# Bida Aim Trainer (Android) — luyện tập offline

Ứng dụng **độc lập**, chạy hoàn toàn offline (không có quyền INTERNET hay bất kỳ quyền nào). Dùng để luyện ngắm bida:
bàn, bi cái, bi mục tiêu, lỗ, đường ngắm, ghost ball, điểm tiếp xúc, đường bi sau va chạm, bank 1…4 băng.
Không chạy overlay trên game nào và không dùng trong trận online.

## Cách dùng
- **Kéo bi** để đặt (bi tự được đẩy ra khỏi băng, lỗ và các bi khác). Chạm bi mục tiêu để chọn làm bi mục tiêu.
- **Chạm/kéo trên vùng trống** để xoay hướng đánh. **Chạm vào lỗ** để chọn lỗ.
- Nút **AIM** (trái) bật/tắt toàn bộ đường ngắm; nút **☰** ẩn/hiện panel.
- Chế độ **Tự do** (góc tuyệt đối), **Vào lỗ** (ghost ball vào lỗ đã chọn + dung sai góc), **Bank** (các tuyến N băng đã kiểm chứng, xếp từ dễ đến khó, chuyển tuyến bằng nút).
- Panel: số lần bật băng (0–8), độ dài tia ngắm, độ dài đường dự đoán, ghost ball / điểm tiếp xúc / đường bi / đường cue sau va chạm, thêm-xóa bi (tối đa 4 bi mục tiêu), lực + ma sát, **debug physics** (vùng va chạm, mép lỗ, pháp tuyến, nhật ký sự kiện, chỉnh e/μ trực tiếp).

## Cài đặt (build APK)
Máy dựng sẵn của tôi không có Android SDK nên **APK chưa được build sẵn trong gói này**. Cách tạo APK (chọn 1):
1. **Android Studio**: File > Open thư mục này > chờ sync > Build > Build APK(s). APK ở `app/build/outputs/apk/debug/app-debug.apk`.
2. **Dòng lệnh**: cài JDK 17 + Gradle 8.7+ + Android SDK (platform 34), đặt `ANDROID_HOME` rồi chạy `scripts/build_apk.sh` → `dist/BidaAimTrainer-debug.apk`.
3. **GitHub Actions** (không cần cài gì): đẩy thư mục này lên một repo GitHub; workflow `.github/workflows/build-apk.yml` tự chạy test + build, tải APK ở tab Actions > Artifacts.

Cài lên điện thoại: chép `.apk` sang máy, mở file, cho phép "cài từ nguồn không xác định" cho ứng dụng file manager. Yêu cầu Android 8.0+ (API 26). Đây là APK debug (ký bằng khóa debug), đủ để cài và dùng.

## Cấu trúc
    engine/  (Java thuần, test trên JVM)
      config / geom / table / ball / collision / physics / guideline   engine vật lý đã test
      trainer/  TrainerModel (trạng thái, kéo thả hợp lệ, 3 chế độ), SceneBuilder (vẽ -> DrawList), Viewport, ...
    app/     (Android, mỏng) MainActivity (panel) + TableView (phát lại DrawList lên Canvas, xử lý chạm)
    app/src/main/assets/billiards_config.properties   MỌI thông số vật lý (bàn, bi, lỗ, độ nảy, ma sát...)
    scripts/ run_tests.sh | preview.sh | aim_cli.sh | build_apk.sh      docs/screenshots/  ảnh giao diện render từ cùng mã vẽ

## Kiểm thử đã chạy (JVM): `scripts/run_tests.sh` → 97.436 kiểm tra, 0 lỗi
Engine: so với phương pháp gương độc lập (33.858 cú đánh 1/2/3 băng), động lượng/năng lượng, quy tắc 90°, đảo ngược thời gian, biên miệng lỗ, mép lỗ, dừng theo ma sát,
bank scanner. Trainer: viewport, kéo thả hợp lệ, cửa sổ dung sai khớp mô phỏng đầy đủ, bank 1/2/3 băng xác nhận qua bi cái, lưu/khôi phục (kể cả dữ liệu hỏng),
bật/tắt từng phần guideline, độ dài tia, fuzz 4.000 thao tác ngẫu nhiên.

## Chưa kiểm chứng được (nói thẳng)
- Chưa build/chạy trên Android thật hoặc emulator (không có SDK). Code Android (~600 dòng) chỉ được kiểm tra kiểu dữ liệu bằng bộ stub API tự viết,
  và toàn bộ phần vẽ được kiểm tra qua ảnh render cùng DrawList. Lỗi API thật (nếu có) sẽ hiện ngay lúc build; mỗi lỗi nhỏ, tập trung ở `app/`.
- Thông số vật lý là chuẩn bàn 9 foot, không hiệu chỉnh theo game cụ thể nào. Không có xoáy (spin) và throw.
- Hiệu năng trên điện thoại chưa đo; khung hình nhanh ~0,004 ms, bank 3 băng ~70 ms trên JVM máy tính và chạy ở luồng nền.
