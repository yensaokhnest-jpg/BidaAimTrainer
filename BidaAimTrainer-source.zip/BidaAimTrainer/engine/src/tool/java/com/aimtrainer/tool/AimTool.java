package com.aimtrainer.tool;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.guideline.*;
import com.aimtrainer.physics.*;
import com.aimtrainer.table.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Text test tool for the engine (NOT the final UI). Reads commands from a scenario file, --line
 * arguments, or stdin (--interactive). Type 'help' for the command list.
 */
public final class AimTool {
    private EngineConfig cfg;
    private Table table;
    private ShotSimulator sim;
    private AimSolver aim;
    private BankScanner bank;
    private final List<Ball> balls = new ArrayList<Ball>();
    private final SvgRenderer svg = new SvgRenderer();
    private final PrintStream out = System.out;
    private boolean includeTips = false;

    public AimTool(EngineConfig c) { setConfig(c); }

    private void setConfig(EngineConfig c) {
        cfg = c; table = new Table(c); sim = new ShotSimulator(c, table);
        aim = new AimSolver(c, table, sim); bank = new BankScanner(c, sim.tracer());
    }
    private TraceOptions opts() { return TraceOptions.fromConfig(cfg); }

    // ---------------------------------------------------------------- command execution
    public void exec(String line) {
        line = line.trim();
        int h = line.indexOf('#'); if (h >= 0) line = line.substring(0, h).trim();
        if (line.isEmpty()) return;
        out.println("> " + line);
        String[] a = line.split("\\s+");
        String cmd = a[0].toLowerCase();
        try {
            if (cmd.equals("cue")) place("cue", num(a, 1), num(a, 2));
            else if (cmd.equals("ball")) place(a[1], num(a, 2), num(a, 3));
            else if (cmd.equals("remove")) { Ball b = find(a[1]); balls.remove(b); out.println("  removed " + a[1]); }
            else if (cmd.equals("clear")) { balls.clear(); svg.clear(); out.println("  cleared"); }
            else if (cmd.equals("cushions")) { setConfig(cfg.with("guideline.max_cushions", a[1])); out.println("  max cushions = " + cfg.maxCushions); }
            else if (cmd.equals("mode")) { setConfig(cfg.with("guideline.mode", a[1])); out.println("  mode = " + a[1]); }
            else if (cmd.equals("speed")) { setConfig(cfg.with("guideline.default_speed", a[1])); out.println("  speed = " + cfg.defaultSpeed + " (used in dynamic mode)"); }
            else if (cmd.equals("set")) { setConfig(cfg.with(a[1], a[2])); out.println("  " + a[1] + " = " + a[2]); }
            else if (cmd.equals("tips")) { includeTips = a[1].equalsIgnoreCase("on"); out.println("  bank solutions through jaw tips: " + (includeTips ? "shown" : "hidden")); }
            else if (cmd.equals("shot")) shot(a);
            else if (cmd.equals("pocket")) pocketShot(a);
            else if (cmd.equals("trace")) traceBall(a);
            else if (cmd.equals("bank")) bankShot(a);
            else if (cmd.equals("svg")) writeSvg(a[1]);
            else if (cmd.equals("show")) show();
            else if (cmd.equals("config")) out.print(cfg.describe());
            else if (cmd.equals("help")) help();
            else out.println("  unknown command '" + cmd + "' (try: help)");
        } catch (ArrayIndexOutOfBoundsException e) {
            out.println("  ERROR: missing argument (try: help)");
        } catch (RuntimeException e) {
            out.println("  ERROR: " + e.getMessage());
        }
    }

    private static double num(String[] a, int i) {
        try { return Double.parseDouble(a[i]); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("'" + a[i] + "' is not a number"); }
    }
    private Ball find(String id) { return ShotSimulator.find(balls, id); }

    private void place(String id, double x, double y) {
        Vec2 p = new Vec2(x, y);
        if (!table.inPlayfield(p, cfg.eps())) throw new IllegalArgumentException("position " + p + " is not a legal ball-center position (outside the cushions or inside a pocket mouth)");
        for (Ball b : balls) if (!b.id.equals(id) && b.pos.dist(p) < 2 * cfg.ballRadius - cfg.eps())
            throw new IllegalArgumentException("overlaps ball '" + b.id + "' (centers " + String.format(Locale.ROOT, "%.3f", b.pos.dist(p)) + " apart, need >= " + 2 * cfg.ballRadius + ")");
        for (Iterator<Ball> it = balls.iterator(); it.hasNext();) if (it.next().id.equals(id)) it.remove();
        balls.add(new Ball(id, p));
        out.println("  " + id + " at " + p);
    }

    // ---------------------------------------------------------------- commands
    private void shot(String[] a) {
        Ball cue = find("cue");
        Vec2 d;
        if (a[1].equals("angle")) d = Vec2.fromAngleDeg(num(a, 2));
        else if (a[1].equals("to")) d = new Vec2(num(a, 2), num(a, 3)).sub(cue.pos);
        else throw new IllegalArgumentException("use: shot angle DEG | shot to X Y");
        ShotResult r = sim.simulate(balls, "cue", d, 0, opts());
        printShot(r);
        drawShot(r);
    }

    private void pocketShot(String[] a) {
        Pocket pk = table.pocketByName(a[2]);
        if (pk == null) throw new IllegalArgumentException("unknown pocket '" + a[2] + "' (bl bm br tl tm tr)");
        CueSolution s = aim.aimAtPocket(balls, "cue", a[1], pk, opts(), 0);
        printSolution(s);
        if (s.windowComputed)
            out.printf(Locale.ROOT, "  aim window: +%.3f deg / -%.3f deg around the aim line (resolution %.3f deg)%n", s.windowPlusDeg, s.windowMinusDeg, cfg.scanAngleStepDeg);
        if (s.shot != null) { printShot(s.shot); drawShot(s.shot); }
        if (s.ghost != null) svg.addGhost(s.ghost);
    }

    private void traceBall(String[] a) {
        Ball b = find(a[1]);
        if (!a[2].equals("angle")) throw new IllegalArgumentException("use: trace ID angle DEG");
        List<Ball> obs = new ArrayList<Ball>();
        for (Ball o : balls) if (o != b) obs.add(o);
        double sp = cfg.dynamicMode ? cfg.defaultSpeed : 1.0;
        PathTrace t = sim.tracer().trace(b.pos, Vec2.fromAngleDeg(num(a, 3)).mul(sp), obs, opts());
        printTrace("PATH of '" + b.id + "'", t);
        svg.addPath(t, null);
    }

    private void bankShot(String[] a) {
        Ball tgt = find(a[1]);
        String pf = null;
        if (!a[2].equalsIgnoreCase("any")) {
            Pocket pk = table.pocketByName(a[2]);
            if (pk == null) throw new IllegalArgumentException("unknown pocket '" + a[2] + "'");
            pf = pk.name;
        }
        int n = (int) num(a, 3);
        List<Ball> obs = new ArrayList<Ball>();
        for (Ball o : balls) if (o != tgt && !o.id.equals("cue")) obs.add(o);
        List<BankSolution> sols = bank.scan(tgt.pos, obs, n, pf, opts());
        int shown = 0, hidden = 0;
        out.printf(Locale.ROOT, "  %d-cushion bank routes for '%s' -> %s (geometric sweep, step %.3f deg)%n", n, tgt.id, pf == null ? "any pocket" : pf, cfg.scanAngleStepDeg);
        for (BankSolution s : sols) {
            boolean tip = false; for (String r : s.rails) if (r.startsWith("tip:")) tip = true;
            if (tip && !includeTips) { hidden++; continue; }
            if (shown >= 8) break;
            shown++;
            out.printf(Locale.ROOT, "  #%d %s via %s  object-ball angle %.4f deg (window %.4f..%.4f, width %.4f)%n", shown, s.pocket, s.rails, s.angleCenterDeg, s.angleMinDeg, s.angleMaxDeg, s.widthDeg());
            if (balls.size() > 0 && indexOf("cue") >= 0) {
                CueSolution c = aim.evaluate(balls, "cue", tgt.id, Vec2.fromAngleDeg(s.angleCenterDeg), s.pocket, n, opts(), 0);
                if (c.cueDir != null) out.printf(Locale.ROOT, "      cue aim angle %.4f deg, ghost %s, cut %.3f deg -> %s%n", c.cueDir.angleDeg(), c.ghost, c.cutAngleDeg, c.pocketOk ? "VERIFIED by full simulation" : "NOT valid: " + c.reason);
                else out.println("      cue: " + c.reason);
                if (shown == 1) { svg.addPath(s.trace, "#ffd400"); }
                if (c.pocketOk && c.shot != null) { svg.addPath(c.shot.cuePath, null); svg.addGhost(c.ghost); }
            } else if (shown == 1) svg.addPath(s.trace, "#ffd400");
        }
        if (hidden > 0) out.println("  (" + hidden + " more route(s) pass through a jaw tip and are hidden; 'tips on' shows them)");
        if (sols.isEmpty()) out.println("  no route found");
    }
    private int indexOf(String id) { for (int i = 0; i < balls.size(); i++) if (balls.get(i).id.equals(id)) return i; return -1; }

    private void writeSvg(String file) {
        try {
            Files.write(Paths.get(file), svg.render(cfg, table, balls).getBytes(StandardCharsets.UTF_8));
            out.println("  wrote " + file);
        } catch (IOException e) { throw new IllegalArgumentException(e.getMessage()); }
    }

    private void show() {
        out.printf(Locale.ROOT, "  profile: %s | unit: %s | table %.1f x %.1f | ball radius %.3f | mode %s | cushions %d%n",
            cfg.profile, cfg.lengthUnit, cfg.tableLength, cfg.tableWidth, cfg.ballRadius, cfg.dynamicMode ? "dynamic" : "geometric", cfg.maxCushions);
        for (Ball b : balls) out.println("  " + b);
        if (balls.isEmpty()) out.println("  (no balls)");
    }

    // ---------------------------------------------------------------- printing
    private void drawShot(ShotResult r) {
        svg.addPath(r.cuePath, "#4da6ff");
        if (r.contact != null) { svg.addGhost(r.contact.ghost); svg.addMarker(r.contact.contactPoint, "#ff3030", "contact"); }
        if (r.targetPath != null) svg.addPath(r.targetPath, "#ff9f1a");
        if (r.cuePostPath != null) svg.addPath(r.cuePostPath, "#7dffb0");
    }

    private void printSolution(CueSolution s) {
        if (s.ghost != null) out.println("  ghost-ball (cue center at impact): " + s.ghost);
        if (s.cueDir != null) out.printf(Locale.ROOT, "  cue aim angle: %.4f deg | cut angle: %.4f deg%n", s.cueDir.angleDeg(), s.cutAngleDeg);
        out.println("  contact OK: " + s.contactOk + " | pocket OK: " + s.pocketOk + (s.reason.isEmpty() ? "" : " | " + s.reason));
    }

    private void printShot(ShotResult r) {
        printTrace("CUE path", r.cuePath);
        if (r.contact == null) return;
        BallContact c = r.contact;
        out.println("  CONTACT with ball '" + c.targetId + "'");
        out.println("    cue center at impact (ghost): " + c.ghost);
        out.println("    contact point:               " + c.contactPoint);
        out.printf(Locale.ROOT, "    line of centers: %.4f deg | cut angle: %.4f deg (%s)%n", c.normal.angleDeg(), c.cutAngleDeg, c.cutSide);
        out.printf(Locale.ROOT, "    cue speed at impact %.4f | after: %.4f at %s | object ball after: %.4f at %.4f deg%n",
            c.speedAtImpact, c.cueVelAfter.len(), c.cueVelAfter.len() > 1e-9 ? String.format(Locale.ROOT, "%.4f deg", c.cueVelAfter.angleDeg()) : "-", c.targetVelAfter.len(), c.targetVelAfter.angleDeg());
        printTrace("OBJECT ball '" + c.targetId + "' path", r.targetPath);
        if (r.cuePostPath != null) printTrace("CUE ball path after contact", r.cuePostPath);
    }

    private void printTrace(String title, PathTrace t) {
        out.printf(Locale.ROOT, "  %s: length %.3f, ends: %s%s%n", title, t.length, t.termination, t.pocketName() != null ? " in " + t.pocketName() : "");
        out.println("    start " + t.points.get(0));
        for (PathEvent e : t.events) {
            switch (e.kind) {
                case CUSHION: case TIP:
                    out.printf(Locale.ROOT, "    [%d] %-6s %-16s at %s  dist %.3f  in %.4f -> out %.4f deg%s%n", e.cushionIndex, e.kind, e.label, e.point, e.distance, e.dirBefore.angleDeg(), e.dirAfter.angleDeg(),
                        cfg.dynamicMode ? String.format(Locale.ROOT, "  speed %.2f->%.2f", e.speedBefore, e.speedAfter) : ""); break;
                case CUSHION_LIMIT:
                    out.printf(Locale.ROOT, "    -- cushion limit reached: next hit would be %s at %s (dist %.3f)%n", e.label, e.point, e.distance); break;
                case BALL_HIT:
                    out.printf(Locale.ROOT, "    BALL_HIT '%s': cue center %s  dist %.3f%n", e.label, e.point, e.distance); break;
                case POCKET:
                    out.printf(Locale.ROOT, "    POCKET %s: center crosses the gate at %s  dist %.3f%n", e.label, e.point, e.distance); break;
            }
        }
        if (t.termination == Termination.MAX_LENGTH || t.termination == Termination.STOPPED || t.termination == Termination.ESCAPED)
            out.println("    end point " + t.endPoint());
    }

    private void help() {
        out.println("  Units/angles: lengths in config unit; origin bottom-left cushion corner, +x right, +y up; angle 0 = +x, CCW.");
        out.println("  cue X Y | ball ID X Y | remove ID | clear | show | config");
        out.println("  shot angle DEG | shot to X Y          cue shot: path, contact point, object-ball + cue paths");
        out.println("  pocket BALL POCKET                     ghost-ball aim to a pocket (bl bm br tl tm tr) + aim window");
        out.println("  trace ID angle DEG                     raw path of any ball (set 'cushions N' for 1/2/3-bank checks)");
        out.println("  bank BALL POCKET|any N                 all N-cushion bank routes (+ cue aim if a cue ball exists)");
        out.println("  cushions N | mode geometric|dynamic | speed V | set KEY VALUE | tips on|off");
        out.println("  svg FILE | help | quit");
    }

    // ---------------------------------------------------------------- main
    public static void main(String[] args) throws Exception {
        String cfgPath = "config/billiards_config.properties", svgOut = null;
        List<String> lines = new ArrayList<String>();
        boolean interactive = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--config")) cfgPath = args[++i];
            else if (a.equals("--scenario")) lines.addAll(Files.readAllLines(Paths.get(args[++i]), StandardCharsets.UTF_8));
            else if (a.equals("--line")) lines.add(args[++i]);
            else if (a.equals("--svg")) svgOut = args[++i];
            else if (a.equals("--interactive")) interactive = true;
            else { System.out.println("unknown option " + a); return; }
        }
        if (lines.isEmpty() && !interactive) {
            System.out.println("usage: aim.sh [--config FILE] [--scenario FILE] [--line \"cmd\"]... [--svg OUT.svg] [--interactive]");
            System.out.println("example: aim.sh --line \"cue 600 400\" --line \"ball 1 1800 800\" --line \"pocket 1 tr\" --svg out/aim.svg");
            return;
        }
        AimTool t = new AimTool(EngineConfig.load(Paths.get(cfgPath)));
        for (String l : lines) t.exec(l);
        if (interactive) {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
            String l;
            System.out.print("aim> "); System.out.flush();
            while ((l = br.readLine()) != null) {
                if (l.trim().equalsIgnoreCase("quit") || l.trim().equalsIgnoreCase("exit")) break;
                t.exec(l);
                System.out.print("aim> "); System.out.flush();
            }
        }
        if (svgOut != null) t.exec("svg " + svgOut);
    }
}
