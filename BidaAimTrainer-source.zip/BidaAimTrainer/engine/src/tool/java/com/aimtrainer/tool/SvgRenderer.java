package com.aimtrainer.tool;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.physics.*;
import com.aimtrainer.table.*;
import java.util.*;

/** Debug drawing only (no physics). Accumulates layers, renders one SVG. y axis is flipped (+y up). */
public final class SvgRenderer {
    private final List<String[]> paths = new ArrayList<String[]>();   // {color, points}
    private final List<String[]> circles = new ArrayList<String[]>(); // {x,y,style}
    private final List<String[]> dots = new ArrayList<String[]>();    // {x,y,color,label}
    private final List<double[]> pathPts = new ArrayList<double[]>();

    public void addPath(PathTrace t, String color) {
        StringBuilder sb = new StringBuilder();
        for (Vec2 p : t.points) sb.append(p.x).append(',').append(p.y).append(' ');
        paths.add(new String[] { color, sb.toString().trim() });
        for (PathEvent e : t.events) {
            String col = e.kind == EventKind.BALL_HIT ? "#ff3030" : e.kind == EventKind.POCKET ? "#ffd400" : e.kind == EventKind.TIP ? "#ff00ff" : "#ffffff";
            dots.add(new String[] { "" + e.point.x, "" + e.point.y, col, e.kind == EventKind.CUSHION ? "" + e.cushionIndex : "" });
        }
    }
    public void addGhost(Vec2 c) { circles.add(new String[] { "" + c.x, "" + c.y }); }
    public void addMarker(Vec2 p, String color, String label) { dots.add(new String[] { "" + p.x, "" + p.y, color, label }); }
    public void clear() { paths.clear(); circles.clear(); dots.clear(); }

    public String render(EngineConfig c, Table t, List<Ball> balls) {
        double s = 1000.0 / c.tableLength, m = 40, R = c.ballRadius;
        double W = c.tableLength * s + 2 * m, H = c.tableWidth * s + 2 * m;
        StringBuilder o = new StringBuilder();
        o.append(String.format(Locale.ROOT, "<svg xmlns='http://www.w3.org/2000/svg' width='%.0f' height='%.0f' viewBox='0 0 %.0f %.0f'>", W, H, W, H));
        o.append("<rect width='100%' height='100%' fill='#222'/>");
        o.append(String.format(Locale.ROOT, "<rect x='%.2f' y='%.2f' width='%.2f' height='%.2f' fill='#0b6b3a'/>", m, m, c.tableLength * s, c.tableWidth * s));
        o.append(String.format(Locale.ROOT, "<rect x='%.2f' y='%.2f' width='%.2f' height='%.2f' fill='none' stroke='#2a9d5c' stroke-dasharray='4 4'/>",
            m + R * s, m + R * s, (c.tableLength - 2 * R) * s, (c.tableWidth - 2 * R) * s));
        for (CushionSegment g : t.cushions)
            o.append(line(g.a, g.b, "#8b5a2b", 5, s, m, c));
        for (Pocket p : t.pockets) {
            o.append(line(p.a, p.b, "#ffd400", 2, s, m, c).replace("/>", " stroke-dasharray='5 3'/>"));
            o.append(String.format(Locale.ROOT, "<text x='%.1f' y='%.1f' fill='#ffd400' font-size='11' text-anchor='middle'>%s</text>", X(p.mid.x, s, m) - p.inward.x * 14, Y(p.mid.y, s, m, c) + p.inward.y * 14, p.shortName));
        }
        for (Tip k : t.tips)
            o.append(String.format(Locale.ROOT, "<circle cx='%.2f' cy='%.2f' r='2.5' fill='#ff7070'/>", X(k.pos.x, s, m), Y(k.pos.y, s, m, c)));
        for (Ball b : balls) {
            String fill = b.id.equals("cue") ? "#f5f5f5" : "#f0c020";
            o.append(String.format(Locale.ROOT, "<circle cx='%.2f' cy='%.2f' r='%.2f' fill='%s' stroke='#000'/>", X(b.pos.x, s, m), Y(b.pos.y, s, m, c), R * s, fill));
            o.append(String.format(Locale.ROOT, "<text x='%.1f' y='%.1f' font-size='11' text-anchor='middle' fill='#000'>%s</text>", X(b.pos.x, s, m), Y(b.pos.y, s, m, c) + 4, b.id));
        }
        String[] cols = { "#4da6ff", "#ff9f1a", "#c77dff", "#7dffb0", "#ff7d7d" };
        int i = 0;
        for (String[] p : paths) {
            StringBuilder pts = new StringBuilder();
            for (String xy : p[1].split(" ")) { String[] v = xy.split(","); pts.append(String.format(Locale.ROOT, "%.2f,%.2f ", X(Double.parseDouble(v[0]), s, m), Y(Double.parseDouble(v[1]), s, m, c))); }
            String col = p[0] != null ? p[0] : cols[i++ % cols.length];
            o.append("<polyline fill='none' stroke='").append(col).append("' stroke-width='1.6' points='").append(pts).append("'/>");
        }
        for (String[] g : circles)
            o.append(String.format(Locale.ROOT, "<circle cx='%.2f' cy='%.2f' r='%.2f' fill='none' stroke='#fff' stroke-dasharray='4 3'/>", X(Double.parseDouble(g[0]), s, m), Y(Double.parseDouble(g[1]), s, m, c), R * s));
        for (String[] d : dots) {
            o.append(String.format(Locale.ROOT, "<circle cx='%.2f' cy='%.2f' r='3' fill='%s'/>", X(Double.parseDouble(d[0]), s, m), Y(Double.parseDouble(d[1]), s, m, c), d[2]));
            if (!d[3].isEmpty()) o.append(String.format(Locale.ROOT, "<text x='%.1f' y='%.1f' font-size='10' fill='#fff'>%s</text>", X(Double.parseDouble(d[0]), s, m) + 5, Y(Double.parseDouble(d[1]), s, m, c) - 5, d[3]));
        }
        o.append("</svg>");
        return o.toString();
    }
    private static double X(double x, double s, double m) { return m + x * s; }
    private static double Y(double y, double s, double m, EngineConfig c) { return m + (c.tableWidth - y) * s; }
    private static String line(Vec2 a, Vec2 b, String col, int w, double s, double m, EngineConfig c) {
        return String.format(Locale.ROOT, "<line x1='%.2f' y1='%.2f' x2='%.2f' y2='%.2f' stroke='%s' stroke-width='%d'/>",
            X(a.x, s, m), Y(a.y, s, m, c), X(b.x, s, m), Y(b.y, s, m, c), col, w);
    }
}
