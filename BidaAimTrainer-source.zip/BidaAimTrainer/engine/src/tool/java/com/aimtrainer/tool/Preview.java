package com.aimtrainer.tool;

import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.trainer.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Paths;
import javax.imageio.ImageIO;

/** Renders a DrawList to PNG with Java2D: the same commands the Android view replays on a Canvas. */
public final class Preview {
    public static BufferedImage render(DrawList d, int w, int h) {
        BufferedImage im = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = im.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        for (DrawList.Prim p : d.items) {
            Stroke st = null;
            if (p.stroke != 0 && p.kind != DrawList.TEXT) {
                float wd = (float) Math.max(0.5, p.width);
                st = p.dash ? new BasicStroke(wd, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND, 10f, new float[] { 8f, 6f }, 0f)
                            : new BasicStroke(wd, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
            }
            Shape sh = null;
            switch (p.kind) {
                case DrawList.RECT: sh = new Rectangle2D.Double(p.x[0], p.y[0], p.x[1] - p.x[0], p.y[1] - p.y[0]); break;
                case DrawList.LINE: sh = new Line2D.Double(p.x[0], p.y[0], p.x[1], p.y[1]); break;
                case DrawList.POLY: { Path2D.Double q = new Path2D.Double(); for (int i = 0; i < p.x.length; i++) { if (i == 0) q.moveTo(p.x[i], p.y[i]); else q.lineTo(p.x[i], p.y[i]); } sh = q; break; }
                case DrawList.CIRCLE: sh = new Ellipse2D.Double(p.x[0] - p.r, p.y[0] - p.r, 2 * p.r, 2 * p.r); break;
                default: break;
            }
            if (p.kind == DrawList.TEXT) {
                g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, (int) Math.round(p.size)));
                g.setColor(new Color(p.fill, true));
                int tw = g.getFontMetrics().stringWidth(p.text);
                double x = p.align == DrawList.CENTER ? p.x[0] - tw / 2.0 : p.align == DrawList.RIGHT ? p.x[0] - tw : p.x[0];
                g.drawString(p.text, (float) x, (float) p.y[0]);
                continue;
            }
            if (p.fill != 0 && p.kind != DrawList.POLY && p.kind != DrawList.LINE) { g.setColor(new Color(p.fill, true)); g.fill(sh); }
            if (p.stroke != 0) { g.setColor(new Color(p.stroke, true)); g.setStroke(st); g.draw(sh); }
        }
        g.dispose();
        return im;
    }

    /** Builds and renders the current model state like the Android view would (side panel space reserved). */
    public static void save(TrainerModel m, String file, int w, int h, double dp, double rightInset) throws Exception {
        TrainerFrame f = m.frame();
        Viewport v = Viewport.fit(w, h, m.config().tableLength, m.config().tableWidth, SceneBuilder.railWidth(m.config()), 8 * dp, rightInset);
        DrawList d = SceneBuilder.build(m, f, v, w, h, dp);
        ImageIO.write(render(d, w, h), "png", new File(file));
    }

    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        String out = a.length > 0 ? a[0] : "build/preview";
        new File(out).mkdirs();
        EngineConfig cfg = EngineConfig.load(Paths.get("app/src/main/assets/billiards_config.properties"));
        int w = 1280, h = 600; double dp = 2.0;

        TrainerModel m = new TrainerModel(cfg);
        m.settings().maxCushions = 3; m.physicsSettingsChanged();
        m.setFreeAngle(14); save(m, out + "/free_3cushions.png", w, h, dp, 0);

        m = new TrainerModel(cfg);
        m.moveBall("cue", new Vec2(600, 400)); m.moveBall("1", new Vec2(1800, 800));
        m.selectPocket("tr"); m.runHeavyNow(); save(m, out + "/pocket.png", w, h, dp, 0);

        m = new TrainerModel(cfg);
        m.moveBall("cue", new Vec2(500, 300)); m.moveBall("1", new Vec2(1500, 400));
        m.setMode(TrainerMode.BANK); m.runHeavyNow(); save(m, out + "/bank1.png", w, h, dp, 0);

        m.setBankCushions(2); m.runHeavyNow(); save(m, out + "/bank2.png", w, h, dp, 0);

        m = new TrainerModel(cfg);
        m.addObjectBall(); m.settings().debug = true; m.settings().maxCushions = 2; m.physicsSettingsChanged();
        m.selectPocket("tm"); m.runHeavyNow(); save(m, out + "/debug.png", w, h, dp, 0);
        System.out.println("saved previews in " + out);
    }
}
