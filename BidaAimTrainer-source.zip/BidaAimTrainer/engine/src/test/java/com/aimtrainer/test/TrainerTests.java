package com.aimtrainer.test;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.physics.*;
import com.aimtrainer.trainer.*;
import java.util.*;

/** Tests of the Android-independent trainer layer (model, viewport, scene). Uses TestRunner's helpers. */
final class TrainerTests {
    private TrainerTests() {}
    static EngineConfig BASE;

    static TrainerModel model() { return new TrainerModel(BASE); }

    /** Finds a free-aim angle whose cue path reaches at least `cushions` bounces without ending in a pocket or ball. */
    static double angleWithBounces(TrainerModel m, int cushions) {
        for (double a = -85; a <= 85; a += 0.37) {
            m.setFreeAngle(a);
            PathTrace p = m.frame().shot.cuePath;
            if (p.termination == Termination.MAX_CUSHIONS && p.cushionCount >= cushions) return a;
        }
        throw new IllegalStateException("no angle with " + cushions + " bounces");
    }
    static void place(TrainerModel m, String id, double x, double y) { TestRunner.check(m.moveBall(id, new Vec2(x, y)), "place " + id + " at " + x + "," + y); }

    static void viewport() {
        double L = BASE.tableLength, W = BASE.tableWidth, rail = SceneBuilder.railWidth(BASE);
        Viewport v = Viewport.fit(1280, 600, L, W, rail, 16, 300);
        Random r = new Random(1);
        for (int i = 0; i < 200; i++) {
            double x = r.nextDouble() * L, y = r.nextDouble() * W;
            TestRunner.near("viewport x round trip", v.tx(v.sx(x)), x, 1e-9);
            TestRunner.near("viewport y round trip", v.ty(v.sy(y)), y, 1e-9);
        }
        TestRunner.check(v.sx(-rail) >= 16 - 1e-9 && v.sx(L + rail) <= 1280 - 300 - 16 + 1e-9, "table + rail fit horizontally inside the free area");
        TestRunner.check(v.sy(W + rail) >= 16 - 1e-9 && v.sy(-rail) <= 600 - 16 + 1e-9, "table + rail fit vertically");
        TestRunner.check(v.sy(W) < v.sy(0), "y axis is flipped (top of table has smaller pixel y)");
        TestRunner.near("scale is uniform", v.len(100), v.sx(100) - v.sx(0), 1e-9);
    }

    static void clip() {
        List<Vec2> p = Arrays.asList(new Vec2(0, 0), new Vec2(10, 0), new Vec2(10, 10));
        TestRunner.near("length", PolylineClip.length(p), 20, 1e-12);
        List<Vec2> c = PolylineClip.clip(p, 15);
        TestRunner.nearV("cut point", c.get(c.size() - 1), new Vec2(10, 5), 1e-12);
        TestRunner.near("clipped length", PolylineClip.length(c), 15, 1e-12);
        TestRunner.check(PolylineClip.clip(p, 100).size() == 3, "longer than the path keeps all points");
        TestRunner.check(PolylineClip.clip(p, 0).size() == 1, "zero length keeps only the start");
        TestRunner.near("clip inside first segment", PolylineClip.length(PolylineClip.clip(p, 4)), 4, 1e-12);
    }

    static void legalMoves() {
        TrainerModel m = model(); double R = BASE.ballRadius;
        TestRunner.check(m.moveBall("1", new Vec2(-500, 99999)), "wild point is legalized");
        Vec2 q = m.ball("1").pos;
        TestRunner.check(m.table().inPlayfield(q, 1e-9), "legalized point is playable: " + q);
        Vec2 cue = m.ball("cue").pos;
        TestRunner.check(m.moveBall("1", cue.add(new Vec2(10, 0))), "move onto the cue ball");
        TestRunner.check(m.ball("1").pos.dist(cue) >= 2 * R - 1e-6, "overlap is pushed out (dist " + m.ball("1").pos.dist(cue) + ")");
        TestRunner.check(m.moveBall("1", new Vec2(3, 3)), "corner pocket mouth point");
        TestRunner.check(m.table().inPlayfield(m.ball("1").pos, 1e-9), "pocket-mouth point is moved to a legal spot: " + m.ball("1").pos);
        place(m, "1", 1700, 500);
        TestRunner.check("1".equals(m.pickBall(new Vec2(1700 + R + 10, 500), 15)), "pickBall within tolerance");
        TestRunner.check(m.pickBall(new Vec2(1700 + R + 40, 500), 15) == null, "pickBall outside tolerance");
        TestRunner.check(m.pickPocket(m.pocketCenter(m.table().pocketByName("tr")), 5).equals("top_right"), "pickPocket at a pocket center");
        TestRunner.check(m.pickPocket(new Vec2(1270, 635), 20) == null, "pickPocket in the middle of the table is null");
    }

    static void addRemove() {
        TrainerModel m = model();
        for (int i = 2; i <= 4; i++) TestRunner.check(("" + i).equals(m.addObjectBall()), "added ball " + i);
        TestRunner.check(m.addObjectBall() == null, "no more than " + TrainerModel.MAX_OBJECT_BALLS + " object balls");
        for (Ball a : m.balls()) for (Ball b : m.balls()) if (a != b) TestRunner.check(a.pos.dist(b.pos) >= 2 * BASE.ballRadius - 1e-6, "no overlap after adds");
        TestRunner.check(!m.removeBall("cue"), "cue ball cannot be removed");
        m.selectTarget("3"); TestRunner.check(m.removeBall("3") && !m.targetId().equals("3"), "removing the target re-targets");
        TestRunner.check(m.removeBall("2") && m.removeBall("4"), "remove others");
        TestRunner.check(!m.removeBall(m.targetId()), "last object ball cannot be removed");
    }

    static void freeMode() {
        TrainerModel m = model();
        place(m, "1", 2300, 1100);
        m.setFreeAngle(-30);
        for (int n = 0; n <= 3; n++) {
            m.settings().maxCushions = n; m.physicsSettingsChanged();
            TrainerFrame f = m.frame();
            TestRunner.check(f.shot.contact == null && f.shot.cuePath.cushionCount == n && f.shot.cuePath.termination == Termination.MAX_CUSHIONS,
                "free mode with " + n + " cushions: count " + f.shot.cuePath.cushionCount + " " + f.shot.cuePath.termination);
        }
        m.settings().maxCushions = 8; m.physicsSettingsChanged();
        double a8 = angleWithBounces(m, 8);
        m.setFreeAngle(a8);
        TestRunner.check(m.frame().shot.cuePath.cushionCount == 8 && m.frame().shot.cuePath.termination == Termination.MAX_CUSHIONS, "up to 8 cushions are supported (angle " + a8 + ")");
        m.setFreeAngle(-30);
        TestRunner.check(m.frame().shot.cuePath.termination == Termination.POCKETED, "at -30 deg the ball is legitimately pocketed after 5 bounces (jaw hit included)");
        // aimToward / nudge
        m.aimToward(new Vec2(m.ball("cue").pos.x + 100, m.ball("cue").pos.y + 100));
        TestRunner.near("aimToward sets 45 deg", m.freeAngleDeg(), 45, 1e-9);
        m.nudge(0.1); TestRunner.near("nudge +0.1", m.freeAngleDeg(), 45.1, 1e-9);
        m.setFreeAngle(190); TestRunner.near("angles wrap to (-180,180]", m.freeAngleDeg(), -170, 1e-9);
        // frame == direct simulation
        place(m, "1", 1700, 500); m.setFreeAngle(8);
        TrainerFrame f = m.frame();
        ShotResult direct = new ShotSimulator(m.config(), m.table()).simulate(new ArrayList<Ball>(m.balls()), "cue", Vec2.fromAngleDeg(8), 0, TraceOptions.fromConfig(m.config()));
        TestRunner.nearV("frame cue path == direct simulation", f.shot.cuePath.endPoint(), direct.cuePath.endPoint(), 1e-9);
        TestRunner.check(f.status.length() > 0, "status text present");
    }

    static void pocketMode() {
        TrainerModel m = model();
        place(m, "cue", 600, 400); place(m, "1", 1800, 800);
        m.selectPocket("tr");
        TestRunner.check(m.mode() == TrainerMode.POCKET, "selectPocket switches FREE -> POCKET");
        TrainerFrame f0 = m.frame();
        TestRunner.check(f0.computing && !f0.windowKnown, "window not known before the slow job");
        TestRunner.check(f0.solution.pocketOk, "fast frame already has a valid aim: " + f0.solution.reason);
        TestRunner.check("top_right".equals(f0.shot.targetPocketName()), "ideal aim pockets the ball");
        // stale results are rejected
        TrainerModel.HeavyJob job = m.heavyJob();
        place(m, "1", 1800, 801);
        TestRunner.check(!m.acceptHeavy(job.run()), "stale heavy result is rejected");
        place(m, "1", 1800, 800);
        m.runHeavyNow();
        TrainerFrame f = m.frame();
        TestRunner.check(f.windowKnown && f.windowPlus > 0 && f.windowMinus > 0, "window known: +" + f.windowPlus + " -" + f.windowMinus);
        double step = m.config().scanAngleStepDeg;
        m.setOffset(0.8 * f.windowPlus);
        TestRunner.check("top_right".equals(m.frame().shot.targetPocketName()), "offset inside +window still pockets");
        m.setOffset(f.windowPlus + 3 * step + 0.05);
        TestRunner.check(!"top_right".equals(m.frame().shot.targetPocketName()), "offset beyond +window misses");
        m.setOffset(-0.8 * f.windowMinus);
        TestRunner.check("top_right".equals(m.frame().shot.targetPocketName()), "offset inside -window still pockets");
        m.setOffset(-(f.windowMinus + 3 * step + 0.05));
        TestRunner.check(!"top_right".equals(m.frame().shot.targetPocketName()), "offset beyond -window misses");
        m.resetOffset();
        m.aimToward(m.ball("1").pos.add(new Vec2(0, 200)));    // drag aim somewhere else -> offset, clamped
        TestRunner.check(Math.abs(m.offsetDeg()) <= 20.0001, "offset is clamped to +-20 deg");
        // invalid pocket (cut >= 90) is reported, and in Vietnamese
        m.resetOffset(); m.selectPocket("bl");
        TrainerFrame bad = m.frame();
        TestRunner.check(!bad.solution.pocketOk && bad.status.contains("Không thể vào"), "impossible pocket reported: " + bad.status);
    }

    static void bankMode() {
        TrainerModel m = model();
        place(m, "cue", 500, 300); place(m, "1", 1500, 400);
        m.setMode(TrainerMode.BANK);
        TestRunner.check(m.frame().computing, "bank routes not ready before the slow job");
        m.runHeavyNow();
        TrainerFrame f = m.frame();
        TestRunner.check(!f.computing && !f.routes.isEmpty(), "1-cushion routes found: " + f.routes.size());
        for (int n = 1; n <= 3; n++) {
            m.setBankCushions(n); m.runHeavyNow();
            TrainerFrame g = m.frame();
            TestRunner.check(!g.routes.isEmpty(), n + "-cushion routes exist");
            int shown = 0;
            for (int i = 0; i < g.routes.size(); i++) {
                BankRoute r = g.routes.get(i);
                TestRunner.check(r.cue.pocketOk && r.cushions() == n, "route verified through the cue ball");
                TestRunner.check(m.bankIndex() == 0 || true, "");
                shown++;
            }
            TestRunner.check(g.shot.targetPath != null && g.shot.targetPath.pocketName() != null && g.shot.targetPath.cushionCount == n,
                n + "-cushion: selected route pockets the ball after exactly " + n + " cushions");
            TestRunner.check(g.status.startsWith("Bank " + n), "status: " + g.status);
            for (int i = 1; i < g.routes.size(); i++) {         // ranked easiest first
                double a = g.routes.get(i - 1).solution.widthDeg() * Math.cos(Math.toRadians(g.routes.get(i - 1).cue.cutAngleDeg));
                double b = g.routes.get(i).solution.widthDeg() * Math.cos(Math.toRadians(g.routes.get(i).cue.cutAngleDeg));
                TestRunner.check(a >= b - 1e-12, "routes are ranked");
            }
        }
        m.setBankCushions(1); m.runHeavyNow();
        int cnt = m.frame().routes.size();
        if (cnt > 1) {
            m.nextBank(1);
            TestRunner.check(m.bankIndex() == 1, "nextBank");
            for (int i = 0; i < cnt - 1; i++) m.nextBank(1);
            TestRunner.check(m.bankIndex() == 0, "nextBank wraps around");
            m.nextBank(-1); TestRunner.check(m.bankIndex() == cnt - 1, "previous bank wraps");
            TestRunner.check(m.frame().shot.targetPocketName() != null, "every selected route pockets the ball");
        }
        m.nextBank(-(m.bankIndex()));
        m.setOffset(6);
        TestRunner.check(m.frame().shot.targetPocketName() == null || m.frame().shot.targetPath.cushionCount != 1, "a 6-degree aiming error loses the bank");
        m.resetOffset();
        // pocket-restricted banks
        m.selectPocket("br");
        m.setBankAnyPocket(false); m.runHeavyNow();
        for (BankRoute r : m.frame().routes) TestRunner.check("bottom_right".equals(r.pocket()), "pocket filter respected");
        // an obstacle ball can remove routes but never produces an invalid one
        m.setBankAnyPocket(true); m.addObjectBall(); m.runHeavyNow();
        for (BankRoute r : m.frame().routes) TestRunner.check(r.cue.pocketOk, "routes stay verified with an obstacle");
    }

    static void dynamicMode() {
        TrainerModel m = model();
        m.settings().dynamic = true; m.settings().power = 300; m.physicsSettingsChanged();
        m.setFreeAngle(m.ball("1").pos.sub(m.ball("cue").pos).angleDeg());
        TrainerFrame f = m.frame();
        TestRunner.check(f.shot.contact == null && f.shot.cuePath.termination == Termination.STOPPED, "weak shot stops before the ball: " + f.shot.cuePath.termination);
        TestRunner.check(f.status.contains("ma sát"), "status explains: " + f.status);
        m.settings().power = 6000; m.physicsSettingsChanged();
        TestRunner.check(m.frame().shot.contact != null, "strong shot reaches the ball");
        double decel = m.config().rollingFriction * m.config().gravity;
        m.settings().power = 1000; m.physicsSettingsChanged();
        m.setFreeAngle(-90);  // straight down: bounce in place until it stops
        PathTrace p = m.frame().shot.cuePath;
        TestRunner.check(p.termination == Termination.STOPPED || p.cushionCount == 3, "dynamic cue path ends sensibly: " + p.termination);
        TestRunner.check(decel > 0, "friction configured");
    }

    static void persistence() {
        TrainerModel m = model();
        place(m, "cue", 400, 300); place(m, "1", 1900, 700); m.addObjectBall();
        m.settings().maxCushions = 5; m.settings().showGhost = false; m.settings().aimLenFactor = 4.5;
        m.settings().cushionRestitution = 0.9; m.settings().dynamic = true; m.settings().power = 4321;
        m.physicsSettingsChanged();
        m.selectPocket("tl"); m.setMode(TrainerMode.BANK); m.setFreeAngle(33);
        String saved = m.save();
        TrainerModel n = model(); n.load(saved);
        TestRunner.check(saved.equals(n.save()), "save/load round trip is exact");
        TestRunner.check(n.mode() == TrainerMode.BANK && n.pocketName().equals("top_left") && n.settings().maxCushions == 5, "state restored");
        TestRunner.check(Math.abs(n.config().cushionRestitution - 0.9) < 1e-12, "physics settings restored into the engine");
        // hostile / corrupt input must never break the model
        String[] bad = { null, "", "zzz", "mode=BOGUS\nball=1,NaN,5\nball=cue,abc\nball=9,100,100\ncushions=99\ne=-4\npower=NaN\nfree=NaN",
                         "ball=cue,100,100\nball=cue,200,200\nball=1,100,100", "ball=1,1e308,1e308\nball=cue,-5,-5" };
        for (String b : bad) {
            TrainerModel x = model();
            try { x.load(b); } catch (RuntimeException e) { TestRunner.check(false, "load threw " + e + " for: " + b); continue; }
            TestRunner.check(x.balls().size() >= 2, "still has cue + object ball");
            for (Ball a : x.balls()) TestRunner.check(x.table().inPlayfield(a.pos, 1e-9), "restored ball is legal");
            TestRunner.check(x.settings().maxCushions >= 0 && x.settings().maxCushions <= TrainerSettings.MAX_CUSHIONS, "settings clamped");
            x.frame();
        }
    }

    static void finite(DrawList d, String ctx) {
        for (DrawList.Prim p : d.items) {
            boolean ok = true;
            for (double v : p.x) if (Double.isNaN(v) || Double.isInfinite(v)) ok = false;
            for (double v : p.y) if (Double.isNaN(v) || Double.isInfinite(v)) ok = false;
            if (Double.isNaN(p.r) || Double.isInfinite(p.r)) ok = false;
            if (!ok) { TestRunner.check(false, "non-finite drawing coordinate (" + p.tag + ") " + ctx); return; }
        }
        TestRunner.pass++;
    }

    static DrawList scene(TrainerModel m, double w, double h, double dp, double inset) {
        Viewport v = Viewport.fit(w, h, m.config().tableLength, m.config().tableWidth, SceneBuilder.railWidth(m.config()), 8 * dp, inset);
        return SceneBuilder.build(m, m.frame(), v, w, h, dp);
    }

    static void sceneToggles() {
        TrainerModel m = model();
        place(m, "cue", 600, 400); place(m, "1", 1800, 800); m.setFreeAngle(17.8);
        DrawList d = scene(m, 1280, 600, 2, 0);
        TestRunner.check(d.count("cueRay") == 1 && d.count("ghost") == 1 && d.count("contact") == 1 && d.count("objPath") == 1, "all guide parts drawn");
        TestRunner.check(d.count("ball") == 2 && d.count("pocket") == 6 && d.count("cushion") == 6, "table parts drawn");
        m.settings().showGhost = false; m.displaySettingsChanged();
        TestRunner.check(scene(m, 1280, 600, 2, 0).count("ghost") == 0, "ghost can be hidden");
        m.settings().showContact = false;
        TestRunner.check(scene(m, 1280, 600, 2, 0).count("contact") == 0, "contact point can be hidden");
        m.settings().showObjectPath = false; m.settings().showCuePost = false;
        d = scene(m, 1280, 600, 2, 0);
        TestRunner.check(d.count("objPath") == 0 && d.count("cuePost") == 0, "predicted paths can be hidden");
        m.settings().showGuide = false;
        d = scene(m, 1280, 600, 2, 0);
        TestRunner.check(d.count("cueRay") == 0 && d.count("ghost") == 0 && d.count("contact") == 0 && d.count("ball") == 2, "AIM off hides the guide but keeps the table");
        TestRunner.check(d.count("pocketHit") == 0, "AIM off hides the pocket result highlight");
        m.settings().showGuide = true; m.settings().debug = true;
        d = scene(m, 1280, 600, 2, 0);
        TestRunner.check(d.count("dbgTip") == 12 && d.count("dbgGate") == 6 && d.count("dbgBox") == 1 && d.count("dbgText") > 0, "debug overlay drawn");
        m.settings().debug = false;
        TestRunner.check(scene(m, 1280, 600, 2, 0).count("dbgTip") == 0, "debug overlay off");
        // ray length setting really clips the drawn line
        m.settings().showObjectPath = true; m.settings().maxCushions = 8; m.physicsSettingsChanged();
        place(m, "cue", 711, 635); place(m, "1", 2300, 1100);
        double aLong = angleWithBounces(m, 8);
        m.setFreeAngle(aLong);
        TestRunner.check(PolylineClip.length(m.frame().shot.cuePath.points) > 3.2 * m.config().tableLength, "test path is longer than the largest ray setting");
        for (double k : new double[] { 0.2, 0.5, 1.0, 3.0 }) {
            m.settings().aimLenFactor = k; m.displaySettingsChanged();
            Viewport v = Viewport.fit(1280, 600, m.config().tableLength, m.config().tableWidth, SceneBuilder.railWidth(m.config()), 16, 0);
            DrawList s = SceneBuilder.build(m, m.frame(), v, 1280, 600, 2);
            double len = 0;
            for (DrawList.Prim p : s.items) if (p.tag.equals("cueRay"))
                for (int i = 1; i < p.x.length; i++) len += Math.hypot(p.x[i] - p.x[i - 1], p.y[i] - p.y[i - 1]);
            TestRunner.near("cue ray drawn length for factor " + k, len, k * m.config().tableLength * v.scale, 1e-6 * len + 1e-6);
        }
        // sizes: phone-like and tablet-like, panel inset
        double[][] sizes = { { 800, 360, 2.75, 0 }, { 800, 360, 2.75, 330 }, { 2400, 1080, 3.0, 800 }, { 320, 200, 1.0, 0 } };
        for (double[] z : sizes) finite(scene(m, z[0], z[1], z[2], z[3]), z[0] + "x" + z[1]);
    }

    static void fuzz() {
        Random r = new Random(77);
        TrainerModel m = model();
        String[] pk = { "bl", "bm", "br", "tl", "tm", "tr" };
        int heavy = 0;
        for (int i = 0; i < 4000; i++) {
            int op = r.nextInt(14);
            Vec2 p = new Vec2(-200 + r.nextDouble() * 3000, -200 + r.nextDouble() * 1700);
            if (op == 0) m.moveBall("cue", p);
            else if (op == 1) { List<Ball> bs = m.balls(); m.moveBall(bs.get(1 + r.nextInt(bs.size() - 1)).id, p); }
            else if (op == 2) m.setMode(TrainerMode.values()[r.nextInt(3)]);
            else if (op == 3) m.selectPocket(pk[r.nextInt(6)]);
            else if (op == 4) m.addObjectBall();
            else if (op == 5) { List<Ball> bs = m.balls(); m.removeBall(bs.get(r.nextInt(bs.size())).id); }
            else if (op == 6) m.nudge(r.nextDouble() * 4 - 2);
            else if (op == 7) m.aimToward(p);
            else if (op == 8) { m.settings().maxCushions = r.nextInt(10); m.physicsSettingsChanged(); }
            else if (op == 9) { m.settings().dynamic = r.nextInt(4) == 0; m.settings().power = 100 + r.nextInt(8000); m.physicsSettingsChanged(); }
            else if (op == 10) { m.setBankCushions(1 + r.nextInt(4)); }
            else if (op == 11) m.selectTarget("" + (1 + r.nextInt(4)));
            else if (op == 12) m.nextBank(r.nextBoolean() ? 1 : -1);
            else { m.settings().debug = r.nextBoolean(); m.settings().showGuide = r.nextInt(5) != 0; m.displaySettingsChanged(); }
            if (m.needsHeavy() && i % 160 == 0) { m.runHeavyNow(); heavy++; }
            for (Ball a : m.balls()) {
                TestRunner.check(m.table().inPlayfield(a.pos, 1e-9), "ball stays legal (op " + op + ")");
                for (Ball b : m.balls()) if (a != b && a.pos.dist(b.pos) < 2 * BASE.ballRadius - 1e-6) TestRunner.check(false, "overlap after op " + op);
            }
            try { finite(scene(m, 800, 360, 2.75, i % 2 == 0 ? 0 : 300), "fuzz step " + i); }
            catch (RuntimeException e) { TestRunner.check(false, "exception at step " + i + " op " + op + ": " + e); e.printStackTrace(System.out); return; }
        }
        System.out.println("    4000 random UI operations, " + heavy + " slow computations, no exception / illegal state");
    }

    static void timing() {
        TrainerModel m = model();
        place(m, "cue", 500, 300); place(m, "1", 1500, 400);
        long t0 = System.nanoTime();
        for (int i = 0; i < 200; i++) m.frame();
        double fast = (System.nanoTime() - t0) / 1e6 / 200;
        m.setMode(TrainerMode.BANK); m.setBankCushions(3);
        t0 = System.nanoTime(); m.runHeavyNow(); double bank3 = (System.nanoTime() - t0) / 1e6;
        m.selectPocket("tr"); m.setMode(TrainerMode.POCKET);
        t0 = System.nanoTime(); m.runHeavyNow(); double win = (System.nanoTime() - t0) / 1e6;
        System.out.printf(Locale.ROOT, "    frame(): %.3f ms | 3-cushion bank sweep: %.0f ms | aim window: %.0f ms (desktop JVM; phone is slower, so the slow ones run in a background thread)%n", fast, bank3, win);
        TestRunner.check(fast < 5, "fast frame is cheap enough for dragging (" + fast + " ms)");
    }
}
