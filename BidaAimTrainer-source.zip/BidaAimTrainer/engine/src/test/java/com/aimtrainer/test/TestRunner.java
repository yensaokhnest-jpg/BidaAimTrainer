package com.aimtrainer.test;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.collision.Impulse;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.guideline.*;
import com.aimtrainer.physics.*;
import com.aimtrainer.table.*;
import java.nio.file.Paths;
import java.util.*;

/** Dependency-free test runner. Run from the project root:  ./run_tests.sh */
public final class TestRunner {
    static int pass = 0, fail = 0;
    static EngineConfig BASE;

    static void check(boolean ok, String msg) { if (ok) pass++; else { fail++; System.out.println("    FAIL: " + msg); } }
    static void near(String msg, double got, double exp, double tol) {
        check(Math.abs(got - exp) <= tol, msg + ": got " + got + ", expected " + exp + " (tol " + tol + ")");
    }
    static void nearV(String msg, Vec2 got, Vec2 exp, double tol) {
        check(got.dist(exp) <= tol, msg + ": got " + got + ", expected " + exp + " (tol " + tol + ")");
    }

    /** Pure mirror physics: e = 1, no cushion friction. */
    static EngineConfig ideal() {
        return BASE.with("cushion.restitution", "1").with("cushion.friction", "0")
                   .with("collision.ball_ball_restitution", "1").with("guideline.mode", "geometric");
    }
    static class Env {
        final EngineConfig c; final Table t; final PathTracer tr; final ShotSimulator sim;
        final AimSolver aim; final BankScanner bank;
        Env(EngineConfig c) { this.c = c; t = new Table(c); sim = new ShotSimulator(c, t); tr = sim.tracer();
            aim = new AimSolver(c, t, sim); bank = new BankScanner(c, tr); }
    }
    static List<Ball> balls(Object... a) {
        List<Ball> l = new ArrayList<Ball>();
        for (int i = 0; i < a.length; i += 3) l.add(new Ball((String) a[i], new Vec2(((Number) a[i + 1]).doubleValue(), ((Number) a[i + 2]).doubleValue())));
        return l;
    }
    static double distToSegment(Vec2 p, Vec2 a, Vec2 b) {
        Vec2 ab = b.sub(a); double t = Math.max(0, Math.min(1, p.sub(a).dot(ab) / ab.dot(ab)));
        return p.dist(a.add(ab.mul(t)));
    }

    // ------------------------------------------------------------------ tests
    static void testConfig() throws Exception {
        check(BASE.ballRadius > 0, "config loaded");
        try { BASE.with("ball.radious", "1"); check(false, "typo key must be rejected"); } catch (IllegalArgumentException e) { check(true, ""); }
        try { BASE.with("cushion.restitution", "1.5"); check(false, "e>1 must be rejected"); } catch (IllegalArgumentException e) { check(true, ""); }
        try { BASE.with("guideline.mode", "fast"); check(false, "bad mode must be rejected"); } catch (IllegalArgumentException e) { check(true, ""); }
        try { BASE.with("pocket.side.mouth", "5000"); check(false, "overlapping pockets must be rejected"); } catch (IllegalArgumentException e) { check(true, ""); }
        Map<String, String> m = new LinkedHashMap<String, String>();
        for (String k : EngineConfig.KEYS) m.put(k, "1");
        try { EngineConfig.fromMap(m); check(false, "garbage config must be rejected"); } catch (IllegalArgumentException e) { check(true, ""); }
        m.remove("ball.radius");
        try { EngineConfig.fromMap(m); check(false, "missing key must be rejected"); } catch (IllegalArgumentException e) { check(true, ""); }
    }

    static void testGhostBallGeometry() {
        Env e = new Env(ideal()); double R = e.c.ballRadius;
        Pocket pk = e.t.pocketByName("tr");
        List<Ball> b = balls("cue", 600, 400, "1", 1800, 800);
        CueSolution s = e.aim.aimAtPocket(b, "cue", "1", pk, TraceOptions.fromConfig(e.c), 0);
        check(s.contactOk && s.pocketOk, "pocket shot valid: " + s.reason);
        Vec2 T = b.get(1).pos;
        near("ghost-to-target distance == 2R", s.ghost.dist(T), 2 * R, 1e-9);
        Vec2 objDir = pk.mid.sub(T).unit();
        near("ghost, target, pocket collinear (cross)", T.sub(s.ghost).unit().cross(objDir), 0, 1e-12);
        BallContact c = s.shot.contact;
        nearV("engine ghost == analytic ghost", c.ghost, s.ghost, 1e-7);
        near("contact point on cue ball surface", c.contactPoint.dist(c.ghost), R, 1e-9);
        near("contact point on target surface", c.contactPoint.dist(T), R, 1e-9);
        near("cut angle vs analytic", c.cutAngleDeg, Math.toDegrees(Math.acos(s.cueDir.dot(objDir))), 1e-9);
        check("tr".equals(pk.shortName) && "top_right".equals(s.shot.targetPocketName()), "object ball pocketed in top_right");
        check(s.windowComputed && s.windowPlusDeg > 0 && s.windowMinusDeg > 0, "aim window found: +" + s.windowPlusDeg + " -" + s.windowMinusDeg);
    }

    static void testStraightShotAndImpulses() {
        Env e = new Env(ideal());
        List<Ball> b = balls("cue", 500, 635, "1", 1500, 635);
        ShotResult r = e.sim.simulate(b, "cue", new Vec2(1, 0), 0, TraceOptions.fromConfig(e.c));
        check(r.contact != null, "straight shot makes contact");
        near("cue center at impact x = 1500-2R", r.contact.ghost.x, 1500 - 2 * e.c.ballRadius, 1e-9);
        near("contact point x = 1500-R", r.contact.contactPoint.x, 1500 - e.c.ballRadius, 1e-9);
        near("e=1 head-on: cue stops dead", r.contact.cueVelAfter.len(), 0, 1e-12);
        near("e=1 head-on: target takes all speed", r.contact.targetVelAfter.x, 1, 1e-12);
        near("cut angle 0", r.contact.cutAngleDeg, 0, 1e-9);

        Random rnd = new Random(7);
        for (int i = 0; i < 2000; i++) {
            double ang = rnd.nextDouble() * 360, ntheta = rnd.nextDouble() * 360;
            Vec2 v = Vec2.fromAngleDeg(ang).mul(0.5 + rnd.nextDouble() * 4), n = Vec2.fromAngleDeg(ntheta);
            if (v.dot(n) <= 1e-6) continue;
            Vec2[] a = Impulse.ballBall(v, new Vec2(0, 0), n, 1.0);
            check(a[0].add(a[1]).dist(v) < 1e-12, "momentum (e=1)");
            check(Math.abs(a[0].dot(a[0]) + a[1].dot(a[1]) - v.dot(v)) < 1e-9, "energy (e=1)");
            check(Math.abs(a[0].dot(a[1])) < 1e-9, "90-degree rule (e=1)");
            double eb = 0.95;
            Vec2[] b2 = Impulse.ballBall(v, new Vec2(0, 0), n, eb);
            check(b2[0].add(b2[1]).dist(v) < 1e-12, "momentum (e<1)");
            check(Math.abs(b2[1].sub(b2[0]).dot(n) - eb * v.dot(n)) < 1e-9, "restitution definition (e<1)");
            Vec2 t = new Vec2(-n.y, n.x);
            check(Math.abs(b2[0].dot(t) - v.dot(t)) < 1e-12, "tangential component conserved");
            check(Math.abs(b2[1].dot(t)) < 1e-12, "object ball moves along line of centers");
        }
    }

    // ---- independent analytic reference: unfold the table (mirror method), valid for e=1, mu=0
    static double fold(double u, double a) { double t = ((u % (2 * a)) + 2 * a) % (2 * a); return t <= a ? t : 2 * a - t; }
    /** Each crossing: {x, y, wall}; wall 0=left 1=right 2=bottom 3=top. */
    static List<double[]> analytic(EngineConfig c, Vec2 A, Vec2 d, int n) {
        double R = c.ballRadius, a = c.tableLength - 2 * R, b = c.tableWidth - 2 * R;
        double kx = d.x > 0 ? Math.floor((A.x - R) / a) + 1 : Math.ceil((A.x - R) / a) - 1;
        double ky = d.y > 0 ? Math.floor((A.y - R) / b) + 1 : Math.ceil((A.y - R) / b) - 1;
        List<double[]> out = new ArrayList<double[]>();
        for (int i = 0; i < n; i++) {
            double sx = Math.abs(d.x) < 1e-15 ? Double.POSITIVE_INFINITY : (R + kx * a - A.x) / d.x;
            double sy = Math.abs(d.y) < 1e-15 ? Double.POSITIVE_INFINITY : (R + ky * b - A.y) / d.y;
            double s = Math.min(sx, sy);
            double X = A.x + d.x * s, Y = A.y + d.y * s;
            double fx = R + fold(X - R, a), fy = R + fold(Y - R, b);
            int wall;
            if (sx <= sy) { wall = Math.abs(fx - R) < 1e-6 ? 0 : 1; kx += d.x > 0 ? 1 : -1; }
            else { wall = Math.abs(fy - R) < 1e-6 ? 2 : 3; ky += d.y > 0 ? 1 : -1; }
            out.add(new double[] { fx, fy, wall });
        }
        return out;
    }
    static final String[] WALL = { "left", "right", "bottom", "top" };
    /** Crossing must lie on a real cushion segment (not in a pocket mouth). */
    static boolean onCushion(Env e, double[] p) {
        double m = 1e-3, L = e.c.tableLength, W = e.c.tableWidth, tC = e.t.cornerTip, hS = e.t.sideHalfMouth;
        int w = (int) p[2];
        if (w <= 1) return p[1] >= tC + m && p[1] <= W - tC - m;
        double x = p[0];
        return (x >= tC + m && x <= L / 2 - hS - m) || (x >= L / 2 + hS + m && x <= L - tC - m);
    }

    static void testMirrorUnfolding() {
        Env e = new Env(ideal());
        Random rnd = new Random(12345);
        int[] used = new int[4];
        for (int i = 0; i < 40000; i++) {
            int n = 1 + rnd.nextInt(3);
            Vec2 A = new Vec2(e.c.ballRadius + rnd.nextDouble() * (e.c.tableLength - 2 * e.c.ballRadius),
                              e.c.ballRadius + rnd.nextDouble() * (e.c.tableWidth - 2 * e.c.ballRadius));
            Vec2 d = Vec2.fromAngleDeg(rnd.nextDouble() * 360);
            List<double[]> ref = analytic(e.c, A, d, n);
            boolean ok = true; for (double[] p : ref) if (!onCushion(e, p)) { ok = false; break; }
            if (!ok) continue;
            used[n]++;
            PathTrace t = e.tr.trace(A, d, new ArrayList<Ball>(), TraceOptions.fromConfig(e.c).withMaxCushions(n));
            List<PathEvent> cu = new ArrayList<PathEvent>();
            for (PathEvent ev : t.events) if (ev.kind == EventKind.CUSHION) cu.add(ev);
            if (cu.size() != n) { check(false, "expected " + n + " cushion events, got " + cu.size() + " (" + t.termination + ") A=" + A + " d=" + d.angleDeg()); continue; }
            for (int k = 0; k < n; k++) {
                if (cu.get(k).point.dist(new Vec2(ref.get(k)[0], ref.get(k)[1])) > 1e-6 || !cu.get(k).label.equals(WALL[(int) ref.get(k)[2]])) {
                    check(false, "bounce " + (k + 1) + "/" + n + " mismatch: engine " + cu.get(k).label + cu.get(k).point + " vs analytic " + WALL[(int) ref.get(k)[2]] + " (" + ref.get(k)[0] + "," + ref.get(k)[1] + ")");
                    break;
                } else pass++;
            }
        }
        check(used[1] > 1000 && used[2] > 1000 && used[3] > 500, "enough random cases per cushion count: " + used[1] + "/" + used[2] + "/" + used[3]);
        System.out.println("    compared " + used[1] + " one-cushion, " + used[2] + " two-cushion, " + used[3] + " three-cushion random shots against the mirror method");
    }

    static void testTimeReversal() {
        Env e = new Env(ideal()); Random rnd = new Random(99); int used = 0;
        for (int i = 0; i < 20000 && used < 3000; i++) {
            int n = 1 + rnd.nextInt(3);
            Vec2 A = new Vec2(e.c.ballRadius + rnd.nextDouble() * (e.c.tableLength - 2 * e.c.ballRadius),
                              e.c.ballRadius + rnd.nextDouble() * (e.c.tableWidth - 2 * e.c.ballRadius));
            Vec2 d = Vec2.fromAngleDeg(rnd.nextDouble() * 360);
            boolean ok = true; for (double[] p : analytic(e.c, A, d, n + 1)) if (!onCushion(e, p)) { ok = false; break; }
            if (!ok) continue;
            used++;
            TraceOptions o = TraceOptions.fromConfig(e.c).withMaxCushions(n);
            PathTrace f = e.tr.trace(A, d, new ArrayList<Ball>(), o);
            PathEvent lastC = f.events.get(n - 1);
            PathTrace r = e.tr.trace(f.endPoint(), lastC.dirAfter.mul(-1), new ArrayList<Ball>(), o);
            List<Vec2> p = r.points; int m = p.size();
            check(distToSegment(A, p.get(m - 2), p.get(m - 1)) < 1e-6, "time reversal returns to start (n=" + n + ")");
        }
    }

    static void testRestitutionAndFriction() {
        EngineConfig c = BASE.with("cushion.restitution", "0.8").with("cushion.friction", "0");
        Env e = new Env(c);
        double ang = 30; // heading down-right into the bottom cushion at 30 deg below horizontal... (angle -30)
        Vec2 A = new Vec2(300, 400), d = Vec2.fromAngleDeg(-ang);
        PathTrace t = e.tr.trace(A, d, new ArrayList<Ball>(), TraceOptions.fromConfig(c).withMaxCushions(1));
        PathEvent ev = t.events.get(0);
        near("tangential speed unchanged (mu=0)", ev.dirAfter.mul(ev.speedAfter).x, d.x, 1e-12);
        near("normal speed = e * incoming", ev.dirAfter.mul(ev.speedAfter).y, 0.8 * (-d.y), 1e-12);
        near("speed after", ev.speedAfter, Math.hypot(d.x, 0.8 * d.y), 1e-12);
        check(ev.speedAfter < ev.speedBefore, "cushion removes speed");

        Vec2 v = Impulse.cushion(new Vec2(1, -1), new Vec2(0, 1), 0.8, 0.1);
        near("friction loss = mu(1+e)|vn| = 0.18", v.x, 1 - 0.18, 1e-12);
        near("friction keeps restitution", v.y, 0.8, 1e-12);
        Vec2 w = Impulse.cushion(new Vec2(0.05, -1), new Vec2(0, 1), 0.8, 0.5);
        near("friction cannot reverse tangential motion", w.x, 0, 1e-12);
        Random rnd = new Random(3);
        for (int i = 0; i < 2000; i++) {                       // a cushion never adds energy
            Vec2 n = Vec2.fromAngleDeg(rnd.nextDouble() * 360), vin = Vec2.fromAngleDeg(rnd.nextDouble() * 360).mul(rnd.nextDouble() * 5);
            if (vin.dot(n) >= 0) continue;
            Vec2 out = Impulse.cushion(vin, n, 0.3 + 0.7 * rnd.nextDouble(), rnd.nextDouble());
            check(out.len() <= vin.len() + 1e-12 && out.dot(n) >= 0, "cushion output is energy-bounded and leaves the wall");
        }
    }

    static void testPocketsAndKnuckles() {
        Env e = new Env(ideal()); double R = e.c.ballRadius, L = e.c.tableLength, hS = e.t.sideHalfMouth, tC = e.t.cornerTip;
        TraceOptions o = TraceOptions.fromConfig(e.c).withMaxCushions(0);
        PathTrace t = e.tr.trace(new Vec2(400, 400), Vec2.fromAngleDeg(225), new ArrayList<Ball>(), o);
        check("bottom_left".equals(t.pocketName()), "diagonal into bottom-left corner pocket: " + t.termination);
        nearV("crosses the gate at its midpoint", t.endPoint(), e.t.pocketByName("bl").mid, 1e-9);
        double lim = hS - R;   // vertical path into the side pocket: clear iff |dx| <= hS-R (center stays R from the tips)
        for (int sgn = -1; sgn <= 1; sgn += 2) {
            PathTrace in = e.tr.trace(new Vec2(L / 2 + sgn * (lim - 1e-6), 635), new Vec2(0, -1), new ArrayList<Ball>(), o);
            check("bottom_mid".equals(in.pocketName()), "side pocket accepts |dx|=hS-R-1e-6 (" + sgn + "): " + in.termination);
            PathTrace out = e.tr.trace(new Vec2(L / 2 + sgn * (lim + 1e-6), 635), new Vec2(0, -1), new ArrayList<Ball>(), o.withMaxCushions(1));
            check(out.events.size() > 0 && out.events.get(0).kind == EventKind.TIP, "side pocket rejects |dx|=hS-R+1e-6 (knuckle hit): " + out.termination);
        }
        // knuckle bounce direction: normal must be (center - tip)/R
        PathTrace k = e.tr.trace(new Vec2(L / 2 + lim + 5, 635), new Vec2(0, -1), new ArrayList<Ball>(), o.withMaxCushions(1));
        PathEvent ke = k.events.get(0);
        Vec2 tip = new Vec2(L / 2 + hS, 0);
        near("knuckle contact: center is R from tip", ke.point.dist(tip), R, 1e-9);
        nearV("knuckle normal = (center-tip)/R", ke.normal, ke.point.sub(tip).mul(1 / R), 1e-12);
        // corner mouth: along the bottom rail toward the corner, a ball hugging the rail must hit the jaw tip
        PathTrace hug = e.tr.trace(new Vec2(600, R), new Vec2(-1, 0), new ArrayList<Ball>(), o.withMaxCushions(1));
        check(hug.events.size() > 0, "ball hugging the rail toward the corner interacts with the jaw");
    }

    static void testLegalPositions() {
        Env e = new Env(ideal()); double R = e.c.ballRadius, L = e.c.tableLength;
        check(e.t.inPlayfield(new Vec2(1270, 635), 0), "table center is legal");
        check(!e.t.inPlayfield(new Vec2(R - 1, 635), 0), "inside the cushion is illegal");
        check(!e.t.inPlayfield(new Vec2(L - R + 0.1, 635), 0), "beyond the right cushion line is illegal");
        check(!e.t.inPlayfield(new Vec2(R + 1, R + 1), 0), "ball center in the corner pocket mouth is illegal");
        check(!e.t.inPlayfield(new Vec2(L - R - 5, R + 3), 0), "bottom-right pocket mouth is illegal");
        check(e.t.inPlayfield(new Vec2(150, 150), 0), "ball just in front of the corner pocket is legal");
    }

    static void testBlockingAndBallBallPaths() {
        Env e = new Env(ideal());
        List<Ball> b = balls("cue", 500, 635, "blocker", 1000, 635, "1", 1500, 635);
        ShotResult r = e.sim.simulate(b, "cue", new Vec2(1, 0), 0, TraceOptions.fromConfig(e.c));
        check(r.contact != null && r.contact.targetId.equals("blocker"), "first ball in line is hit");
        Pocket tm = e.t.pocketByName("tm");
        List<Ball> b2 = balls("cue", 800, 300, "1", 1270, 800, "x", 1270, 1050);
        CueSolution s = e.aim.aimAtPocket(b2, "cue", "1", tm, TraceOptions.fromConfig(e.c), 0);
        check(!s.pocketOk && s.reason.length() > 0, "blocked pocket shot is reported invalid: " + s.reason);
        CueSolution s2 = e.aim.aimAtPocket(balls("cue", 1270, 500, "1", 1270, 800), "cue", "1", e.t.pocketByName("bm"), TraceOptions.fromConfig(e.c), 0);
        check(!s2.pocketOk, "cut >= 90 / wrong side shot rejected: " + s2.reason);
    }

    static void testDynamicStopDistance() {
        EngineConfig c = BASE.with("cushion.restitution", "1").with("cushion.friction", "0")
                             .with("guideline.mode", "dynamic").with("guideline.max_path_length", "1000000");
        Env e = new Env(c);
        double v0 = 1000, a = c.rollingFriction * c.gravity, expect = v0 * v0 / (2 * a);
        PathTrace t = e.tr.trace(new Vec2(300, 635), new Vec2(v0, 0), new ArrayList<Ball>(), TraceOptions.fromConfig(c).withMaxCushions(100));
        check(t.termination == Termination.STOPPED, "ball stops: " + t.termination);
        near("total path = v^2/(2a) with e=1", t.length, expect, 1e-6);
        EngineConfig c2 = c.with("cushion.restitution", "0.8");
        Env e2 = new Env(c2);
        PathTrace t2 = e2.tr.trace(new Vec2(300, 635), new Vec2(v0, 0), new ArrayList<Ball>(), TraceOptions.fromConfig(c2).withMaxCushions(100));
        check(t2.termination == Termination.STOPPED && t2.length < expect, "restitution < 1 shortens the path: " + t2.length);
        // analytic: sum of legs with speed^2 -> speed^2 - 2 a s, and v -> 0.8 v at each wall (head-on, 1-D)
        double v = v0, x = 300, dir = 1, total = 0;
        double lo = c.ballRadius, hi = c.tableLength - c.ballRadius;
        while (true) {
            double wall = dir > 0 ? hi - x : x - lo;
            double stop = v * v / (2 * a);
            if (stop <= wall) { total += stop; break; }
            total += wall; v = Math.sqrt(v * v - 2 * a * wall) * 0.8; x = dir > 0 ? hi : lo; dir = -dir;
        }
        near("1-D bouncing path vs closed form (e=0.8)", t2.length, total, 1e-6);
    }

    static void testBankScanner() {
        Env e = new Env(ideal());
        List<Ball> obs = new ArrayList<Ball>();
        Vec2 start = new Vec2(1500, 400);
        for (int n = 1; n <= 3; n++) {
            List<BankSolution> sols = e.bank.scan(start, obs, n, null, TraceOptions.fromConfig(e.c));
            check(!sols.isEmpty(), n + "-cushion bank solutions exist");
            for (BankSolution s : sols) {
                TraceOptions o = TraceOptions.fromConfig(e.c).withMaxCushions(n);
                PathTrace mid = e.tr.trace(start, Vec2.fromAngleDeg(s.angleCenterDeg), obs, o);
                check(s.pocket.equals(mid.pocketName()) && mid.cushionCount == n, "center of window pockets after " + n);
                if (s.widthDeg() < 1e-3) continue;
                double w = Math.min(1e-4, s.widthDeg() / 4);
                PathTrace in1 = e.tr.trace(start, Vec2.fromAngleDeg(s.angleMinDeg + w), obs, o);
                PathTrace in2 = e.tr.trace(start, Vec2.fromAngleDeg(s.angleMaxDeg - w), obs, o);
                check(s.pocket.equals(in1.pocketName()) && s.pocket.equals(in2.pocketName()), "just inside both edges still pockets");
                PathTrace o1 = e.tr.trace(start, Vec2.fromAngleDeg(s.angleMinDeg - w), obs, o);
                PathTrace o2 = e.tr.trace(start, Vec2.fromAngleDeg(s.angleMaxDeg + w), obs, o);
                boolean same1 = s.pocket.equals(o1.pocketName()) && o1.cushionCount == n && o1.events.size() == mid.events.size();
                boolean same2 = s.pocket.equals(o2.pocketName()) && o2.cushionCount == n && o2.events.size() == mid.events.size();
                check(!(same1 && sameRails(o1, mid)) && !(same2 && sameRails(o2, mid)), "just outside both edges the route changes");
            }
        }
        // mirror method must agree for a 1-cushion bank into the top-right corner:
        // image of the gate midpoint across the bottom center-line y=R must lie inside the angular window
        Pocket tr = e.t.pocketByName("tr"); double R = e.c.ballRadius;
        List<BankSolution> s1 = e.bank.scan(start, obs, 1, "top_right", TraceOptions.fromConfig(e.c));
        boolean found = false;
        for (BankSolution s : s1) {
            if (!s.rails.get(0).equals("bottom")) continue;
            Vec2 img = new Vec2(tr.mid.x, 2 * R - tr.mid.y);
            double ang = img.sub(start).angleDeg(); while (ang < s.angleMinDeg - 180) ang += 360; while (ang > s.angleMinDeg + 180) ang -= 360;
            found = true;
            check(ang >= s.angleMinDeg - 1e-9 && ang <= s.angleMaxDeg + 1e-9, "mirror-image aim at the gate midpoint lies inside the solver window");
        }
        System.out.println("    bottom->top_right 1-cushion window found: " + found);
    }
    static boolean sameRails(PathTrace a, PathTrace b) {
        if (a.events.size() != b.events.size()) return false;
        for (int i = 0; i < a.events.size(); i++) if (!a.events.get(i).label.equals(b.events.get(i).label)) return false;
        return true;
    }

    static void testBankCueSolution() {
        Env e = new Env(ideal());
        List<Ball> b = balls("cue", 500, 300, "1", 1500, 400);
        List<Ball> obs = new ArrayList<Ball>();
        List<BankSolution> sols = e.bank.scan(b.get(1).pos, obs, 1, null, TraceOptions.fromConfig(e.c));
        int ok = 0;
        for (BankSolution s : sols) {
            CueSolution c = e.aim.evaluate(b, "cue", "1", Vec2.fromAngleDeg(s.angleCenterDeg), s.pocket, 1, TraceOptions.fromConfig(e.c), 0);
            if (c.pocketOk) ok++;
        }
        check(ok > 0, "at least one 1-cushion bank is fully verified through the cue ball (" + ok + "/" + sols.size() + ")");
    }

    static void testRandomInvariants() {
        EngineConfig c = BASE.with("cushion.friction", "0.15");
        Env e = new Env(c); Random rnd = new Random(2024); double R = c.ballRadius;
        int escaped = 0, outside = 0, gain = 0, runs = 20000, skippedStart = 0;
        for (int i = 0; i < runs; i++) {
            Vec2 A = new Vec2(R + rnd.nextDouble() * (c.tableLength - 2 * R), R + rnd.nextDouble() * (c.tableWidth - 2 * R));
            if (!e.t.inPlayfield(A, 0)) { skippedStart++; continue; }
            List<Ball> obs = new ArrayList<Ball>();
            int nb = rnd.nextInt(4);
            for (int k = 0; k < nb; k++) {
                Vec2 p = new Vec2(R + rnd.nextDouble() * (c.tableLength - 2 * R), R + rnd.nextDouble() * (c.tableWidth - 2 * R));
                boolean clash = p.dist(A) < 2 * R + 1e-6; for (Ball o : obs) if (o.pos.dist(p) < 2 * R + 1e-6) clash = true;
                if (!clash && e.t.inPlayfield(p, 0)) obs.add(new Ball("o" + k, p));
            }
            PathTrace t = e.tr.trace(A, Vec2.fromAngleDeg(rnd.nextDouble() * 360), obs, TraceOptions.fromConfig(c).withMaxCushions(8));
            if (t.termination == Termination.ESCAPED) escaped++;
            for (Vec2 p : t.points) if (p.x < -1e-6 || p.x > c.tableLength + 1e-6 || p.y < -1e-6 || p.y > c.tableWidth + 1e-6) outside++;
            for (PathEvent ev : t.events) if (ev.speedAfter > ev.speedBefore + 1e-12) gain++;
        }
        check(escaped == 0, "no trace escapes the table (" + escaped + " of " + runs + ")");
        check(outside == 0, "no trace point leaves the table rectangle (" + outside + ")");
        check(gain == 0, "speed never increases at an event (" + gain + ")");
        System.out.println("    " + skippedStart + " illegal start positions (inside a pocket mouth) skipped");
    }

    // ------------------------------------------------------------------ main
    interface T { void run() throws Exception; }
    static void run(String name, T t) {
        int f0 = fail, p0 = pass;
        System.out.println("[ " + name + " ]");
        try { t.run(); } catch (Throwable x) { fail++; System.out.println("    EXCEPTION: " + x); x.printStackTrace(System.out); }
        System.out.println("    " + (pass - p0) + " checks passed" + (fail > f0 ? ", " + (fail - f0) + " FAILED" : ""));
    }

    public static void main(String[] args) throws Exception {
        BASE = EngineConfig.load(Paths.get(args.length > 0 ? args[0] : "config/billiards_config.properties"));
        run("config validation", new T() { public void run() throws Exception { testConfig(); } });
        run("ghost-ball geometry / contact point", new T() { public void run() { testGhostBallGeometry(); } });
        run("straight shot + collision impulses (momentum, energy, 90-degree rule)", new T() { public void run() { testStraightShotAndImpulses(); } });
        run("1/2/3 cushion paths vs independent mirror (unfolding) method", new T() { public void run() { testMirrorUnfolding(); } });
        run("time reversal of multi-cushion paths", new T() { public void run() { testTimeReversal(); } });
        run("cushion restitution + friction model", new T() { public void run() { testRestitutionAndFriction(); } });
        run("pockets and jaw-tip knuckles", new T() { public void run() { testPocketsAndKnuckles(); } });
        run("legal ball positions", new T() { public void run() { testLegalPositions(); } });
        run("blocking balls / invalid shots", new T() { public void run() { testBlockingAndBallBallPaths(); } });
        run("dynamic mode stop distance vs closed form", new T() { public void run() { testDynamicStopDistance(); } });
        run("bank scanner (1/2/3 cushions)", new T() { public void run() { testBankScanner(); } });
        run("bank -> cue-ball solution verified by full simulation", new T() { public void run() { testBankCueSolution(); } });
        run("randomized invariants (20000 traces, e<1, mu>0)", new T() { public void run() { testRandomInvariants(); } });
        TrainerTests.BASE = BASE;
        run("trainer: viewport math", new T() { public void run() { TrainerTests.viewport(); } });
        run("trainer: polyline clipping (ray length)", new T() { public void run() { TrainerTests.clip(); } });
        run("trainer: legal drag & drop moves", new T() { public void run() { TrainerTests.legalMoves(); } });
        run("trainer: add / remove balls", new T() { public void run() { TrainerTests.addRemove(); } });
        run("trainer: FREE mode, 0..8 cushions, aim controls", new T() { public void run() { TrainerTests.freeMode(); } });
        run("trainer: POCKET mode, aim window vs full simulation", new T() { public void run() { TrainerTests.pocketMode(); } });
        run("trainer: BANK mode 1/2/3 cushions", new T() { public void run() { TrainerTests.bankMode(); } });
        run("trainer: dynamic (power + friction) mode", new T() { public void run() { TrainerTests.dynamicMode(); } });
        run("trainer: save / load + corrupt input", new T() { public void run() { TrainerTests.persistence(); } });
        run("trainer: scene toggles, ray length, screen sizes", new T() { public void run() { TrainerTests.sceneToggles(); } });
        run("trainer: random UI fuzz (4000 operations)", new T() { public void run() { TrainerTests.fuzz(); } });
        run("trainer: timing", new T() { public void run() { TrainerTests.timing(); } });
        System.out.println("\n==== " + pass + " checks passed, " + fail + " failed ====");
        System.exit(fail == 0 ? 0 : 1);
    }
}
