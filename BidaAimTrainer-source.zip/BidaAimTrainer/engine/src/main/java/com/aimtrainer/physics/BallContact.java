package com.aimtrainer.physics;

import com.aimtrainer.geom.Vec2;

/** Result of the cue ball hitting an object ball. */
public final class BallContact {
    public final String targetId;
    public final Vec2 ghost;           // cue ball center at impact ("ghost ball")
    public final Vec2 contactPoint;    // point where the two ball surfaces touch
    public final Vec2 normal;          // unit vector cue -> target (line of centers)
    public final double cutAngleDeg;   // angle between cue direction and line of centers
    public final String cutSide;       // "left", "right" or "straight" (side the object ball is cut toward)
    public final double speedAtImpact;
    public final Vec2 cueVelAfter, targetVelAfter;
    public BallContact(String targetId, Vec2 ghost, Vec2 contactPoint, Vec2 normal, double cutAngleDeg, String cutSide,
                       double speedAtImpact, Vec2 cueVelAfter, Vec2 targetVelAfter) {
        this.targetId = targetId; this.ghost = ghost; this.contactPoint = contactPoint; this.normal = normal;
        this.cutAngleDeg = cutAngleDeg; this.cutSide = cutSide; this.speedAtImpact = speedAtImpact;
        this.cueVelAfter = cueVelAfter; this.targetVelAfter = targetVelAfter;
    }
}
