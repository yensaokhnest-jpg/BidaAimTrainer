package com.aimtrainer.guideline;

import com.aimtrainer.geom.Vec2;
import com.aimtrainer.physics.ShotResult;

/** Cue aim computed for a desired object-ball direction, verified by full simulation. */
public final class CueSolution {
    public Vec2 ghost;               // cue-ball center at impact
    public Vec2 cueDir;              // unit aim direction of the cue ball
    public double cutAngleDeg;       // angle between cue direction and object-ball direction
    public boolean contactOk;        // cue really hits the intended object ball at the ghost position
    public boolean pocketOk;         // object ball really ends in the expected pocket (and cushion count)
    public String reason = "";       // why contactOk/pocketOk is false
    public ShotResult shot;          // full simulation (null if it could not be run)
    public double windowPlusDeg, windowMinusDeg;   // aim tolerance (CCW / CW) that still pockets the ball
    public boolean windowComputed;
}
