package com.aimtrainer.trainer;

import com.aimtrainer.geom.Vec2;
import java.util.ArrayList;
import java.util.List;

public final class PolylineClip {
    private PolylineClip() {}

    public static double length(List<Vec2> pts) {
        double t = 0;
        for (int i = 1; i < pts.size(); i++) t += pts.get(i).dist(pts.get(i - 1));
        return t;
    }

    /** Returns the part of the polyline within maxLen of its start (cut exactly at maxLen). */
    public static List<Vec2> clip(List<Vec2> pts, double maxLen) {
        List<Vec2> out = new ArrayList<Vec2>();
        if (pts.isEmpty()) return out;
        out.add(pts.get(0));
        double left = maxLen;
        for (int i = 1; i < pts.size(); i++) {
            Vec2 a = pts.get(i - 1), b = pts.get(i);
            double seg = a.dist(b);
            if (seg <= left) { out.add(b); left -= seg; }
            else {
                if (left > 0 && seg > 0) out.add(a.add(b.sub(a).mul(left / seg)));
                break;
            }
        }
        return out;
    }
}
