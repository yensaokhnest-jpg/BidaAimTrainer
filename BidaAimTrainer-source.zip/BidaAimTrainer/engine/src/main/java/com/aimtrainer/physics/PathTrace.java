package com.aimtrainer.physics;

import com.aimtrainer.collision.RayHit;
import com.aimtrainer.geom.Vec2;
import java.util.List;

public final class PathTrace {
    public final List<Vec2> points;
    public final List<PathEvent> events;
    public final Termination termination;
    public final double length;
    public final RayHit endHit;       // BALL_HIT / POCKETED / MAX_CUSHIONS: the hit that ended the trace
    public final double endSpeed;
    public final Vec2 endDir;         // direction of travel when the trace ended
    public final int cushionCount;
    public PathTrace(List<Vec2> points, List<PathEvent> events, Termination termination, double length,
                     RayHit endHit, double endSpeed, Vec2 endDir, int cushionCount) {
        this.points = points; this.events = events; this.termination = termination; this.length = length;
        this.endHit = endHit; this.endSpeed = endSpeed; this.endDir = endDir; this.cushionCount = cushionCount;
    }
    public Vec2 endPoint() { return points.get(points.size() - 1); }
    /** Name of the pocket if the ball was pocketed, else null. */
    public String pocketName() {
        return termination == Termination.POCKETED ? endHit.pocket.name : null;
    }
}
