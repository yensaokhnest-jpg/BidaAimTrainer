package com.aimtrainer.collision;
public enum HitType { BALL, CUSHION, TIP, POCKET }
