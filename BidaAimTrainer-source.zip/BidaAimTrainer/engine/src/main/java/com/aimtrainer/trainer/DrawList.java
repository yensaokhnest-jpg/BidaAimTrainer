package com.aimtrainer.trainer;

import java.util.ArrayList;
import java.util.List;

/**
 * Platform-independent drawing commands in SCREEN pixels. The Android view and the PNG preview both
 * just replay this list, so the drawing logic can be tested on a normal JVM.
 */
public final class DrawList {
    public static final int RECT = 0, LINE = 1, POLY = 2, CIRCLE = 3, TEXT = 4;
    public static final int LEFT = 0, CENTER = 1, RIGHT = 2;

    public static final class Prim {
        public int kind;
        public double[] x, y;        // RECT: x1,y1,x2,y2 | LINE: 2 pts | POLY: n pts | CIRCLE/TEXT: 1 pt
        public double r;
        public int fill, stroke;     // ARGB, 0 = none
        public double width;         // stroke width (px)
        public boolean dash;
        public String text;
        public double size;          // text size (px)
        public int align;
        public String tag = "";
    }

    public final List<Prim> items = new ArrayList<Prim>();

    private Prim add(int kind, String tag) { Prim p = new Prim(); p.kind = kind; p.tag = tag; items.add(p); return p; }

    public void rect(double x1, double y1, double x2, double y2, int fill, int stroke, double width, String tag) {
        Prim p = add(RECT, tag); p.x = new double[] { x1, x2 }; p.y = new double[] { y1, y2 };
        p.fill = fill; p.stroke = stroke; p.width = width;
    }
    public void line(double x1, double y1, double x2, double y2, int stroke, double width, boolean dash, String tag) {
        Prim p = add(LINE, tag); p.x = new double[] { x1, x2 }; p.y = new double[] { y1, y2 };
        p.stroke = stroke; p.width = width; p.dash = dash;
    }
    public void poly(double[] x, double[] y, int stroke, double width, boolean dash, String tag) {
        Prim p = add(POLY, tag); p.x = x; p.y = y; p.stroke = stroke; p.width = width; p.dash = dash;
    }
    public void circle(double cx, double cy, double r, int fill, int stroke, double width, boolean dash, String tag) {
        Prim p = add(CIRCLE, tag); p.x = new double[] { cx }; p.y = new double[] { cy }; p.r = r;
        p.fill = fill; p.stroke = stroke; p.width = width; p.dash = dash;
    }
    public void text(double x, double y, String s, int color, double size, int align, String tag) {
        Prim p = add(TEXT, tag); p.x = new double[] { x }; p.y = new double[] { y };
        p.text = s; p.fill = color; p.size = size; p.align = align;
    }
    public int count(String tag) { int n = 0; for (Prim p : items) if (p.tag.equals(tag)) n++; return n; }
}
