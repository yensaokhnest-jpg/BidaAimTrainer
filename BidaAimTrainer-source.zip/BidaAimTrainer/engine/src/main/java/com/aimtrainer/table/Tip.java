package com.aimtrainer.table;

import com.aimtrainer.geom.Vec2;

/** Jaw tip (cushion end): a point obstacle the ball center must stay one radius away from. */
public final class Tip {
    public final Vec2 pos;
    public final Pocket pocket;
    public Tip(Vec2 pos, Pocket pocket) { this.pos = pos; this.pocket = pocket; }
}
