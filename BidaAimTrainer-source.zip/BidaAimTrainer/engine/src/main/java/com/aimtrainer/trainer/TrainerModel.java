package com.aimtrainer.trainer;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.guideline.*;
import com.aimtrainer.physics.*;
import com.aimtrainer.table.Pocket;
import com.aimtrainer.table.Table;
import java.util.*;

/**
 * All trainer state and behaviour, with NO Android dependency (so it is unit-tested on a plain JVM).
 * Fast work (one shot simulation) happens in frame(); slow work (aim window, bank sweep) is split
 * into HeavyJob objects that can run on a background thread and be accepted if still current.
 */
public final class TrainerModel {
    public static final String CUE = "cue";
    public static final int MAX_OBJECT_BALLS = 4;

    private final EngineConfig base;
    private EngineConfig cfg;
    private Table table;
    private ShotSimulator sim;
    private AimSolver aim;
    private BankScanner bankScanner;

    private final TrainerSettings s = new TrainerSettings();
    private final List<Ball> balls = new ArrayList<Ball>();
    private String targetId = "1";
    private String pocketName = "top_right";
    private TrainerMode mode = TrainerMode.FREE;
    private double freeAngleDeg = 0, offsetDeg = 0;
    private int bankIndex = 0;
    private int version = 0;

    // cached slow results (valid only while *Version == version)
    private int routesVersion = -1, windowVersion = -1;
    private List<BankRoute> routes = Collections.emptyList();
    private boolean windowKnown;
    private double windowPlus, windowMinus;

    public TrainerModel(EngineConfig base) {
        this.base = base;
        s.cushionRestitution = base.cushionRestitution;
        s.cushionFriction = base.cushionFriction;
        s.ballRestitution = base.ballBallRestitution;
        rebuild();
        resetLayout();
    }

    // ------------------------------------------------------------------ engine (re)build
    private void rebuild() {
        s.clamp();
        EngineConfig c = base
            .with("guideline.max_cushions", Integer.toString(s.maxCushions))
            .with("guideline.max_path_length", "200000")      // physics is never length-limited; display clips
            .with("guideline.mode", s.dynamic ? "dynamic" : "geometric")
            .with("guideline.default_speed", Double.toString(s.power))
            .with("cushion.restitution", Double.toString(s.cushionRestitution))
            .with("cushion.friction", Double.toString(s.cushionFriction))
            .with("collision.ball_ball_restitution", Double.toString(s.ballRestitution));
        cfg = c;
        table = new Table(c);
        sim = new ShotSimulator(c, table);
        aim = new AimSolver(c, table, sim);
        bankScanner = new BankScanner(c, sim.tracer());
    }

    /** Call after changing a physics-affecting setting (cushions, dynamic, power, e, mu). */
    public void physicsSettingsChanged() { rebuild(); touch(); }
    /** Call after changing a display-only setting. Cheap; no recomputation of slow results. */
    public void displaySettingsChanged() { s.clamp(); }

    private void touch() { version++; }

    // ------------------------------------------------------------------ accessors
    public EngineConfig config() { return cfg; }
    public Table table() { return table; }
    public TrainerSettings settings() { return s; }
    public TrainerMode mode() { return mode; }
    public String targetId() { return targetId; }
    public String pocketName() { return pocketName; }
    public int bankIndex() { return bankIndex; }
    public int version() { return version; }
    public double freeAngleDeg() { return freeAngleDeg; }
    public double offsetDeg() { return offsetDeg; }
    public List<Ball> balls() { return Collections.unmodifiableList(balls); }
    public Ball ball(String id) { return ShotSimulator.find(balls, id); }
    public Vec2 pocketCenter(Pocket p) { return p.mid.sub(p.inward.mul(0.35 * p.len)); }

    // ------------------------------------------------------------------ layout
    public void resetLayout() {
        balls.clear();
        balls.add(new Ball(CUE, new Vec2(0.28 * cfg.tableLength, 0.5 * cfg.tableWidth)));
        balls.add(new Ball("1", new Vec2(0.66 * cfg.tableLength, 0.38 * cfg.tableWidth)));
        targetId = "1";
        offsetDeg = 0; bankIndex = 0;
        freeAngleDeg = balls.get(1).pos.sub(balls.get(0).pos).angleDeg();
        touch();
    }

    private boolean isLegal(String id, Vec2 p) {
        if (!table.inPlayfield(p, 1e-9)) return false;
        for (Ball b : balls) if (!b.id.equals(id) && b.pos.dist(p) < 2 * cfg.ballRadius - 1e-6) return false;
        return true;
    }

    private Vec2 clampBox(Vec2 p) {
        double R = cfg.ballRadius;
        return new Vec2(Math.max(R, Math.min(cfg.tableLength - R, p.x)), Math.max(R, Math.min(cfg.tableWidth - R, p.y)));
    }

    private Vec2 outOfPocketZone(Vec2 q) {
        if (table.inPlayfield(q, 0)) return q;
        Vec2 c = new Vec2(cfg.tableLength / 2, cfg.tableWidth / 2);
        double lo = 0, hi = 1;
        for (int i = 0; i < 50; i++) {
            double t = (lo + hi) / 2;
            if (table.inPlayfield(q.add(c.sub(q).mul(t)), 0)) hi = t; else lo = t;
        }
        return q.add(c.sub(q).mul(hi));
    }

    /** Nearest legal center for ball id (inside cushions, outside pocket mouths, not overlapping). null if none found. */
    public Vec2 legalize(String id, Vec2 p) {
        double R = cfg.ballRadius;
        Vec2 q = clampBox(p);
        for (int it = 0; it < 12; it++) {
            q = outOfPocketZone(q);
            boolean moved = false;
            for (Ball b : balls) {
                if (b.id.equals(id)) continue;
                double d = q.dist(b.pos);
                if (d < 2 * R - 1e-9) {
                    Vec2 dir = d > 1e-9 ? q.sub(b.pos).mul(1.0 / d) : new Vec2(1, 0);
                    q = clampBox(b.pos.add(dir.mul(2 * R)));
                    moved = true;
                }
            }
            if (!moved) break;
        }
        return isLegal(id, q) ? q : null;
    }

    public boolean moveBall(String id, Vec2 p) {
        Vec2 q = legalize(id, p);
        if (q == null) return false;
        for (int i = 0; i < balls.size(); i++)
            if (balls.get(i).id.equals(id)) { balls.set(i, new Ball(id, q)); touch(); return true; }
        return false;
    }

    /** id of the ball whose disc (plus tol) contains the table point p, nearest first; null if none. */
    public String pickBall(Vec2 p, double tol) {
        String best = null; double bd = Double.MAX_VALUE;
        for (Ball b : balls) {
            double d = b.pos.dist(p);
            if (d <= cfg.ballRadius + tol && d < bd) { bd = d; best = b.id; }
        }
        return best;
    }

    /** Pocket whose drawn hole is within tol of p; null if none. */
    public String pickPocket(Vec2 p, double tol) {
        String best = null; double bd = Double.MAX_VALUE;
        for (Pocket k : table.pockets) {
            double d = pocketCenter(k).dist(p);
            if (d <= 0.6 * k.len + tol && d < bd) { bd = d; best = k.name; }
        }
        return best;
    }

    public int objectBallCount() { return balls.size() - 1; }

    public String addObjectBall() {
        if (objectBallCount() >= MAX_OBJECT_BALLS) return null;
        String id = null;
        for (int i = 1; i <= MAX_OBJECT_BALLS; i++) {
            boolean used = false;
            for (Ball b : balls) if (b.id.equals(Integer.toString(i))) used = true;
            if (!used) { id = Integer.toString(i); break; }
        }
        if (id == null) return null;
        double[] fx = { 0.50, 0.75, 0.40, 0.85, 0.60, 0.30 }, fy = { 0.62, 0.30, 0.25, 0.65, 0.80, 0.72 };
        for (int i = 0; i < fx.length; i++) {
            Vec2 p = new Vec2(fx[i] * cfg.tableLength, fy[i] * cfg.tableWidth);
            boolean far = true;
            for (Ball b : balls) if (b.pos.dist(p) < 3 * cfg.ballRadius) far = false;
            if (far && isLegal(id, p)) { balls.add(new Ball(id, p)); touch(); return id; }
        }
        return null;
    }

    public boolean removeBall(String id) {
        if (id.equals(CUE) || objectBallCount() <= 1) return false;
        for (Iterator<Ball> it = balls.iterator(); it.hasNext();)
            if (it.next().id.equals(id)) it.remove();
        if (targetId.equals(id)) for (Ball b : balls) if (!b.id.equals(CUE)) { targetId = b.id; break; }
        touch();
        return true;
    }

    public void selectTarget(String id) {
        if (id == null || id.equals(CUE)) return;
        for (Ball b : balls) if (b.id.equals(id)) { targetId = id; offsetDeg = 0; bankIndex = 0; touch(); }
    }

    // ------------------------------------------------------------------ mode / aim
    public void setMode(TrainerMode m) {
        if (m == mode) return;
        mode = m; offsetDeg = 0; bankIndex = 0; touch();
    }

    /** Choose a pocket. In FREE mode this switches to POCKET mode. */
    public void selectPocket(String name) {
        if (table.pocketByName(name) == null) return;
        pocketName = table.pocketByName(name).name;
        if (mode == TrainerMode.FREE) mode = TrainerMode.POCKET;
        offsetDeg = 0; bankIndex = 0; touch();
    }

    public void setBankCushions(int n) { s.bankCushions = n; s.clamp(); bankIndex = 0; offsetDeg = 0; touch(); }
    public void setBankAnyPocket(boolean any) { s.bankAnyPocket = any; bankIndex = 0; offsetDeg = 0; touch(); }

    public void setFreeAngle(double deg) { freeAngleDeg = norm(deg); }

    private static double norm(double a) { return ((a + 180) % 360 + 360) % 360 - 180; }

    private static final double MAX_OFFSET = 20.0;

    /** Aim the cue ball toward table point p (FREE: absolute angle; others: offset from the ideal aim). */
    public void aimToward(Vec2 p) {
        Vec2 d = p.sub(ball(CUE).pos);
        if (d.len() < 1e-6) return;
        double a = d.angleDeg();
        if (mode == TrainerMode.FREE) freeAngleDeg = a;
        else offsetDeg = Math.max(-MAX_OFFSET, Math.min(MAX_OFFSET, norm(a - baseAngle())));
    }

    public void nudge(double deltaDeg) {
        if (mode == TrainerMode.FREE) freeAngleDeg = norm(freeAngleDeg + deltaDeg);
        else offsetDeg = Math.max(-MAX_OFFSET, Math.min(MAX_OFFSET, offsetDeg + deltaDeg));
    }

    public void setOffset(double deg) { offsetDeg = Math.max(-MAX_OFFSET, Math.min(MAX_OFFSET, deg)); }
    public void resetOffset() { offsetDeg = 0; }

    public void nextBank(int delta) {
        if (routesVersion != version || routes.isEmpty()) return;
        int n = routes.size();
        bankIndex = ((bankIndex + delta) % n + n) % n;
        offsetDeg = 0;
    }

    /** The "ideal" aim angle of the current mode (POCKET: ghost-ball line, BANK: selected route, FREE: current). */
    private double baseAngle() {
        TraceOptions o = effectiveOpts();
        if (mode == TrainerMode.POCKET) {
            CueSolution c = aim.aimAtPocket(balls, CUE, targetId, table.pocketByName(pocketName), o, speed(), false);
            if (c.cueDir != null) return c.cueDir.angleDeg();
        } else if (mode == TrainerMode.BANK && routesVersion == version && !routes.isEmpty()) {
            return routes.get(Math.min(bankIndex, routes.size() - 1)).cue.cueDir.angleDeg();
        }
        return freeAngleDeg;
    }

    private double speed() { return s.dynamic ? s.power : 0; }

    private TraceOptions effectiveOpts() {
        TraceOptions o = TraceOptions.fromConfig(cfg);
        if (mode == TrainerMode.BANK) o = o.withMaxCushions(Math.max(s.maxCushions, s.bankCushions));
        return o;
    }

    // ------------------------------------------------------------------ fast frame
    public TrainerFrame frame() {
        long t0 = System.nanoTime();
        TraceOptions o = effectiveOpts();
        double base = freeAngleDeg;
        CueSolution sol = null;
        boolean computing = false, winKnown = false;
        double wp = 0, wm = 0;
        List<BankRoute> rs = Collections.emptyList();
        int bi = bankIndex;

        if (mode == TrainerMode.POCKET) {
            sol = aim.aimAtPocket(balls, CUE, targetId, table.pocketByName(pocketName), o, speed(), false);
            if (sol.cueDir != null) base = sol.cueDir.angleDeg();
            if (windowVersion == version) { winKnown = windowKnown; wp = windowPlus; wm = windowMinus; } else computing = true;
        } else if (mode == TrainerMode.BANK) {
            if (routesVersion == version) {
                rs = routes;
                if (!rs.isEmpty()) {
                    bi = Math.min(bi, rs.size() - 1);
                    sol = rs.get(bi).cue;
                    base = sol.cueDir.angleDeg();
                }
            } else computing = true;
        }
        double angle = mode == TrainerMode.FREE ? freeAngleDeg : norm(base + offsetDeg);
        ShotResult shot = sim.simulate(balls, CUE, Vec2.fromAngleDeg(angle), speed(), o);
        String status = describe(shot, sol, rs, bi, computing);
        double ms = (System.nanoTime() - t0) / 1e6;
        return new TrainerFrame(mode, angle, base, mode == TrainerMode.FREE ? 0 : offsetDeg, shot, sol, rs, bi, computing,
                                winKnown, wp, wm, status, ms);
    }

    private String describe(ShotResult shot, CueSolution sol, List<BankRoute> rs, int bi, boolean computing) {
        StringBuilder sb = new StringBuilder();
        if (mode == TrainerMode.BANK) {
            if (computing) return "Đang tính các đường bank " + s.bankCushions + " băng…";
            if (rs.isEmpty()) return "Không có đường bank " + s.bankCushions + " băng khả thi cho bi " + targetId + " (thử đổi vị trí bi hoặc số băng).";
            BankRoute r = rs.get(bi);
            sb.append("Bank ").append(r.cushions()).append(" băng · tuyến ").append(bi + 1).append("/").append(rs.size())
              .append(" · ").append(Vi.pocket(r.pocket())).append(" qua ");
            for (int i = 0; i < r.solution.rails.size(); i++) { if (i > 0) sb.append(" → "); sb.append(Vi.rail(r.solution.rails.get(i))); }
            sb.append(String.format(Locale.ROOT, " · rộng %.2f°. ", r.solution.widthDeg()));
        } else if (mode == TrainerMode.POCKET && sol != null && !sol.pocketOk) {
            sb.append("Không thể vào ").append(Vi.pocket(pocketName)).append(": ").append(Vi.reason(sol.reason)).append(". ");
        }
        PathTrace cp = shot.cuePath;
        if (cp.termination == Termination.POCKETED) return sb.append("Bi cái rơi xuống ").append(Vi.pocket(cp.pocketName())).append("!").toString();
        if (shot.contact == null) return sb.append("Bi cái chưa chạm bi nào (").append(cp.termination == Termination.STOPPED ? "dừng do ma sát" : "đang bật băng").append(").").toString();
        BallContact c = shot.contact;
        sb.append(String.format(Locale.ROOT, "Chạm bi %s · góc cắt %.1f° (%s)", c.targetId, c.cutAngleDeg, Vi.side(c.cutSide)));
        PathTrace tp = shot.targetPath;
        if (tp.termination == Termination.POCKETED)
            sb.append(" · bi ").append(c.targetId).append(" vào ").append(Vi.pocket(tp.pocketName()))
              .append(tp.cushionCount > 0 ? " sau " + tp.cushionCount + " băng" : "");
        else sb.append(" · bi ").append(c.targetId).append(" không vào lỗ");
        return sb.toString();
    }

    // ------------------------------------------------------------------ slow work
    public boolean needsHeavy() { return mode != TrainerMode.FREE; }

    /** True if the cached slow results match the current state. */
    public boolean heavyUpToDate() {
        if (mode == TrainerMode.POCKET) return windowVersion == version;
        if (mode == TrainerMode.BANK) return routesVersion == version;
        return true;
    }

    /** Immutable snapshot of the inputs; safe to run on any thread. */
    public HeavyJob heavyJob() {
        return new HeavyJob(version, mode, cfg, table, aim, bankScanner, new ArrayList<Ball>(balls), targetId, pocketName,
                            s.bankAnyPocket, s.bankCushions, effectiveOpts(), speed());
    }

    /** Applies a slow result if it still matches the current state. Returns true if accepted. */
    public boolean acceptHeavy(HeavyResult r) {
        if (r == null || r.version != version || r.mode != mode) return false;
        if (mode == TrainerMode.POCKET) {
            windowVersion = version; windowKnown = r.windowKnown; windowPlus = r.windowPlus; windowMinus = r.windowMinus;
        } else if (mode == TrainerMode.BANK) {
            routesVersion = version; routes = r.routes; bankIndex = 0;
        }
        return true;
    }

    /** Convenience for tests / synchronous callers. */
    public void runHeavyNow() { acceptHeavy(heavyJob().run()); }

    public static final class HeavyJob {
        private final int version, bankN;
        private final TrainerMode mode;
        private final EngineConfig cfg;
        private final Table table;
        private final AimSolver aim;
        private final BankScanner bank;
        private final List<Ball> balls;
        private final String targetId, pocketName;
        private final boolean anyPocket;
        private final TraceOptions o;
        private final double speed;

        HeavyJob(int version, TrainerMode mode, EngineConfig cfg, Table table, AimSolver aim, BankScanner bank,
                 List<Ball> balls, String targetId, String pocketName, boolean anyPocket, int bankN, TraceOptions o, double speed) {
            this.version = version; this.mode = mode; this.cfg = cfg; this.table = table; this.aim = aim; this.bank = bank;
            this.balls = balls; this.targetId = targetId; this.pocketName = pocketName; this.anyPocket = anyPocket;
            this.bankN = bankN; this.o = o; this.speed = speed;
        }

        public int version() { return version; }

        private static double score(BankRoute r) {
            return r.solution.widthDeg() * Math.max(0, Math.cos(Math.toRadians(r.cue.cutAngleDeg)));
        }

        public HeavyResult run() {
            if (mode == TrainerMode.POCKET) {
                CueSolution c = aim.aimAtPocket(balls, CUE, targetId, table.pocketByName(pocketName), o, speed, true);
                return new HeavyResult(version, mode, c.windowComputed, c.windowPlusDeg, c.windowMinusDeg, null);
            }
            if (mode == TrainerMode.BANK) {
                Ball tgt = ShotSimulator.find(balls, targetId);
                List<Ball> obs = new ArrayList<Ball>();
                for (Ball b : balls) if (b != tgt && !b.id.equals(CUE)) obs.add(b);
                List<BankSolution> sols = bank.scan(tgt.pos, obs, bankN, anyPocket ? null : pocketName, o);
                List<BankRoute> out = new ArrayList<BankRoute>();
                for (BankSolution b : sols) {
                    boolean tip = false;
                    for (String r : b.rails) if (r.startsWith("tip:")) tip = true;
                    if (tip || b.widthDeg() < 0.02) continue;
                    CueSolution c = aim.evaluate(balls, CUE, targetId, Vec2.fromAngleDeg(b.angleCenterDeg), b.pocket, bankN, o, speed);
                    if (c.pocketOk) out.add(new BankRoute(b, c));
                }
                // easiest first: wide window, small cut angle (thin cuts amplify aiming errors)
                Collections.sort(out, new Comparator<BankRoute>() {
                    public int compare(BankRoute x, BankRoute y) { return Double.compare(score(y), score(x)); }
                });
                while (out.size() > 10) out.remove(out.size() - 1);
                return new HeavyResult(version, mode, false, 0, 0, out);
            }
            return new HeavyResult(version, mode, false, 0, 0, null);
        }
    }

    // ------------------------------------------------------------------ persistence
    public String save() {
        StringBuilder sb = new StringBuilder();
        sb.append("mode=").append(mode.name()).append('\n');
        sb.append("target=").append(targetId).append('\n');
        sb.append("pocket=").append(pocketName).append('\n');
        sb.append("free=").append(freeAngleDeg).append('\n');
        sb.append("offset=").append(offsetDeg).append('\n');
        for (Ball b : balls) sb.append("ball=").append(b.id).append(',').append(b.pos.x).append(',').append(b.pos.y).append('\n');
        sb.append("guide=").append(s.showGuide).append('\n');
        sb.append("ghost=").append(s.showGhost).append('\n');
        sb.append("contact=").append(s.showContact).append('\n');
        sb.append("objpath=").append(s.showObjectPath).append('\n');
        sb.append("cuepost=").append(s.showCuePost).append('\n');
        sb.append("debug=").append(s.debug).append('\n');
        sb.append("aimlen=").append(s.aimLenFactor).append('\n');
        sb.append("predlen=").append(s.predictLenFactor).append('\n');
        sb.append("cushions=").append(s.maxCushions).append('\n');
        sb.append("bankn=").append(s.bankCushions).append('\n');
        sb.append("bankany=").append(s.bankAnyPocket).append('\n');
        sb.append("dynamic=").append(s.dynamic).append('\n');
        sb.append("power=").append(s.power).append('\n');
        sb.append("e=").append(s.cushionRestitution).append('\n');
        sb.append("mu=").append(s.cushionFriction).append('\n');
        sb.append("ebb=").append(s.ballRestitution).append('\n');
        return sb.toString();
    }

    /** Restores a saved state. Unknown / malformed lines are ignored; the result is always a legal state. */
    public void load(String text) {
        if (text == null) return;
        List<String[]> parsedBalls = new ArrayList<String[]>();
        TrainerMode m = mode; String tgt = targetId, pk = pocketName;
        double free = freeAngleDeg, off = 0;
        for (String line : text.split("\n")) {
            int i = line.indexOf('=');
            if (i <= 0) continue;
            String k = line.substring(0, i).trim(), v = line.substring(i + 1).trim();
            try {
                if (k.equals("mode")) m = TrainerMode.valueOf(v);
                else if (k.equals("target")) tgt = v;
                else if (k.equals("pocket")) pk = v;
                else if (k.equals("free")) free = Double.parseDouble(v);
                else if (k.equals("offset")) off = Double.parseDouble(v);
                else if (k.equals("ball")) parsedBalls.add(v.split(","));
                else if (k.equals("guide")) s.showGuide = Boolean.parseBoolean(v);
                else if (k.equals("ghost")) s.showGhost = Boolean.parseBoolean(v);
                else if (k.equals("contact")) s.showContact = Boolean.parseBoolean(v);
                else if (k.equals("objpath")) s.showObjectPath = Boolean.parseBoolean(v);
                else if (k.equals("cuepost")) s.showCuePost = Boolean.parseBoolean(v);
                else if (k.equals("debug")) s.debug = Boolean.parseBoolean(v);
                else if (k.equals("aimlen")) s.aimLenFactor = Double.parseDouble(v);
                else if (k.equals("predlen")) s.predictLenFactor = Double.parseDouble(v);
                else if (k.equals("cushions")) s.maxCushions = Integer.parseInt(v);
                else if (k.equals("bankn")) s.bankCushions = Integer.parseInt(v);
                else if (k.equals("bankany")) s.bankAnyPocket = Boolean.parseBoolean(v);
                else if (k.equals("dynamic")) s.dynamic = Boolean.parseBoolean(v);
                else if (k.equals("power")) s.power = Double.parseDouble(v);
                else if (k.equals("e")) s.cushionRestitution = Double.parseDouble(v);
                else if (k.equals("mu")) s.cushionFriction = Double.parseDouble(v);
                else if (k.equals("ebb")) s.ballRestitution = Double.parseDouble(v);
            } catch (RuntimeException ex) { /* ignore malformed line */ }
        }
        if (Double.isNaN(s.power) || Double.isInfinite(s.power)) s.power = 3000;
        try { rebuild(); } catch (RuntimeException ex) { rebuild(); }
        balls.clear();
        for (String[] b : parsedBalls) {
            try {
                String id = b[0].trim();
                if (!(id.equals(CUE) || (id.length() == 1 && id.charAt(0) >= '1' && id.charAt(0) <= '0' + MAX_OBJECT_BALLS))) continue;
                boolean dup = false;
                for (Ball x : balls) if (x.id.equals(id)) dup = true;
                if (dup) continue;
                double x = Double.parseDouble(b[1]), y = Double.parseDouble(b[2]);
                if (Double.isNaN(x) || Double.isNaN(y) || Double.isInfinite(x) || Double.isInfinite(y)) continue;
                Vec2 q = legalize(id, new Vec2(x, y));
                if (q != null) balls.add(new Ball(id, q));
            } catch (RuntimeException ex) { /* skip */ }
        }
        boolean hasCue = false, hasObj = false;
        for (Ball b : balls) { if (b.id.equals(CUE)) hasCue = true; else hasObj = true; }
        if (!hasCue || !hasObj) { resetLayout(); }
        else {
            targetId = tgt; boolean ok = false;
            for (Ball b : balls) if (b.id.equals(tgt) && !tgt.equals(CUE)) ok = true;
            if (!ok) for (Ball b : balls) if (!b.id.equals(CUE)) { targetId = b.id; break; }
        }
        if (table.pocketByName(pk) != null) pocketName = table.pocketByName(pk).name;
        mode = m; freeAngleDeg = norm(free); offsetDeg = Math.max(-MAX_OFFSET, Math.min(MAX_OFFSET, off)); bankIndex = 0;
        touch();
    }
}
