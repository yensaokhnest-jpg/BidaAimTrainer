package com.aimtrainer.trainer;
/** FREE: aim by angle/drag. POCKET: ghost-ball aim into a chosen pocket. BANK: n-cushion bank routes. */
public enum TrainerMode { FREE, POCKET, BANK }
