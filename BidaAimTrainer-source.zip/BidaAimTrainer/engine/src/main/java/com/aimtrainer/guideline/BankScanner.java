package com.aimtrainer.guideline;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.physics.*;
import java.util.*;

/**
 * Finds every object-ball direction that ends in a pocket after EXACTLY n cushions by sweeping
 * 360 degrees with the real path tracer (so knuckles, restitution and blocking balls are all
 * respected), then refines the window edges by bisection. Geometric (no friction) by design.
 */
public final class BankScanner {
    private final EngineConfig cfg;
    private final PathTracer tracer;

    public BankScanner(EngineConfig cfg, PathTracer tracer) { this.cfg = cfg; this.tracer = tracer; }

    /** obstacles: balls that block the object ball (do NOT include the object ball or the cue ball). */
    public List<BankSolution> scan(Vec2 start, List<Ball> obstacles, int n, String pocketFilter, TraceOptions base) {
        TraceOptions o = base.withMaxCushions(n).withFriction(false);
        int N = (int) Math.ceil(360.0 / cfg.scanAngleStepDeg);
        double st = 360.0 / N;
        String[] sig = new String[N];
        int offset = 0;
        boolean haveNull = false;
        for (int i = 0; i < N; i++) {
            sig[i] = signature(start, i * st, obstacles, o, pocketFilter, n);
            if (sig[i] == null && !haveNull) { offset = i; haveNull = true; }
        }
        List<BankSolution> out = new ArrayList<BankSolution>();
        int j = 0;
        while (j < N) {
            int idx = (offset + j) % N;
            if (sig[idx] == null) { j++; continue; }
            String key = sig[idx];
            int k = j;
            while (k + 1 < N && key.equals(sig[(offset + k + 1) % N])) k++;
            double aFirst = (offset + j) * st, aLast = (offset + k) * st;
            double lo = edge(start, obstacles, o, pocketFilter, n, key, aFirst, aFirst - st);
            double hi = edge(start, obstacles, o, pocketFilter, n, key, aLast, aLast + st);
            double c = (lo + hi) / 2;
            PathTrace t = tracer.trace(start, Vec2.fromAngleDeg(c), obstacles, o);
            List<String> rails = new ArrayList<String>();
            for (PathEvent e : t.events)
                if (e.kind == EventKind.CUSHION || e.kind == EventKind.TIP) rails.add(e.label);
            double cn = ((c + 180) % 360 + 360) % 360 - 180;
            out.add(new BankSolution(t.pocketName(), n, rails, lo, hi, cn, t));
            j = k + 1;
        }
        Collections.sort(out, new Comparator<BankSolution>() {
            public int compare(BankSolution a, BankSolution b) { return Double.compare(b.widthDeg(), a.widthDeg()); }
        });
        return out;
    }

    private double edge(Vec2 start, List<Ball> obs, TraceOptions o, String pf, int n, String key, double ok, double bad) {
        for (int i = 0; i < 45; i++) {
            double mid = (ok + bad) / 2;
            if (key.equals(signature(start, mid, obs, o, pf, n))) ok = mid; else bad = mid;
        }
        return (ok + bad) / 2;
    }

    private String signature(Vec2 start, double angleDeg, List<Ball> obs, TraceOptions o, String pf, int n) {
        PathTrace t = tracer.trace(start, Vec2.fromAngleDeg(angleDeg), obs, o);
        if (t.termination != Termination.POCKETED || t.cushionCount != n) return null;
        String pk = t.pocketName();
        if (pf != null && !pf.equals(pk)) return null;
        StringBuilder sb = new StringBuilder(pk);
        for (PathEvent e : t.events)
            if (e.kind == EventKind.CUSHION || e.kind == EventKind.TIP) sb.append('|').append(e.label);
        return sb.toString();
    }
}
