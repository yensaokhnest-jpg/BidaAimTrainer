package com.aimtrainer.trainer;

import com.aimtrainer.guideline.BankSolution;
import com.aimtrainer.guideline.CueSolution;

/** A bank route that was verified through the cue ball by the full simulation. */
public final class BankRoute {
    public final BankSolution solution;   // object-ball direction window
    public final CueSolution cue;         // cue aim for the window center (pocketOk == true)
    public BankRoute(BankSolution solution, CueSolution cue) { this.solution = solution; this.cue = cue; }
    public String pocket() { return solution.pocket; }
    public int cushions() { return solution.cushions; }
}
