package com.aimtrainer.table;

import com.aimtrainer.geom.Vec2;

/** Pocket mouth: the "gate" segment between the two jaw tips. inward = unit normal into the table. */
public final class Pocket {
    public final String name, shortName;
    public final boolean corner;
    public final Vec2 a, b, u, inward, mid;
    public final double len;
    public Pocket(String name, String shortName, boolean corner, Vec2 a, Vec2 b, Vec2 inward) {
        this.name = name; this.shortName = shortName; this.corner = corner;
        this.a = a; this.b = b; this.inward = inward;
        this.u = b.sub(a).unit();
        this.len = b.sub(a).len();
        this.mid = a.add(b).mul(0.5);
    }
}
