package com.aimtrainer.physics;

import com.aimtrainer.config.EngineConfig;

public final class TraceOptions {
    public final int maxCushions;
    public final double maxLength;
    public final boolean friction;
    public TraceOptions(int maxCushions, double maxLength, boolean friction) {
        this.maxCushions = maxCushions; this.maxLength = maxLength; this.friction = friction;
    }
    public static TraceOptions fromConfig(EngineConfig c) {
        return new TraceOptions(c.maxCushions, c.maxPathLength, c.dynamicMode);
    }
    public TraceOptions withMaxCushions(int n) { return new TraceOptions(n, maxLength, friction); }
    public TraceOptions withFriction(boolean f) { return new TraceOptions(maxCushions, maxLength, f); }
}
