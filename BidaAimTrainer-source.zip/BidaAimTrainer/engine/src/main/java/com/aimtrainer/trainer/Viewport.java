package com.aimtrainer.trainer;

/** Table coordinates (origin bottom-left, +y up) <-> screen pixels (+y down). Pure math. */
public final class Viewport {
    public final double scale, offX, offYTop, tableW;
    private Viewport(double scale, double offX, double offYTop, double tableW) {
        this.scale = scale; this.offX = offX; this.offYTop = offYTop; this.tableW = tableW;
    }

    /**
     * Fits the table (+ a decorative rail) into the view, leaving rightInset pixels free for a side panel.
     */
    public static Viewport fit(double viewW, double viewH, double L, double W, double rail, double margin, double rightInset) {
        double availW = Math.max(10, viewW - rightInset - 2 * margin), availH = Math.max(10, viewH - 2 * margin);
        double cw = L + 2 * rail, ch = W + 2 * rail;
        double sc = Math.min(availW / cw, availH / ch);
        double offX = margin + (availW - cw * sc) / 2 + rail * sc;
        double offYTop = margin + (availH - ch * sc) / 2 + rail * sc;
        return new Viewport(sc, offX, offYTop, W);
    }

    public double sx(double x) { return offX + x * scale; }
    public double sy(double y) { return offYTop + (tableW - y) * scale; }
    public double tx(double px) { return (px - offX) / scale; }
    public double ty(double py) { return tableW - (py - offYTop) / scale; }
    public double len(double l) { return l * scale; }
}
