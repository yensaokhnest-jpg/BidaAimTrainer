package com.aimtrainer.trainer;

/** Vietnamese UI strings used by the model / scene (kept out of the logic). */
public final class Vi {
    private Vi() {}
    public static String pocket(String name) {
        if (name == null) return "?";
        switch (name) {
            case "bottom_left": return "lỗ góc dưới-trái";
            case "bottom_mid": return "lỗ giữa dưới";
            case "bottom_right": return "lỗ góc dưới-phải";
            case "top_left": return "lỗ góc trên-trái";
            case "top_mid": return "lỗ giữa trên";
            case "top_right": return "lỗ góc trên-phải";
            default: return name;
        }
    }
    public static String rail(String label) {
        if (label == null) return "?";
        if (label.startsWith("tip:")) return "mép lỗ";
        switch (label) {
            case "bottom": return "băng dưới";
            case "top": return "băng trên";
            case "left": return "băng trái";
            case "right": return "băng phải";
            default: return label;
        }
    }
    public static String side(String s) { return s.equals("left") ? "trái" : s.equals("right") ? "phải" : "thẳng"; }

    /** Translates the engine's English failure reasons for display. */
    public static String reason(String r) {
        if (r == null) return "";
        if (r.startsWith("cut angle >= 90")) return "góc cắt ≥ 90°: bi cái không tới được vị trí ghost từ phía này";
        if (r.startsWith("ghost-ball position")) return "vị trí ghost nằm ngoài vùng chơi";
        if (r.startsWith("cue path is blocked")) {
            int a = r.indexOf('\''), b = r.indexOf('\'', a + 1);
            return "bị bi " + (a >= 0 && b > a ? r.substring(a + 1, b) : "khác") + " chắn đường";
        }
        if (r.startsWith("cue path ends without")) return "bi cái không chạm bi mục tiêu";
        if (r.startsWith("object ball path ends")) return "bi mục tiêu không vào lỗ";
        if (r.startsWith("object ball is pocketed")) return "bi mục tiêu vào lỗ khác / số băng khác";
        if (r.startsWith("cue ball is already")) return "bi cái đang nằm đúng vị trí ghost";
        return r;
    }
}
