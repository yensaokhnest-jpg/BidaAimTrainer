package com.aimtrainer.geom;

/** Immutable 2D vector (double precision). */
public final class Vec2 {
    public final double x, y;
    public Vec2(double x, double y) { this.x = x; this.y = y; }
    public Vec2 add(Vec2 o) { return new Vec2(x + o.x, y + o.y); }
    public Vec2 sub(Vec2 o) { return new Vec2(x - o.x, y - o.y); }
    public Vec2 mul(double k) { return new Vec2(x * k, y * k); }
    public double dot(Vec2 o) { return x * o.x + y * o.y; }
    public double cross(Vec2 o) { return x * o.y - y * o.x; }
    public double len() { return Math.hypot(x, y); }
    public double dist(Vec2 o) { return sub(o).len(); }
    public Vec2 unit() {
        double l = len();
        if (l == 0) throw new IllegalStateException("zero-length vector");
        return new Vec2(x / l, y / l);
    }
    public double angleDeg() { return Math.toDegrees(Math.atan2(y, x)); }
    public static Vec2 fromAngleDeg(double deg) {
        double r = Math.toRadians(deg);
        return new Vec2(Math.cos(r), Math.sin(r));
    }
    @Override public String toString() { return String.format("(%.3f, %.3f)", x, y); }
}
