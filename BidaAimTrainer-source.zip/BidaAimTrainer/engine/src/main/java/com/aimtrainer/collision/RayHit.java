package com.aimtrainer.collision;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.table.Pocket;

/**
 * First obstacle met by a moving ball center.
 * s       : distance travelled by the center
 * center  : ball center at the moment of impact
 * normal  : BALL -> unit vector from the moving ball to the hit ball;
 *           CUSHION/TIP -> unit normal pointing toward the ball (into the table);
 *           POCKET -> gate inward normal
 */
public final class RayHit {
    public final HitType type;
    public final double s;
    public final Vec2 center, normal;
    public final String label;
    public final Ball ball;
    public final Pocket pocket;
    public RayHit(HitType type, double s, Vec2 center, Vec2 normal, String label, Ball ball, Pocket pocket) {
        this.type = type; this.s = s; this.center = center; this.normal = normal;
        this.label = label; this.ball = ball; this.pocket = pocket;
    }
}
