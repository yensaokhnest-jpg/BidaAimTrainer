package com.aimtrainer.physics;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.collision.*;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.table.Table;
import java.util.*;

/**
 * Traces ONE moving ball (center path) through cushions until a ball is hit, it is pocketed,
 * the cushion limit is reached, or (dynamic mode) it stops. Other balls are static obstacles.
 */
public final class PathTracer {
    private final EngineConfig cfg;
    private final CollisionSolver solver;

    public PathTracer(EngineConfig cfg, Table table) {
        this.cfg = cfg;
        this.solver = new CollisionSolver(table, cfg);
    }

    public PathTrace trace(Vec2 start, Vec2 velocity, List<Ball> obstacles, TraceOptions o) {
        List<Vec2> pts = new ArrayList<Vec2>();
        List<PathEvent> evs = new ArrayList<PathEvent>();
        pts.add(start);
        double speed = velocity.len();
        if (speed < 1e-12) return new PathTrace(pts, evs, Termination.STOPPED, 0, null, 0, null, 0);

        Vec2 dir = velocity.mul(1.0 / speed);
        Vec2 pos = start;
        double travelled = 0;
        int cushions = 0;
        double decel = cfg.rollingFriction * cfg.gravity;
        boolean fr = o.friction && decel > 0;

        for (int guard = 0; guard < 100000; guard++) {
            if (o.friction && speed <= cfg.stopSpeed)
                return new PathTrace(pts, evs, Termination.STOPPED, travelled, null, speed, dir, cushions);

            RayHit h = solver.firstHit(pos, dir, obstacles);
            if (h == null)
                return new PathTrace(pts, evs, Termination.ESCAPED, travelled, null, speed, dir, cushions);

            double seg = h.s;
            double remaining = o.maxLength - travelled;
            double stopDist = fr ? speed * speed / (2 * decel) : Double.POSITIVE_INFINITY;
            double lim = Math.min(remaining, stopDist);
            if (lim <= seg) {                          // the path ends before reaching the next hit
                pts.add(pos.add(dir.mul(lim)));
                double sp = fr ? Math.sqrt(Math.max(0, speed * speed - 2 * decel * lim)) : speed;
                Termination t = stopDist <= remaining ? Termination.STOPPED : Termination.MAX_LENGTH;
                return new PathTrace(pts, evs, t, travelled + lim, null, sp, dir, cushions);
            }

            double spAt = fr ? Math.sqrt(Math.max(0, speed * speed - 2 * decel * seg)) : speed;
            travelled += seg;
            pos = h.center;
            pts.add(pos);

            if (h.type == HitType.BALL) {
                evs.add(new PathEvent(EventKind.BALL_HIT, pos, h.label, h.normal, travelled, spAt, spAt, dir, null, cushions));
                return new PathTrace(pts, evs, Termination.BALL_HIT, travelled, h, spAt, dir, cushions);
            }
            if (h.type == HitType.POCKET) {
                evs.add(new PathEvent(EventKind.POCKET, pos, h.label, h.normal, travelled, spAt, spAt, dir, null, cushions));
                return new PathTrace(pts, evs, Termination.POCKETED, travelled, h, spAt, dir, cushions);
            }
            // CUSHION or TIP
            if (cushions >= o.maxCushions) {
                evs.add(new PathEvent(EventKind.CUSHION_LIMIT, pos, h.label, h.normal, travelled, spAt, spAt, dir, null, cushions));
                return new PathTrace(pts, evs, Termination.MAX_CUSHIONS, travelled, h, spAt, dir, cushions);
            }
            Vec2 v2 = Impulse.cushion(dir.mul(spAt), h.normal, cfg.cushionRestitution, cfg.cushionFriction);
            double sp2 = v2.len();
            cushions++;
            Vec2 dir2 = v2.mul(1.0 / sp2);
            evs.add(new PathEvent(h.type == HitType.TIP ? EventKind.TIP : EventKind.CUSHION, pos, h.label, h.normal,
                                  travelled, spAt, sp2, dir, dir2, cushions));
            speed = sp2;
            dir = dir2;
        }
        return new PathTrace(pts, evs, Termination.ESCAPED, travelled, null, speed, dir, cushions);
    }
}
