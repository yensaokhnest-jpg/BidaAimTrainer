package com.aimtrainer.physics;

/** Everything a guideline needs: cue path, contact, object-ball path, cue path after contact. */
public final class ShotResult {
    public final PathTrace cuePath;
    public final BallContact contact;      // null if the cue ball did not hit a ball
    public final PathTrace targetPath;     // null if no contact
    public final PathTrace cuePostPath;    // null if no contact or cue ball has no motion left
    public ShotResult(PathTrace cuePath, BallContact contact, PathTrace targetPath, PathTrace cuePostPath) {
        this.cuePath = cuePath; this.contact = contact; this.targetPath = targetPath; this.cuePostPath = cuePostPath;
    }
    /** Pocket name the object ball ends in, or null. */
    public String targetPocketName() { return targetPath == null ? null : targetPath.pocketName(); }
}
