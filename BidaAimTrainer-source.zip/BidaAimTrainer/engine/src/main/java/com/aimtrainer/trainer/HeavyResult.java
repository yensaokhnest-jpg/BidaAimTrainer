package com.aimtrainer.trainer;

import java.util.List;

/** Output of a slow computation (aim window / bank routes), tagged with the model version it was computed for. */
public final class HeavyResult {
    public final int version;
    public final TrainerMode mode;
    public final boolean windowKnown;
    public final double windowPlus, windowMinus;
    public final List<BankRoute> routes;        // null unless mode == BANK
    public HeavyResult(int version, TrainerMode mode, boolean windowKnown, double windowPlus, double windowMinus, List<BankRoute> routes) {
        this.version = version; this.mode = mode; this.windowKnown = windowKnown;
        this.windowPlus = windowPlus; this.windowMinus = windowMinus; this.routes = routes;
    }
}
