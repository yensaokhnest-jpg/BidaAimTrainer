package com.aimtrainer.physics;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.collision.Impulse;
import com.aimtrainer.collision.RayHit;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.table.Table;
import java.util.*;

/**
 * One cue shot: cue path -> first ball contact -> object-ball path + cue-ball path after contact.
 * The two post-contact paths are traced independently (the other moving ball is ignored: the
 * time coupling between two moving balls is NOT modeled). No spin.
 */
public final class ShotSimulator {
    private final EngineConfig cfg;
    private final PathTracer tracer;

    public ShotSimulator(EngineConfig cfg, Table table) {
        this.cfg = cfg;
        this.tracer = new PathTracer(cfg, table);
    }

    public PathTracer tracer() { return tracer; }

    public static Ball find(List<Ball> balls, String id) {
        for (Ball b : balls) if (b.id.equals(id)) return b;
        throw new IllegalArgumentException("No ball with id '" + id + "'");
    }

    /** speed: used only when o.friction is true (<=0 -> cfg.defaultSpeed). Geometric mode uses a nominal speed 1. */
    public ShotResult simulate(List<Ball> balls, String cueId, Vec2 dir, double speed, TraceOptions o) {
        Ball cue = find(balls, cueId);
        List<Ball> obstacles = new ArrayList<Ball>();
        for (Ball b : balls) if (b != cue) obstacles.add(b);

        double sp = o.friction ? (speed > 0 ? speed : cfg.defaultSpeed) : 1.0;
        Vec2 d = dir.unit();
        PathTrace cp = tracer.trace(cue.pos, d.mul(sp), obstacles, o);
        if (cp.termination != Termination.BALL_HIT) return new ShotResult(cp, null, null, null);

        RayHit h = cp.endHit;
        Ball tgt = h.ball;
        Vec2 n = h.normal;
        Vec2 vC = cp.endDir.mul(cp.endSpeed);
        Vec2[] after = Impulse.ballBall(vC, new Vec2(0, 0), n, cfg.ballBallRestitution);
        double cosCut = Math.max(-1, Math.min(1, cp.endDir.dot(n)));
        double cross = cp.endDir.cross(n);
        String side = Math.abs(cross) < 1e-12 ? "straight" : (cross > 0 ? "left" : "right");
        BallContact bc = new BallContact(tgt.id, h.center, h.center.add(n.mul(cfg.ballRadius)), n,
            Math.toDegrees(Math.acos(cosCut)), side, cp.endSpeed, after[0], after[1]);

        List<Ball> rest = new ArrayList<Ball>();         // both moving balls leave their start spots
        for (Ball b : obstacles) if (b != tgt) rest.add(b);
        PathTrace tp = tracer.trace(tgt.pos, after[1], rest, o);
        PathTrace cpost = after[0].len() > 1e-9 ? tracer.trace(h.center, after[0], rest, o) : null;
        return new ShotResult(cp, bc, tp, cpost);
    }
}
