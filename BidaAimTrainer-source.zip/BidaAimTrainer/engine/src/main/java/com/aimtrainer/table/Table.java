package com.aimtrainer.table;

import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import java.util.*;

/** Table geometry built purely from EngineConfig. */
public final class Table {
    public final double length, width, radius;
    public final double cornerTip;      // distance of corner jaw tips from the corner, along each rail
    public final double sideHalfMouth;
    public final List<CushionSegment> cushions;
    public final List<Pocket> pockets;
    public final List<Tip> tips;

    public Table(EngineConfig c) {
        length = c.tableLength; width = c.tableWidth; radius = c.ballRadius;
        double L = length, W = width;
        double tC = c.cornerMouth / Math.sqrt(2.0);
        double hS = c.sideMouth / 2.0;
        cornerTip = tC; sideHalfMouth = hS;
        double r2 = Math.sqrt(0.5);

        List<Pocket> pk = new ArrayList<Pocket>();
        pk.add(new Pocket("bottom_left",  "bl", true,  new Vec2(tC, 0),     new Vec2(0, tC),     new Vec2( r2,  r2)));
        pk.add(new Pocket("bottom_mid",   "bm", false, new Vec2(L / 2 - hS, 0), new Vec2(L / 2 + hS, 0), new Vec2(0, 1)));
        pk.add(new Pocket("bottom_right", "br", true,  new Vec2(L - tC, 0), new Vec2(L, tC),     new Vec2(-r2,  r2)));
        pk.add(new Pocket("top_left",     "tl", true,  new Vec2(0, W - tC), new Vec2(tC, W),     new Vec2( r2, -r2)));
        pk.add(new Pocket("top_mid",      "tm", false, new Vec2(L / 2 - hS, W), new Vec2(L / 2 + hS, W), new Vec2(0, -1)));
        pk.add(new Pocket("top_right",    "tr", true,  new Vec2(L - tC, W), new Vec2(L, W - tC), new Vec2(-r2, -r2)));
        pockets = Collections.unmodifiableList(pk);

        List<Tip> tp = new ArrayList<Tip>();
        for (Pocket p : pk) { tp.add(new Tip(p.a, p)); tp.add(new Tip(p.b, p)); }
        tips = Collections.unmodifiableList(tp);

        List<CushionSegment> cs = new ArrayList<CushionSegment>();
        cs.add(new CushionSegment("bottom", new Vec2(tC, 0), new Vec2(L / 2 - hS, 0), new Vec2(0, 1)));
        cs.add(new CushionSegment("bottom", new Vec2(L / 2 + hS, 0), new Vec2(L - tC, 0), new Vec2(0, 1)));
        cs.add(new CushionSegment("top", new Vec2(tC, W), new Vec2(L / 2 - hS, W), new Vec2(0, -1)));
        cs.add(new CushionSegment("top", new Vec2(L / 2 + hS, W), new Vec2(L - tC, W), new Vec2(0, -1)));
        cs.add(new CushionSegment("left", new Vec2(0, tC), new Vec2(0, W - tC), new Vec2(1, 0)));
        cs.add(new CushionSegment("right", new Vec2(L, tC), new Vec2(L, W - tC), new Vec2(-1, 0)));
        cushions = Collections.unmodifiableList(cs);
    }

    /** Accepts full names (bottom_left) or short names (bl, bm, br, tl, tm, tr). */
    public Pocket pocketByName(String s) {
        String k = s.toLowerCase();
        for (Pocket p : pockets) if (p.name.equals(k) || p.shortName.equals(k)) return p;
        return null;
    }

    /**
     * True if a ball CENTER at p is a legal resting position: inside the playable area (inset by one
     * radius from the cushion faces) AND on the table side of every pocket gate. The second condition
     * matters at the corners, where the inset rectangle pokes into the pocket mouth.
     */
    public boolean inPlayfield(Vec2 p, double tol) {
        if (!(p.x >= radius - tol && p.x <= length - radius + tol
           && p.y >= radius - tol && p.y <= width - radius + tol)) return false;
        for (Pocket k : pockets) if (p.sub(k.a).dot(k.inward) < -tol) return false;
        return true;
    }
}
