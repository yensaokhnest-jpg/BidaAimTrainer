package com.aimtrainer.collision;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.table.*;
import java.util.List;

/**
 * Exact (analytic, no time stepping) continuous collision detection for a ball center moving
 * along a ray. Obstacles, all in "center space" (Minkowski sum with the ball radius R):
 *   - other balls     : circle of radius 2R around their centers
 *   - cushion faces   : segment offset by R into the table
 *   - jaw tips        : circle of radius R around the tip point
 *   - pocket gates    : segment between the two tips (center crossing it = pocketed)
 */
public final class CollisionSolver {
    private final Table table;
    private final double R, eps;

    public CollisionSolver(Table table, EngineConfig cfg) {
        this.table = table; this.R = cfg.ballRadius; this.eps = cfg.eps();
    }

    /** First hit along p + s*d (d must be a unit vector), or null if nothing is hit. */
    public RayHit firstHit(Vec2 p, Vec2 d, List<Ball> obstacles) {
        RayHit best = null;
        for (Ball b : obstacles)
            best = better(best, circle(p, d, b.pos, 2 * R, HitType.BALL, b.id, b, true));
        for (Tip t : table.tips)
            best = better(best, circle(p, d, t.pos, R, HitType.TIP, "tip:" + t.pocket.name, null, false));
        for (CushionSegment sg : table.cushions)
            best = better(best, cushion(p, d, sg));
        for (Pocket pk : table.pockets)
            best = better(best, gate(p, d, pk));
        return best;
    }

    // ties (within eps) keep the earlier candidate: ball > tip > cushion > pocket
    private RayHit better(RayHit a, RayHit b) {
        if (b == null) return a;
        if (a == null || b.s < a.s - eps) return b;
        return a;
    }

    private RayHit circle(Vec2 p, Vec2 d, Vec2 c, double rho, HitType type, String label, Ball ball, boolean toward) {
        Vec2 m = p.sub(c);
        double b = m.dot(d);
        if (b >= 0) return null;                       // moving away from (or tangent to) the circle
        double cc = m.dot(m) - rho * rho;
        double disc = b * b - cc;
        if (disc < 0) return null;
        double s = -b - Math.sqrt(disc);               // entering root
        if (s < -eps) return null;                     // already inside: not an entry
        if (s < 0) s = 0;
        Vec2 q = p.add(d.mul(s));
        Vec2 n = toward ? c.sub(q).mul(1.0 / rho) : q.sub(c).mul(1.0 / rho);
        return new RayHit(type, s, q, n, label, ball, null);
    }

    private RayHit cushion(Vec2 p, Vec2 d, CushionSegment sg) {
        double dn = d.dot(sg.n);
        if (dn > -1e-12) return null;                  // not approaching the face
        double dist = p.sub(sg.a).dot(sg.n);           // distance of the center from the face line
        double s = (R - dist) / dn;                    // center reaches distance R
        if (s < -eps) return null;
        if (s < 0) s = 0;
        Vec2 q = p.add(d.mul(s));
        double t = q.sub(sg.a).dot(sg.u);
        if (t < 0 || t > sg.len) return null;          // beyond the segment: tip circle handles it
        return new RayHit(HitType.CUSHION, s, q, sg.n, sg.name, null, null);
    }

    private RayHit gate(Vec2 p, Vec2 d, Pocket pk) {
        double dn = d.dot(pk.inward);
        if (dn > -1e-12) return null;                  // not moving out through the mouth
        double dist = p.sub(pk.a).dot(pk.inward);
        double s = -dist / dn;
        if (s < -eps) return null;
        if (s < 0) s = 0;
        Vec2 q = p.add(d.mul(s));
        double t = q.sub(pk.a).dot(pk.u);
        if (t < 0 || t > pk.len) return null;
        return new RayHit(HitType.POCKET, s, q, pk.inward, pk.name, null, pk);
    }
}
