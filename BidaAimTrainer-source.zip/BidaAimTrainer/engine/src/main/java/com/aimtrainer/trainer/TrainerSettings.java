package com.aimtrainer.trainer;

/** User-adjustable settings. Display-only ones never trigger physics recomputation. */
public final class TrainerSettings {
    // display
    public boolean showGuide = true;          // master AIM on/off
    public boolean showGhost = true;
    public boolean showContact = true;
    public boolean showObjectPath = true;
    public boolean showCuePost = true;
    public boolean debug = false;
    public double aimLenFactor = 3.0;         // cue ray length, in table lengths (display clip)
    public double predictLenFactor = 1.5;     // predicted paths length, in table lengths (display clip)
    // physics
    public int maxCushions = 3;               // 0..MAX_CUSHIONS
    public int bankCushions = 1;              // 1..MAX_BANK
    public boolean bankAnyPocket = true;
    public boolean dynamic = false;           // speed + rolling friction
    public double power = 3000;               // cue speed (config length unit / s) in dynamic mode
    public double cushionRestitution, cushionFriction, ballRestitution;   // initialised from config

    public static final int MAX_CUSHIONS = 8, MAX_BANK = 4;
    public static final double MIN_LEN = 0.2, MAX_LEN = 6.0;

    public void clamp() {
        maxCushions = Math.max(0, Math.min(MAX_CUSHIONS, maxCushions));
        bankCushions = Math.max(1, Math.min(MAX_BANK, bankCushions));
        aimLenFactor = Math.max(MIN_LEN, Math.min(MAX_LEN, aimLenFactor));
        predictLenFactor = Math.max(MIN_LEN, Math.min(MAX_LEN, predictLenFactor));
        power = Math.max(200, Math.min(12000, power));
        cushionRestitution = Math.max(0.05, Math.min(1.0, cushionRestitution));
        cushionFriction = Math.max(0.0, Math.min(1.0, cushionFriction));
        ballRestitution = Math.max(0.05, Math.min(1.0, ballRestitution));
    }
}
