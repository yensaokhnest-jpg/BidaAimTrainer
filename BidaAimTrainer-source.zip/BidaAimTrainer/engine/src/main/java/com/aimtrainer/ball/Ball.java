package com.aimtrainer.ball;

import com.aimtrainer.geom.Vec2;

/** A ball at rest (id + center). Radius is global (EngineConfig.ballRadius). */
public final class Ball {
    public final String id;
    public final Vec2 pos;
    public Ball(String id, Vec2 pos) { this.id = id; this.pos = pos; }
    @Override public String toString() { return id + "@" + pos; }
}
