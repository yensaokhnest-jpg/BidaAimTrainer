package com.aimtrainer.guideline;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.physics.*;
import com.aimtrainer.table.Pocket;
import com.aimtrainer.table.Table;
import java.util.List;

/**
 * Ghost-ball aiming. The ghost position is  G = T - 2R * objDir  (objDir = desired object-ball
 * direction); the cue aims at G; the contact point is the midpoint of cue-at-G and T.
 * Every answer is verified by the real simulation, not assumed from the algebra.
 */
public final class AimSolver {
    private final EngineConfig cfg;
    private final Table table;
    private final ShotSimulator sim;

    public AimSolver(EngineConfig cfg, Table table, ShotSimulator sim) {
        this.cfg = cfg; this.table = table; this.sim = sim;
    }

    /** Direct pocket shot: object ball aimed at the pocket gate midpoint, plus aim-tolerance window. */
    public CueSolution aimAtPocket(List<Ball> balls, String cueId, String targetId, Pocket pk, TraceOptions o, double speed) {
        return aimAtPocket(balls, cueId, targetId, pk, o, speed, true);
    }

    /** Same, with the (slow) aim-window search optional. */
    public CueSolution aimAtPocket(List<Ball> balls, String cueId, String targetId, Pocket pk, TraceOptions o, double speed, boolean computeWindow) {
        Ball tgt = ShotSimulator.find(balls, targetId);
        Vec2 objDir = pk.mid.sub(tgt.pos).unit();
        CueSolution s = evaluate(balls, cueId, targetId, objDir, pk.name, -1, o, speed);
        if (s.pocketOk && computeWindow) computeWindow(s, balls, cueId, targetId, pk.name, o, speed);
        return s;
    }

    /**
     * Cue aim that sends the object ball along objDir.
     * expectPocket != null : also require that the object ball ends in that pocket;
     * expectCushions >= 0  : ... after exactly that many cushion/tip bounces.
     */
    public CueSolution evaluate(List<Ball> balls, String cueId, String targetId, Vec2 objDir,
                                String expectPocket, int expectCushions, TraceOptions o, double speed) {
        Ball cue = ShotSimulator.find(balls, cueId);
        Ball tgt = ShotSimulator.find(balls, targetId);
        double R = cfg.ballRadius;
        CueSolution s = new CueSolution();
        s.ghost = tgt.pos.sub(objDir.mul(2 * R));
        Vec2 toG = s.ghost.sub(cue.pos);
        if (toG.len() < cfg.eps()) { s.reason = "cue ball is already at the ghost-ball position"; return s; }
        s.cueDir = toG.unit();
        double cos = s.cueDir.dot(objDir);
        s.cutAngleDeg = Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, cos))));
        if (cos <= 1e-9) { s.reason = "cut angle >= 90 deg: the cue ball cannot reach the ghost position from this side"; return s; }
        if (!table.inPlayfield(s.ghost, cfg.eps())) { s.reason = "ghost-ball position " + s.ghost + " is outside the playable area"; return s; }

        s.shot = sim.simulate(balls, cueId, s.cueDir, speed, o);
        ShotResult r = s.shot;
        if (r.contact == null) {
            s.reason = "cue path ends without hitting a ball: " + r.cuePath.termination;
            return s;
        }
        if (!r.contact.targetId.equals(targetId)) {
            s.reason = "cue path is blocked: it hits ball '" + r.contact.targetId + "' first";
            return s;
        }
        s.contactOk = true;
        if (expectPocket == null) { s.pocketOk = true; return s; }
        PathTrace tp = r.targetPath;
        if (tp.termination != Termination.POCKETED) {
            s.reason = "object ball path ends: " + tp.termination + (tp.endHit != null ? " (" + tp.endHit.label + ")" : "");
            if (!tp.events.isEmpty()) { PathEvent last = tp.events.get(tp.events.size() - 1);
                s.reason += " at " + last.point; }
            return s;
        }
        if (!tp.pocketName().equals(expectPocket)) { s.reason = "object ball is pocketed in " + tp.pocketName() + " instead of " + expectPocket; return s; }
        if (expectCushions >= 0 && tp.cushionCount != expectCushions) {
            s.reason = "object ball is pocketed after " + tp.cushionCount + " cushion(s), expected " + expectCushions; return s; }
        s.pocketOk = true;
        return s;
    }

    /** Angular tolerance (both sides) of the cue direction that still pockets the object ball. */
    private void computeWindow(CueSolution s, List<Ball> balls, String cueId, String targetId,
                               String pocket, TraceOptions o, double speed) {
        double base = s.cueDir.angleDeg(), step = cfg.scanAngleStepDeg;
        s.windowPlusDeg = sweep(balls, cueId, targetId, pocket, o, speed, base, +1, step);
        s.windowMinusDeg = sweep(balls, cueId, targetId, pocket, o, speed, base, -1, step);
        s.windowComputed = true;
    }

    private double sweep(List<Ball> balls, String cueId, String targetId, String pocket, TraceOptions o,
                         double speed, double base, int sign, double step) {
        double last = 0;
        for (double d = step; d <= cfg.windowMaxDeg + 1e-12; d += step) {
            ShotResult r = sim.simulate(balls, cueId, Vec2.fromAngleDeg(base + sign * d), speed, o);
            boolean ok = r.contact != null && r.contact.targetId.equals(targetId) && pocket.equals(r.targetPocketName());
            if (!ok) break;
            last = d;
        }
        return last;
    }
}
