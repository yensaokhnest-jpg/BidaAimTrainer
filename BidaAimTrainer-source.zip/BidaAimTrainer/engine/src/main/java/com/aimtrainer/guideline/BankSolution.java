package com.aimtrainer.guideline;

import com.aimtrainer.physics.PathTrace;
import java.util.List;

/** One contiguous range of object-ball directions that pocket the ball after exactly n cushions. */
public final class BankSolution {
    public final String pocket;
    public final int cushions;
    public final List<String> rails;        // cushion/tip labels in hit order
    public final double angleMinDeg, angleMaxDeg, angleCenterDeg;
    public final PathTrace trace;           // trace along the center direction
    public BankSolution(String pocket, int cushions, List<String> rails, double min, double max, double center, PathTrace trace) {
        this.pocket = pocket; this.cushions = cushions; this.rails = rails;
        this.angleMinDeg = min; this.angleMaxDeg = max; this.angleCenterDeg = center; this.trace = trace;
    }
    public double widthDeg() { return angleMaxDeg - angleMinDeg; }
}
