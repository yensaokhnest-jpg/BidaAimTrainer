package com.aimtrainer.trainer;

import com.aimtrainer.guideline.CueSolution;
import com.aimtrainer.physics.ShotResult;
import java.util.List;

/** Everything needed to draw one picture. Immutable. */
public final class TrainerFrame {
    public final TrainerMode mode;
    public final double aimAngleDeg, baseAngleDeg, offsetDeg;
    public final ShotResult shot;
    public final CueSolution solution;          // POCKET / BANK: the ideal solution (may be invalid)
    public final List<BankRoute> routes;
    public final int bankIndex;
    public final boolean computing;             // slow computation still running
    public final boolean windowKnown;
    public final double windowPlus, windowMinus;
    public final String status;
    public final double computeMs;
    public TrainerFrame(TrainerMode mode, double aimAngleDeg, double baseAngleDeg, double offsetDeg, ShotResult shot,
                        CueSolution solution, List<BankRoute> routes, int bankIndex, boolean computing,
                        boolean windowKnown, double windowPlus, double windowMinus, String status, double computeMs) {
        this.mode = mode; this.aimAngleDeg = aimAngleDeg; this.baseAngleDeg = baseAngleDeg; this.offsetDeg = offsetDeg;
        this.shot = shot; this.solution = solution; this.routes = routes; this.bankIndex = bankIndex; this.computing = computing;
        this.windowKnown = windowKnown; this.windowPlus = windowPlus; this.windowMinus = windowMinus;
        this.status = status; this.computeMs = computeMs;
    }
}
