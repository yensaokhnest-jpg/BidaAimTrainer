package com.aimtrainer.config;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Immutable engine configuration loaded from ONE .properties file.
 * Strict: every key must be present, unknown keys are rejected, values are range-checked.
 */
public final class EngineConfig {
    public static final List<String> KEYS = Collections.unmodifiableList(Arrays.asList(
        "meta.profile", "meta.length_unit",
        "table.length", "table.width",
        "ball.radius",
        "pocket.corner.mouth", "pocket.side.mouth",
        "cushion.restitution", "cushion.friction",
        "collision.ball_ball_restitution",
        "cloth.rolling_friction", "physics.gravity", "physics.stop_speed",
        "guideline.mode", "guideline.max_cushions", "guideline.max_path_length", "guideline.default_speed",
        "scan.angle_step_deg", "scan.window_max_deg",
        "numeric.epsilon_rel"));

    private final Map<String, String> raw;
    public final String profile, lengthUnit;
    public final double tableLength, tableWidth, ballRadius, cornerMouth, sideMouth;
    public final double cushionRestitution, cushionFriction, ballBallRestitution;
    public final double rollingFriction, gravity, stopSpeed;
    public final boolean dynamicMode;
    public final int maxCushions;
    public final double maxPathLength, defaultSpeed, scanAngleStepDeg, windowMaxDeg, epsilonRel;

    private EngineConfig(Map<String, String> m) {
        for (String k : m.keySet())
            if (!KEYS.contains(k)) throw new IllegalArgumentException("Unknown config key: '" + k + "'");
        for (String k : KEYS)
            if (!m.containsKey(k)) throw new IllegalArgumentException("Missing config key: '" + k + "'");
        raw = Collections.unmodifiableMap(new LinkedHashMap<String, String>(m));
        profile = m.get("meta.profile");
        lengthUnit = m.get("meta.length_unit");
        tableLength = num(m, "table.length");
        tableWidth = num(m, "table.width");
        ballRadius = num(m, "ball.radius");
        cornerMouth = num(m, "pocket.corner.mouth");
        sideMouth = num(m, "pocket.side.mouth");
        cushionRestitution = num(m, "cushion.restitution");
        cushionFriction = num(m, "cushion.friction");
        ballBallRestitution = num(m, "collision.ball_ball_restitution");
        rollingFriction = num(m, "cloth.rolling_friction");
        gravity = num(m, "physics.gravity");
        stopSpeed = num(m, "physics.stop_speed");
        String mode = m.get("guideline.mode");
        if (mode.equals("geometric")) dynamicMode = false;
        else if (mode.equals("dynamic")) dynamicMode = true;
        else throw new IllegalArgumentException("guideline.mode must be 'geometric' or 'dynamic', got '" + mode + "'");
        try { maxCushions = Integer.parseInt(m.get("guideline.max_cushions")); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("guideline.max_cushions must be an integer"); }
        maxPathLength = num(m, "guideline.max_path_length");
        defaultSpeed = num(m, "guideline.default_speed");
        scanAngleStepDeg = num(m, "scan.angle_step_deg");
        windowMaxDeg = num(m, "scan.window_max_deg");
        epsilonRel = num(m, "numeric.epsilon_rel");
        validate();
    }

    private static double num(Map<String, String> m, String key) {
        try { return Double.parseDouble(m.get(key)); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("Config key '" + key + "' is not a number: '" + m.get(key) + "'"); }
    }

    private static void req(boolean ok, String msg) { if (!ok) throw new IllegalArgumentException("Invalid config: " + msg); }

    private void validate() {
        req(tableLength > 0 && tableWidth > 0, "table.length/width must be > 0");
        req(ballRadius > 0, "ball.radius must be > 0");
        req(2 * ballRadius < tableWidth, "ball diameter must be smaller than table.width");
        req(cornerMouth > 0 && sideMouth > 0, "pocket mouths must be > 0");
        double tC = cornerMouth / Math.sqrt(2.0);
        req(tC < tableLength / 2 - sideMouth / 2, "corner + side pocket mouths overlap along the long rail");
        req(tC < tableWidth / 2, "corner pocket mouths overlap along the short rail");
        req(cushionRestitution > 0 && cushionRestitution <= 1, "cushion.restitution must be in (0,1]");
        req(cushionFriction >= 0, "cushion.friction must be >= 0");
        req(ballBallRestitution > 0 && ballBallRestitution <= 1, "collision.ball_ball_restitution must be in (0,1]");
        req(rollingFriction >= 0, "cloth.rolling_friction must be >= 0");
        req(gravity > 0, "physics.gravity must be > 0");
        req(stopSpeed >= 0, "physics.stop_speed must be >= 0");
        req(maxCushions >= 0, "guideline.max_cushions must be >= 0");
        req(maxPathLength > 0, "guideline.max_path_length must be > 0");
        req(defaultSpeed > 0, "guideline.default_speed must be > 0");
        req(scanAngleStepDeg > 0, "scan.angle_step_deg must be > 0");
        req(windowMaxDeg > 0, "scan.window_max_deg must be > 0");
        req(epsilonRel > 0 && epsilonRel < 1e-3, "numeric.epsilon_rel must be in (0,1e-3)");
    }

    public static EngineConfig load(Path file) throws IOException {
        try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) { return load(r); }
    }

    /** Loads from any Reader (e.g. an Android asset). The reader is NOT closed. */
    public static EngineConfig load(Reader r) throws IOException {
        Properties p = new Properties();
        p.load(r);
        Map<String, String> m = new LinkedHashMap<String, String>();
        for (String k : p.stringPropertyNames()) m.put(k, p.getProperty(k).trim());
        return new EngineConfig(m);
    }

    public static EngineConfig fromMap(Map<String, String> m) { return new EngineConfig(m); }

    /** Returns a copy with one key replaced (used by tests and the live 'set' command). */
    public EngineConfig with(String key, String value) {
        if (!KEYS.contains(key)) throw new IllegalArgumentException("Unknown config key: '" + key + "'");
        Map<String, String> m = new LinkedHashMap<String, String>(raw);
        m.put(key, value.trim());
        return new EngineConfig(m);
    }

    /** Absolute numeric tolerance in length units. */
    public double eps() { return epsilonRel * ballRadius; }

    public String describe() {
        StringBuilder sb = new StringBuilder();
        for (String k : KEYS) sb.append(k).append('=').append(raw.get(k)).append('\n');
        return sb.toString();
    }
}
