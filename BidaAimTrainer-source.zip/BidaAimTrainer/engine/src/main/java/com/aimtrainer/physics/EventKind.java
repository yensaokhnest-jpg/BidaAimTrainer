package com.aimtrainer.physics;
public enum EventKind { CUSHION, TIP, BALL_HIT, POCKET, CUSHION_LIMIT }
