package com.aimtrainer.physics;
public enum Termination { BALL_HIT, POCKETED, MAX_CUSHIONS, MAX_LENGTH, STOPPED, ESCAPED }
