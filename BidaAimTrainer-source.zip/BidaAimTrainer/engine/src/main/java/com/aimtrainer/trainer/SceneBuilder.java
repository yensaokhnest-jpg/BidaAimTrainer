package com.aimtrainer.trainer;

import com.aimtrainer.ball.Ball;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.physics.*;
import com.aimtrainer.table.*;
import java.util.*;

/** Turns model + frame into screen-space drawing commands. No Android / AWT dependency. */
public final class SceneBuilder {
    private SceneBuilder() {}

    public static final int BG = 0xFF14171B, WOOD = 0xFF6B4423, WOOD_DARK = 0xFF3B2410, CLOTH = 0xFF0E6B3C,
        CUSHION = 0xFF0A4A28, POCKET = 0xFF050505, GOLD = 0xFFFFD54A, OK_GREEN = 0xFF3DDC84, WHITE = 0xFFFFFFFF,
        CUE_RAY = 0xF2FFFFFF, OBJ_PATH = 0xFFFF9F1A, CUE_POST = 0xFF6DFFB0, CONTACT = 0xFFFF3B30,
        HUD_BG = 0xAA000000, DBG_CYAN = 0xFF4DD0E1, DBG_MAGENTA = 0xFFFF4DFF, DIAMOND = 0xFFE8D9B0;

    public static double railWidth(EngineConfig c) { return 0.075 * c.tableWidth; }

    static int ballColor(String id) {
        if (id.equals(TrainerModel.CUE)) return 0xFFF4F4F4;
        switch (id) { case "1": return 0xFFF5C518; case "2": return 0xFF1E5BD8; case "3": return 0xFFD32F2F; default: return 0xFF8E44AD; }
    }

    private static final class Ctx {
        DrawList d = new DrawList(); Viewport v; double dp; EngineConfig c; double R;
        double[] xs(List<Vec2> pts) { double[] a = new double[pts.size()]; for (int i = 0; i < a.length; i++) a[i] = v.sx(pts.get(i).x); return a; }
        double[] ys(List<Vec2> pts) { double[] a = new double[pts.size()]; for (int i = 0; i < a.length; i++) a[i] = v.sy(pts.get(i).y); return a; }
    }

    public static DrawList build(TrainerModel m, TrainerFrame f, Viewport v, double viewW, double viewH, double dp) {
        Ctx x = new Ctx(); x.v = v; x.dp = dp; x.c = m.config(); x.R = x.c.ballRadius;
        TrainerSettings s = m.settings();
        Table t = m.table();
        double L = x.c.tableLength, W = x.c.tableWidth, rail = railWidth(x.c);
        DrawList d = x.d;

        d.rect(0, 0, viewW, viewH, BG, 0, 0, "bg");
        d.rect(v.sx(-rail), v.sy(W + rail), v.sx(L + rail), v.sy(-rail), WOOD, WOOD_DARK, 2 * dp, "rail");
        d.rect(v.sx(0), v.sy(W), v.sx(L), v.sy(0), CLOTH, 0, 0, "cloth");
        drawDiamonds(x, L, W, rail);
        for (CushionSegment g : t.cushions)
            d.line(v.sx(g.a.x), v.sy(g.a.y), v.sx(g.b.x), v.sy(g.b.y), CUSHION, Math.max(2 * dp, v.len(x.R * 0.5)), false, "cushion");
        drawPockets(x, m, f, t);

        ShotResult r = f.shot;
        if (s.showGuide && r != null) drawPaths(x, s, f, r);
        drawBalls(x, m, f);
        if (s.showGuide && r != null) drawMarkers(x, s, r);
        if (s.debug) drawDebug(x, m, f, t, L, W, viewW, viewH);
        drawHud(x, m, f, viewW, viewH);
        return d;
    }

    // ------------------------------------------------------------------ table
    private static void drawDiamonds(Ctx x, double L, double W, double rail) {
        double r = Math.max(1.5 * x.dp, x.v.len(rail * 0.07));
        for (int k = 1; k <= 7; k++) {
            if (k == 4) continue;
            x.d.circle(x.v.sx(L * k / 8), x.v.sy(-rail / 2), r, DIAMOND, 0, 0, false, "diamond");
            x.d.circle(x.v.sx(L * k / 8), x.v.sy(W + rail / 2), r, DIAMOND, 0, 0, false, "diamond");
        }
        for (int k = 1; k <= 3; k++) {
            x.d.circle(x.v.sx(-rail / 2), x.v.sy(W * k / 4), r, DIAMOND, 0, 0, false, "diamond");
            x.d.circle(x.v.sx(L + rail / 2), x.v.sy(W * k / 4), r, DIAMOND, 0, 0, false, "diamond");
        }
    }

    private static void drawPockets(Ctx x, TrainerModel m, TrainerFrame f, Table t) {
        String tgtPocket = f.shot != null ? f.shot.targetPocketName() : null;
        for (Pocket k : t.pockets) {
            Vec2 c = m.pocketCenter(k);
            double rr = x.v.len(0.6 * k.len);
            x.d.circle(x.v.sx(c.x), x.v.sy(c.y), rr, POCKET, 0, 0, false, "pocket");
            boolean selected = m.mode() != TrainerMode.FREE && k.name.equals(m.pocketName()) && !(m.mode() == TrainerMode.BANK && m.settings().bankAnyPocket);
            if (selected) x.d.circle(x.v.sx(c.x), x.v.sy(c.y), rr + 2 * x.dp, 0, GOLD, 2.5 * x.dp, false, "pocketSel");
            if (k.name.equals(tgtPocket) && m.settings().showGuide)
                x.d.circle(x.v.sx(c.x), x.v.sy(c.y), rr + 5 * x.dp, 0, OK_GREEN, 3 * x.dp, false, "pocketHit");
        }
    }

    // ------------------------------------------------------------------ guidelines
    private static void path(Ctx x, PathTrace p, double maxLen, int color, double w, boolean dash, String tag) {
        List<Vec2> pts = PolylineClip.clip(p.points, maxLen);
        if (pts.size() >= 2) x.d.poly(x.xs(pts), x.ys(pts), color, w, dash, tag);
    }

    private static void cushionMarks(Ctx x, PathTrace p, double maxLen, String tag) {
        for (PathEvent e : p.events) {
            if ((e.kind != EventKind.CUSHION && e.kind != EventKind.TIP) || e.distance > maxLen) continue;
            double px = x.v.sx(e.point.x), py = x.v.sy(e.point.y);
            x.d.circle(px, py, 3.5 * x.dp, e.kind == EventKind.TIP ? DBG_MAGENTA : WHITE, 0xFF000000, 1 * x.dp, false, tag);
            x.d.text(px + 6 * x.dp, py - 6 * x.dp, Integer.toString(e.cushionIndex), WHITE, 11 * x.dp, DrawList.LEFT, tag + "Txt");
        }
    }

    private static void drawPaths(Ctx x, TrainerSettings s, TrainerFrame f, ShotResult r) {
        double L = x.c.tableLength;
        double aimLen = s.aimLenFactor * L, predLen = s.predictLenFactor * L;
        path(x, r.cuePath, aimLen, CUE_RAY, 1.8 * x.dp, true, "cueRay");
        cushionMarks(x, r.cuePath, aimLen, "cueCushion");
        if (r.contact != null && s.showObjectPath && r.targetPath != null) {
            path(x, r.targetPath, predLen, OBJ_PATH, 2.4 * x.dp, false, "objPath");
            cushionMarks(x, r.targetPath, predLen, "objCushion");
            PathTrace tp = r.targetPath;
            if (tp.termination != Termination.POCKETED && PolylineClip.length(tp.points) <= predLen) {
                Vec2 e = tp.endPoint();
                x.d.circle(x.v.sx(e.x), x.v.sy(e.y), x.v.len(x.R), 0, OBJ_PATH, 1.6 * x.dp, true, "objEnd");
            }
        }
        if (r.contact != null && s.showCuePost && r.cuePostPath != null) {
            path(x, r.cuePostPath, predLen, CUE_POST, 2.0 * x.dp, false, "cuePost");
            cushionMarks(x, r.cuePostPath, predLen, "postCushion");
        }
    }

    private static void drawMarkers(Ctx x, TrainerSettings s, ShotResult r) {
        if (r.contact == null) return;
        BallContact c = r.contact;
        if (s.showGhost) {
            x.d.circle(x.v.sx(c.ghost.x), x.v.sy(c.ghost.y), x.v.len(x.R), 0x22FFFFFF, WHITE, 1.6 * x.dp, true, "ghost");
        }
        if (s.showContact) {
            double px = x.v.sx(c.contactPoint.x), py = x.v.sy(c.contactPoint.y), a = 7 * x.dp;
            x.d.line(x.v.sx(c.ghost.x), x.v.sy(c.ghost.y), x.v.sx(c.contactPoint.x + c.normal.x * x.R), x.v.sy(c.contactPoint.y + c.normal.y * x.R), CONTACT, 1.2 * x.dp, true, "centers");
            x.d.circle(px, py, 4.5 * x.dp, CONTACT, WHITE, 1.5 * x.dp, false, "contact");
            x.d.line(px - a, py, px + a, py, WHITE, 1.2 * x.dp, false, "contactCross");
            x.d.line(px, py - a, px, py + a, WHITE, 1.2 * x.dp, false, "contactCross");
        }
    }

    // ------------------------------------------------------------------ balls
    private static void drawBalls(Ctx x, TrainerModel m, TrainerFrame f) {
        double rr = x.v.len(x.R);
        for (Ball b : m.balls()) {
            double px = x.v.sx(b.pos.x), py = x.v.sy(b.pos.y);
            x.d.circle(px, py, rr, ballColor(b.id), 0xFF000000, 1.2 * x.dp, false, "ball");
            x.d.circle(px - rr * 0.32, py - rr * 0.32, rr * 0.28, 0x66FFFFFF, 0, 0, false, "shine");
            if (!b.id.equals(TrainerModel.CUE)) {
                x.d.circle(px, py, rr * 0.45, 0xFFFFFFFF, 0, 0, false, "ballNum");
                x.d.text(px, py + rr * 0.2, b.id, 0xFF000000, Math.max(9 * x.dp, rr * 0.6), DrawList.CENTER, "ballNumTxt");
            }
            if (b.id.equals(m.targetId())) x.d.circle(px, py, rr * 1.3, 0, GOLD, 2.2 * x.dp, false, "targetRing");
        }
    }

    // ------------------------------------------------------------------ debug overlay
    private static void drawDebug(Ctx x, TrainerModel m, TrainerFrame f, Table t, double L, double W, double viewW, double viewH) {
        double R = x.R;
        x.d.rect(x.v.sx(R), x.v.sy(W - R), x.v.sx(L - R), x.v.sy(R), 0, DBG_CYAN, 1 * x.dp, "dbgBox");
        for (Tip k : t.tips)
            x.d.circle(x.v.sx(k.pos.x), x.v.sy(k.pos.y), x.v.len(R), 0, DBG_MAGENTA, 1 * x.dp, true, "dbgTip");
        for (Pocket k : t.pockets)
            x.d.line(x.v.sx(k.a.x), x.v.sy(k.a.y), x.v.sx(k.b.x), x.v.sy(k.b.y), GOLD, 2 * x.dp, true, "dbgGate");
        for (Ball b : m.balls())
            if (!b.id.equals(TrainerModel.CUE))
                x.d.circle(x.v.sx(b.pos.x), x.v.sy(b.pos.y), x.v.len(2 * R), 0, DBG_CYAN, 1 * x.dp, true, "dbgBallZone");
        ShotResult r = f.shot;
        if (r == null) return;
        PathTrace[] ps = { r.cuePath, r.targetPath, r.cuePostPath };
        for (PathTrace p : ps) {
            if (p == null) continue;
            for (PathEvent e : p.events) {
                double px = x.v.sx(e.point.x), py = x.v.sy(e.point.y);
                x.d.line(px, py, px + x.v.len(e.normal.x * R * 1.8), py - x.v.len(e.normal.y * R * 1.8), DBG_MAGENTA, 1.5 * x.dp, false, "dbgNormal");
            }
        }
        // event log, bottom-left
        List<String> all = debugLines(m, f);
        int maxLines = 9, maxChars = (int) Math.max(20, (viewW * 0.62) / (5.6 * x.dp));
        List<String> lines = new ArrayList<String>();
        for (int i = 0; i < all.size() && i < maxLines; i++) {
            String l = all.get(i);
            lines.add(l.length() > maxChars ? l.substring(0, maxChars - 1) + "…" : l);
        }
        if (all.size() > maxLines) lines.set(maxLines - 1, "… (" + (all.size() - maxLines + 1) + " dòng nữa)");
        double lh = 12 * x.dp, y = viewH - 8 * x.dp - lines.size() * lh + lh * 0.8;
        double w = 0; for (String s : lines) w = Math.max(w, s.length() * 5.6 * x.dp);
        x.d.rect(4 * x.dp, y - lh, 4 * x.dp + w + 10 * x.dp, y + (lines.size() - 1) * lh + 5 * x.dp, HUD_BG, 0, 0, "dbgBg");
        for (int i = 0; i < lines.size(); i++)
            x.d.text(9 * x.dp, y + i * lh, lines.get(i), DBG_CYAN, 10 * x.dp, DrawList.LEFT, "dbgText");
    }

    public static List<String> debugLines(TrainerModel m, TrainerFrame f) {
        List<String> out = new ArrayList<String>();
        EngineConfig c = m.config();
        out.add(String.format(Locale.ROOT, "e_băng=%.2f mu_băng=%.2f e_bi=%.2f | R=%.2f %s | %s | frame %.2f ms",
            c.cushionRestitution, c.cushionFriction, c.ballBallRestitution, c.ballRadius, c.lengthUnit,
            c.dynamicMode ? "dynamic v=" + (int) c.defaultSpeed : "geometric", f.computeMs));
        ShotResult r = f.shot;
        if (r == null) return out;
        out.add(String.format(Locale.ROOT, "góc đánh %.4f° (cơ sở %.4f° + lệch %.4f°)", f.aimAngleDeg, f.baseAngleDeg, f.offsetDeg));
        addTrace(out, "CUE", r.cuePath);
        if (r.contact != null) {
            BallContact b = r.contact;
            out.add(String.format(Locale.ROOT, "CHẠM bi %s: ghost %s | tiếp xúc %s | cắt %.3f° (%s)", b.targetId, b.ghost, b.contactPoint, b.cutAngleDeg, b.cutSide));
            addTrace(out, "BI " + b.targetId, r.targetPath);
            if (r.cuePostPath != null) addTrace(out, "CUE sau", r.cuePostPath);
        }
        return out;
    }

    private static void addTrace(List<String> out, String name, PathTrace p) {
        if (p == null) return;
        out.add(String.format(Locale.ROOT, "%s: dài %.1f, kết thúc %s%s", name, p.length, p.termination, p.pocketName() != null ? " " + p.pocketName() : ""));
        for (PathEvent e : p.events) {
            if (e.kind == EventKind.CUSHION || e.kind == EventKind.TIP)
                out.add(String.format(Locale.ROOT, "  [%d] %s %s vào %.2f° ra %.2f°", e.cushionIndex, e.label, e.point, e.dirBefore.angleDeg(), e.dirAfter.angleDeg()));
        }
    }

    // ------------------------------------------------------------------ HUD
    private static void drawHud(Ctx x, TrainerModel m, TrainerFrame f, double viewW, double viewH) {
        TrainerSettings s = m.settings();
        String modeName = m.mode() == TrainerMode.FREE ? "Tự do" : m.mode() == TrainerMode.POCKET ? "Vào lỗ" : "Bank";
        List<String> lines = new ArrayList<String>();
        lines.add("AIM " + (s.showGuide ? "BẬT" : "TẮT") + " · " + modeName + (s.dynamic ? " · có lực/ma sát" : ""));
        if (s.showGuide) {
            lines.add(f.status);
            String extra = String.format(Locale.ROOT, "Góc đánh %.2f°", f.aimAngleDeg);
            if (m.mode() != TrainerMode.FREE) extra += String.format(Locale.ROOT, " (lệch %+.2f°)", f.offsetDeg);
            if (f.shot != null && f.shot.contact != null) extra += String.format(Locale.ROOT, " · cắt %.1f°", f.shot.contact.cutAngleDeg);
            lines.add(extra);
            if (m.mode() == TrainerMode.POCKET) {
                if (f.windowKnown) lines.add(String.format(Locale.ROOT, "Dung sai góc: +%.2f° / −%.2f°", f.windowPlus, f.windowMinus));
                else if (f.computing) lines.add("Đang tính dung sai góc…");
            }
        }
        double size = 12 * x.dp, lh = size + 3 * x.dp;
        int maxChars = (int) Math.max(16, (viewW * 0.55) / (size * 0.5));
        List<String> wrapped = new ArrayList<String>(); List<Integer> src = new ArrayList<Integer>();
        for (int i = 0; i < lines.size(); i++)
            for (String w : wrap(lines.get(i), maxChars)) { wrapped.add(w); src.add(i); }
        double maxW = 0;
        for (String l : wrapped) maxW = Math.max(maxW, l.length() * size * 0.5);
        x.d.rect(6 * x.dp, 6 * x.dp, 6 * x.dp + maxW + 12 * x.dp, 6 * x.dp + wrapped.size() * lh + 8 * x.dp, HUD_BG, 0, 0, "hudBg");
        for (int i = 0; i < wrapped.size(); i++)
            x.d.text(12 * x.dp, 6 * x.dp + size + i * lh, wrapped.get(i), src.get(i) == 0 ? GOLD : WHITE, size, DrawList.LEFT, "hud");
    }

    static List<String> wrap(String s, int maxChars) {
        List<String> out = new ArrayList<String>();
        String cur = "";
        for (String word : s.split(" ")) {
            if (cur.isEmpty()) cur = word;
            else if (cur.length() + 1 + word.length() <= maxChars) cur += " " + word;
            else { out.add(cur); cur = word; }
        }
        if (!cur.isEmpty()) out.add(cur);
        return out;
    }
}
