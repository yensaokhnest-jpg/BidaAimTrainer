package com.aimtrainer.physics;

import com.aimtrainer.geom.Vec2;

public final class PathEvent {
    public final EventKind kind;
    public final Vec2 point;          // ball center at the event
    public final String label;        // rail name, "tip:<pocket>", ball id or pocket name
    public final Vec2 normal;
    public final double distance;     // cumulative path length from the start
    public final double speedBefore, speedAfter;
    public final Vec2 dirBefore, dirAfter;   // dirAfter == null when the path ends here
    public final int cushionIndex;    // number of cushion/tip bounces including this one
    public PathEvent(EventKind kind, Vec2 point, String label, Vec2 normal, double distance,
                     double speedBefore, double speedAfter, Vec2 dirBefore, Vec2 dirAfter, int cushionIndex) {
        this.kind = kind; this.point = point; this.label = label; this.normal = normal; this.distance = distance;
        this.speedBefore = speedBefore; this.speedAfter = speedAfter;
        this.dirBefore = dirBefore; this.dirAfter = dirAfter; this.cushionIndex = cushionIndex;
    }
}
