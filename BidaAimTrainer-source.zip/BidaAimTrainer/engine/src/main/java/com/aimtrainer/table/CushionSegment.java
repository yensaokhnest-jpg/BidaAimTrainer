package com.aimtrainer.table;

import com.aimtrainer.geom.Vec2;

/** Straight cushion face between two jaw tips. n = unit normal pointing into the table. */
public final class CushionSegment {
    public final String name;
    public final Vec2 a, b, u, n;
    public final double len;
    public CushionSegment(String name, Vec2 a, Vec2 b, Vec2 n) {
        this.name = name; this.a = a; this.b = b; this.n = n;
        this.u = b.sub(a).unit();
        this.len = b.sub(a).len();
    }
}
