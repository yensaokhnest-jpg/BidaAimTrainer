package com.aimtrainer.collision;

import com.aimtrainer.geom.Vec2;

/** Velocity updates for the two collision types (no-spin model). */
public final class Impulse {
    private Impulse() {}

    /**
     * Cushion / jaw-tip bounce. n = unit normal pointing toward the ball.
     * Normal speed is multiplied by -e. Tangential speed loses min(|vt|, mu*(1+e)*|vn|).
     */
    public static Vec2 cushion(Vec2 v, Vec2 n, double e, double mu) {
        double vn = v.dot(n);                          // < 0 when approaching
        if (vn >= 0) return v;
        Vec2 vt = v.sub(n.mul(vn));
        double tm = vt.len();
        if (tm > 0 && mu > 0) {
            double loss = Math.min(tm, mu * (1 + e) * (-vn));
            vt = vt.mul(1.0 - loss / tm);
        }
        return vt.add(n.mul(-e * vn));
    }

    /**
     * Ball A (velocity vA) hits ball B (vB). n = unit vector from A to B at contact.
     * Equal masses, frictionless: only the normal component is exchanged.
     * Returns {vA', vB'}. Conserves momentum; relative normal speed after = e * before.
     */
    public static Vec2[] ballBall(Vec2 vA, Vec2 vB, Vec2 n, double e) {
        double u = vA.sub(vB).dot(n);
        if (u <= 0) return new Vec2[] { vA, vB };
        double j = 0.5 * (1 + e) * u;
        return new Vec2[] { vA.sub(n.mul(j)), vB.add(n.mul(j)) };
    }
}
