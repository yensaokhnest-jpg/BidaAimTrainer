package com.aimtrainer.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;
import com.aimtrainer.geom.Vec2;
import com.aimtrainer.trainer.*;

/**
 * Thin Android layer: replays the platform-independent DrawList on a Canvas and turns touches into
 * TrainerModel calls. All logic lives in (JVM-tested) TrainerModel / SceneBuilder.
 */
public class TableView extends View {
    public interface Listener {
        /** heavy == true: ball positions / target / pocket changed, slow results must be recomputed. */
        void onModelEdited(boolean heavy);
    }

    private TrainerModel model;
    private Listener listener;
    private final float dp;
    private float panelInset;
    private Viewport vp;
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tmp = new Path();
    private final DashPathEffect dash;
    private String dragId;
    private boolean aiming;

    public TableView(Context context) {
        super(context);
        dp = context.getResources().getDisplayMetrics().density;
        fillPaint.setStyle(Paint.Style.FILL);
        strokePaint.setStyle(Paint.Style.STROKE);
        dash = new DashPathEffect(new float[] { 6 * dp, 4 * dp }, 0);
    }

    public void setModel(TrainerModel m) { model = m; invalidate(); }
    public void setListener(Listener l) { listener = l; }
    public void setPanelInset(float px) { panelInset = px; invalidate(); }

    @Override
    protected void onDraw(Canvas canvas) {
        if (model == null) return;
        float w = getWidth(), h = getHeight();
        vp = Viewport.fit(w, h, model.config().tableLength, model.config().tableWidth,
                SceneBuilder.railWidth(model.config()), 8 * dp, panelInset);
        DrawList d = SceneBuilder.build(model, model.frame(), vp, w, h, dp);
        for (DrawList.Prim p : d.items) draw(canvas, p);
    }

    private void applyStroke(DrawList.Prim p) {
        strokePaint.setColor(p.stroke);
        strokePaint.setStrokeWidth((float) Math.max(1.0, p.width));
        strokePaint.setPathEffect(p.dash ? dash : null);
        strokePaint.setStrokeCap(p.dash ? Paint.Cap.BUTT : Paint.Cap.ROUND);
    }

    private void draw(Canvas c, DrawList.Prim p) {
        switch (p.kind) {
            case DrawList.RECT:
                if (p.fill != 0) { fillPaint.setColor(p.fill); c.drawRect((float) p.x[0], (float) p.y[0], (float) p.x[1], (float) p.y[1], fillPaint); }
                if (p.stroke != 0) { applyStroke(p); c.drawRect((float) p.x[0], (float) p.y[0], (float) p.x[1], (float) p.y[1], strokePaint); }
                break;
            case DrawList.LINE:
                applyStroke(p);
                c.drawLine((float) p.x[0], (float) p.y[0], (float) p.x[1], (float) p.y[1], strokePaint);
                break;
            case DrawList.POLY:
                if (p.x.length < 2) break;
                tmp.reset();
                tmp.moveTo((float) p.x[0], (float) p.y[0]);
                for (int i = 1; i < p.x.length; i++) tmp.lineTo((float) p.x[i], (float) p.y[i]);
                applyStroke(p);
                c.drawPath(tmp, strokePaint);
                break;
            case DrawList.CIRCLE:
                if (p.fill != 0) { fillPaint.setColor(p.fill); c.drawCircle((float) p.x[0], (float) p.y[0], (float) p.r, fillPaint); }
                if (p.stroke != 0) { applyStroke(p); c.drawCircle((float) p.x[0], (float) p.y[0], (float) p.r, strokePaint); }
                break;
            case DrawList.TEXT:
                textPaint.setColor(p.fill);
                textPaint.setTextSize((float) p.size);
                textPaint.setTextAlign(p.align == DrawList.CENTER ? Paint.Align.CENTER : p.align == DrawList.RIGHT ? Paint.Align.RIGHT : Paint.Align.LEFT);
                c.drawText(p.text, (float) p.x[0], (float) p.y[0], textPaint);
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (model == null || vp == null) return false;
        Vec2 p = new Vec2(vp.tx(e.getX()), vp.ty(e.getY()));
        int action = e.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            double tol = 24 * dp / vp.scale;                 // finger-friendly slop, in table units
            String id = model.pickBall(p, tol);
            dragId = null; aiming = false;
            if (id != null) {
                dragId = id;
                if (!id.equals(TrainerModel.CUE) && !id.equals(model.targetId())) { model.selectTarget(id); notifyEdited(true); }
            } else {
                String pk = model.pickPocket(p, tol * 0.5);
                if (pk != null) {
                    model.selectPocket(pk);
                    if (model.mode() == TrainerMode.BANK) model.setBankAnyPocket(false);
                    notifyEdited(true);
                } else {
                    aiming = true;
                    model.aimToward(p);
                    notifyEdited(false);
                }
            }
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            invalidate();
            return true;
        }
        if (action == MotionEvent.ACTION_MOVE) {
            if (dragId != null) { model.moveBall(dragId, p); notifyEdited(false); }
            else if (aiming) { model.aimToward(p); notifyEdited(false); }
            invalidate();
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            boolean moved = dragId != null;
            dragId = null; aiming = false;
            notifyEdited(moved);
            invalidate();
            return true;
        }
        return true;
    }

    private void notifyEdited(boolean heavy) { if (listener != null) listener.onModelEdited(heavy); }
}
