package com.aimtrainer.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import com.aimtrainer.config.EngineConfig;
import com.aimtrainer.trainer.*;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Bida Aim Trainer: offline practice tool. Standalone app; it does not touch any other app or the network. */
public class MainActivity extends Activity implements TableView.Listener {
    private static final int PANEL_DP = 300;
    private static final int TEXT = 0xFFEAEAEA, MUTED = 0xFF9AA0A6, ACCENT = 0xFFFFD54A;

    private TrainerModel model;
    private TableView tableView;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ExecutorService executor;
    private float density;
    private boolean updating;
    private boolean panelVisible = true;

    private ScrollView panel;
    private Button btnAim, btnPanel;
    private CheckBox cbGuide, cbGhost, cbContact, cbObj, cbPost, cbDynamic, cbDebug, cbBankAny;
    private RadioButton rbFree, rbPocket, rbBank;
    private RadioGroup rgMode;
    private SeekBar sbCushions, sbAimLen, sbPredLen, sbAim, sbBankN, sbPower;
    private TextView tvCushions, tvAimLen, tvPredLen, tvAim, tvBankN, tvPower, tvBankRoute, tvPocketHint, tvE, tvMu, tvEbb;
    private LinearLayout groupBank, groupDebug;

    // ------------------------------------------------------------------ lifecycle
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        density = getResources().getDisplayMetrics().density;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        executor = Executors.newSingleThreadExecutor();

        model = new TrainerModel(loadConfig());
        model.load(getSharedPreferences("aim", MODE_PRIVATE).getString("state", null));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        tableView = new TableView(this);
        tableView.setModel(model);
        tableView.setListener(this);
        root.addView(tableView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        buildPanel();
        root.addView(panel, new FrameLayout.LayoutParams(dp(PANEL_DP), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        btnAim = floatingButton("AIM");
        btnAim.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                model.settings().showGuide = !model.settings().showGuide;
                model.displaySettingsChanged();
                refreshControls(); tableView.invalidate();
            }
        });
        btnPanel = floatingButton("☰");
        btnPanel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setPanelVisible(!panelVisible); }
        });
        col.addView(btnAim, new LinearLayout.LayoutParams(dp(54), dp(44)));
        col.addView(btnPanel, new LinearLayout.LayoutParams(dp(54), dp(44)));
        root.addView(col, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START | Gravity.CENTER_VERTICAL));

        setContentView(root);
        setPanelVisible(true);
        refreshControls();
        scheduleHeavy();
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor ed = getSharedPreferences("aim", MODE_PRIVATE).edit();
        ed.putString("state", model.save());
        ed.apply();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    private EngineConfig loadConfig() {
        try {
            Reader r = new InputStreamReader(getAssets().open("billiards_config.properties"), "UTF-8");
            try { return EngineConfig.load(r); } finally { r.close(); }
        } catch (IOException e) {
            throw new RuntimeException("Cannot read billiards_config.properties from assets", e);
        }
    }

    // ------------------------------------------------------------------ model <-> UI
    @Override
    public void onModelEdited(boolean heavy) {
        refreshControls();
        if (heavy) scheduleHeavy();
    }

    /** Runs the slow computation (aim window / bank sweep) on a background thread; stale results are dropped. */
    private void scheduleHeavy() {
        if (!model.needsHeavy() || model.heavyUpToDate()) { tableView.invalidate(); return; }
        final TrainerModel.HeavyJob job = model.heavyJob();
        executor.execute(new Runnable() {
            public void run() {
                final HeavyResult r = job.run();
                main.post(new Runnable() {
                    public void run() {
                        if (model.acceptHeavy(r)) { refreshControls(); tableView.invalidate(); }
                    }
                });
            }
        });
        tableView.invalidate();
    }

    private void setPanelVisible(boolean v) {
        panelVisible = v;
        panel.setVisibility(v ? View.VISIBLE : View.GONE);
        btnPanel.setText(v ? "✕" : "☰");
        tableView.setPanelInset(v ? dp(PANEL_DP) : 0);
    }

    private void refreshControls() {
        updating = true;
        TrainerSettings s = model.settings();
        TrainerMode mode = model.mode();
        btnAim.setText(s.showGuide ? "AIM\nBẬT" : "AIM\nTẮT");
        btnAim.setTextColor(s.showGuide ? ACCENT : MUTED);
        cbGuide.setChecked(s.showGuide);
        rbFree.setChecked(mode == TrainerMode.FREE);
        rbPocket.setChecked(mode == TrainerMode.POCKET);
        rbBank.setChecked(mode == TrainerMode.BANK);

        sbCushions.setProgress(s.maxCushions);
        tvCushions.setText("Số lần bật băng: " + s.maxCushions);
        sbAimLen.setProgress((int) Math.round(s.aimLenFactor / 0.2) - 1);
        tvAimLen.setText(String.format(Locale.US, "Độ dài tia ngắm: %.1f × bàn", s.aimLenFactor));
        sbPredLen.setProgress((int) Math.round(s.predictLenFactor / 0.2) - 1);
        tvPredLen.setText(String.format(Locale.US, "Độ dài đường dự đoán: %.1f × bàn", s.predictLenFactor));

        if (mode == TrainerMode.FREE) {
            sbAim.setMax(3600);
            sbAim.setProgress((int) Math.round((model.freeAngleDeg() + 180) * 10));
            tvAim.setText(String.format(Locale.US, "Góc đánh: %.1f°", model.freeAngleDeg()));
        } else {
            sbAim.setMax(400);
            sbAim.setProgress((int) Math.round((model.offsetDeg() + 10) / 0.05));
            tvAim.setText(String.format(Locale.US, "Lệch so với đường lý tưởng: %+.2f°", model.offsetDeg()));
        }

        groupBank.setVisibility(mode == TrainerMode.BANK ? View.VISIBLE : View.GONE);
        tvPocketHint.setVisibility(mode == TrainerMode.POCKET ? View.VISIBLE : View.GONE);
        sbBankN.setProgress(s.bankCushions - 1);
        tvBankN.setText("Số băng của bank: " + s.bankCushions);
        cbBankAny.setChecked(s.bankAnyPocket);
        TrainerFrame f = model.frame();
        tvBankRoute.setText(f.computing ? "Đang tính…" : f.routes.isEmpty() ? "Không có tuyến" : "Tuyến " + (f.bankIndex + 1) + "/" + f.routes.size());

        cbGhost.setChecked(s.showGhost);
        cbContact.setChecked(s.showContact);
        cbObj.setChecked(s.showObjectPath);
        cbPost.setChecked(s.showCuePost);
        cbDynamic.setChecked(s.dynamic);
        sbPower.setProgress((int) Math.round(s.power / 100.0) - 2);
        tvPower.setText(String.format(Locale.US, "Lực đánh: %d %s/s", (int) s.power, model.config().lengthUnit));
        sbPower.setEnabled(s.dynamic);
        cbDebug.setChecked(s.debug);
        groupDebug.setVisibility(s.debug ? View.VISIBLE : View.GONE);
        tvE.setText(String.format(Locale.US, "e băng: %.2f", s.cushionRestitution));
        tvMu.setText(String.format(Locale.US, "μ băng: %.2f", s.cushionFriction));
        tvEbb.setText(String.format(Locale.US, "e bi-bi: %.2f", s.ballRestitution));
        updating = false;
    }

    // ------------------------------------------------------------------ panel construction
    private int dp(float v) { return (int) (v * density + 0.5f); }

    private Button floatingButton(String text) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setAllCaps(false);
        bt.setTextSize(12);
        bt.setTextColor(TEXT);
        bt.setBackgroundColor(0x99000000);
        return bt;
    }

    private TextView label(LinearLayout parent, String text, boolean header) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(header ? ACCENT : TEXT);
        t.setTextSize(header ? 14 : 13);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(header ? 12 : 6), 0, 0);
        parent.addView(t, lp);
        return t;
    }

    private CheckBox check(LinearLayout parent, String text, final CheckAction a) {
        CheckBox c = new CheckBox(this);
        c.setText(text);
        c.setTextColor(TEXT);
        c.setTextSize(13);
        c.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton v, boolean checked) { if (!updating) a.run(checked); }
        });
        parent.addView(c, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return c;
    }

    private SeekBar seek(LinearLayout parent, int max, final SeekAction a) {
        SeekBar s = new SeekBar(this);
        s.setMax(max);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int p, boolean fromUser) { if (fromUser && !updating) a.change(p); }
            public void onStartTrackingTouch(SeekBar bar) { }
            public void onStopTrackingTouch(SeekBar bar) { if (!updating) a.stop(); }
        });
        parent.addView(s, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return s;
    }

    private Button button(LinearLayout row, String text, final Runnable r) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setAllCaps(false);
        bt.setTextSize(12);
        bt.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { r.run(); } });
        row.addView(bt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return bt;
    }

    private LinearLayout row(LinearLayout parent) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(r, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return r;
    }

    private interface CheckAction { void run(boolean checked); }
    private interface SeekAction { void change(int progress); void stop(); }

    /** Display-only change: cheap, no recomputation. */
    private void display() { model.displaySettingsChanged(); tableView.invalidate(); refreshControls(); }
    /** Physics change: engine rebuilt now, slow results recomputed (only after the slider is released). */
    private void physics(boolean recompute) {
        model.physicsSettingsChanged();
        tableView.invalidate(); refreshControls();
        if (recompute) scheduleHeavy();
    }

    private void buildPanel() {
        final TrainerSettings s = model.settings();
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(12), dp(8), dp(12), dp(16));
        panel = new ScrollView(this);
        panel.setBackgroundColor(0xE6101418);
        panel.addView(c, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        label(c, "BIDA AIM TRAINER", true);
        label(c, "Luyện tập offline. Kéo bi để đặt, chạm/kéo trên bàn để xoay hướng, chạm vào lỗ để chọn lỗ.", false).setTextColor(MUTED);

        cbGuide = check(c, "Hiện đường ngắm (AIM)", new CheckAction() { public void run(boolean v) { s.showGuide = v; display(); } });

        label(c, "Chế độ", true);
        rgMode = new RadioGroup(this);
        rgMode.setOrientation(RadioGroup.HORIZONTAL);
        rbFree = radio("Tự do"); rbPocket = radio("Vào lỗ"); rbBank = radio("Bank");
        rgMode.addView(rbFree); rgMode.addView(rbPocket); rgMode.addView(rbBank);
        rgMode.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup g, int id) {
                if (updating) return;
                model.setMode(id == rbFree.getId() ? TrainerMode.FREE : id == rbPocket.getId() ? TrainerMode.POCKET : TrainerMode.BANK);
                refreshControls(); scheduleHeavy();
            }
        });
        c.addView(rgMode, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        tvPocketHint = label(c, "Chạm vào một lỗ trên bàn để chọn lỗ cần vào.", false);
        tvPocketHint.setTextColor(MUTED);

        label(c, "Góc ngắm", true);
        tvAim = label(c, "", false);
        sbAim = seek(c, 3600, new SeekAction() {
            public void change(int p) {
                if (model.mode() == TrainerMode.FREE) model.setFreeAngle(-180 + p * 0.1);
                else model.setOffset(-10 + p * 0.05);
                tableView.invalidate(); refreshControls();
            }
            public void stop() { }
        });
        LinearLayout r1 = row(c);
        button(r1, "−1°", new Runnable() { public void run() { nudge(-1); } });
        button(r1, "−0.1°", new Runnable() { public void run() { nudge(-0.1); } });
        button(r1, "+0.1°", new Runnable() { public void run() { nudge(0.1); } });
        button(r1, "+1°", new Runnable() { public void run() { nudge(1); } });
        LinearLayout r1b = row(c);
        button(r1b, "Về đường lý tưởng", new Runnable() { public void run() { model.resetOffset(); display(); } });

        groupBank = new LinearLayout(this);
        groupBank.setOrientation(LinearLayout.VERTICAL);
        c.addView(groupBank, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        label(groupBank, "Bank", true);
        tvBankN = label(groupBank, "", false);
        sbBankN = seek(groupBank, TrainerSettings.MAX_BANK - 1, new SeekAction() {
            public void change(int p) { model.setBankCushions(p + 1); tableView.invalidate(); refreshControls(); }
            public void stop() { scheduleHeavy(); }
        });
        cbBankAny = check(groupBank, "Tìm vào mọi lỗ (tắt = chỉ lỗ đã chọn)", new CheckAction() {
            public void run(boolean v) { model.setBankAnyPocket(v); refreshControls(); scheduleHeavy(); }
        });
        tvBankRoute = label(groupBank, "", false);
        LinearLayout r2 = row(groupBank);
        button(r2, "◀ Tuyến trước", new Runnable() { public void run() { model.nextBank(-1); display(); } });
        button(r2, "Tuyến sau ▶", new Runnable() { public void run() { model.nextBank(1); display(); } });

        label(c, "Tia ngắm & dự đoán", true);
        tvCushions = label(c, "", false);
        sbCushions = seek(c, TrainerSettings.MAX_CUSHIONS, new SeekAction() {
            public void change(int p) { s.maxCushions = p; physics(false); }
            public void stop() { scheduleHeavy(); }
        });
        tvAimLen = label(c, "", false);
        sbAimLen = seek(c, 29, new SeekAction() {
            public void change(int p) { s.aimLenFactor = (p + 1) * 0.2; display(); }
            public void stop() { }
        });
        tvPredLen = label(c, "", false);
        sbPredLen = seek(c, 29, new SeekAction() {
            public void change(int p) { s.predictLenFactor = (p + 1) * 0.2; display(); }
            public void stop() { }
        });
        cbGhost = check(c, "Ghost ball", new CheckAction() { public void run(boolean v) { s.showGhost = v; display(); } });
        cbContact = check(c, "Điểm tiếp xúc", new CheckAction() { public void run(boolean v) { s.showContact = v; display(); } });
        cbObj = check(c, "Đường bi mục tiêu", new CheckAction() { public void run(boolean v) { s.showObjectPath = v; display(); } });
        cbPost = check(c, "Đường bi cái sau va chạm", new CheckAction() { public void run(boolean v) { s.showCuePost = v; display(); } });

        label(c, "Bi", true);
        LinearLayout r3 = row(c);
        button(r3, "Thêm bi", new Runnable() { public void run() { model.addObjectBall(); display(); scheduleHeavy(); } });
        button(r3, "Xóa bi chọn", new Runnable() { public void run() { model.removeBall(model.targetId()); display(); scheduleHeavy(); } });
        LinearLayout r4 = row(c);
        button(r4, "Đặt lại bàn", new Runnable() { public void run() { model.resetLayout(); display(); scheduleHeavy(); } });

        label(c, "Vật lý", true);
        cbDynamic = check(c, "Mô phỏng lực & ma sát (đường dừng khi bi hết đà)", new CheckAction() {
            public void run(boolean v) { s.dynamic = v; physics(true); }
        });
        tvPower = label(c, "", false);
        sbPower = seek(c, 118, new SeekAction() {
            public void change(int p) { s.power = (p + 2) * 100.0; physics(false); }
            public void stop() { scheduleHeavy(); }
        });
        cbDebug = check(c, "Chế độ debug physics", new CheckAction() { public void run(boolean v) { s.debug = v; display(); } });
        groupDebug = new LinearLayout(this);
        groupDebug.setOrientation(LinearLayout.VERTICAL);
        c.addView(groupDebug, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        tvE = label(groupDebug, "", false);
        stepper(groupDebug, new Runnable() { public void run() { s.cushionRestitution -= 0.05; physics(true); } },
                            new Runnable() { public void run() { s.cushionRestitution += 0.05; physics(true); } });
        tvMu = label(groupDebug, "", false);
        stepper(groupDebug, new Runnable() { public void run() { s.cushionFriction -= 0.05; physics(true); } },
                            new Runnable() { public void run() { s.cushionFriction += 0.05; physics(true); } });
        tvEbb = label(groupDebug, "", false);
        stepper(groupDebug, new Runnable() { public void run() { s.ballRestitution -= 0.01; physics(true); } },
                            new Runnable() { public void run() { s.ballRestitution += 0.01; physics(true); } });
        LinearLayout r5 = row(groupDebug);
        button(r5, "Khôi phục thông số gốc", new Runnable() {
            public void run() { resetPhysicsToConfig(); }
        });
        label(c, "Ứng dụng chạy hoàn toàn offline, không yêu cầu quyền nào.", false).setTextColor(MUTED);
    }

    private void resetPhysicsToConfig() {
        try {
            Reader r = new InputStreamReader(getAssets().open("billiards_config.properties"), "UTF-8");
            EngineConfig base;
            try { base = EngineConfig.load(r); } finally { r.close(); }
            TrainerSettings s = model.settings();
            s.cushionRestitution = base.cushionRestitution; s.cushionFriction = base.cushionFriction; s.ballRestitution = base.ballBallRestitution;
            physics(true);
        } catch (IOException e) { /* keep current values */ }
    }

    private void stepper(LinearLayout parent, Runnable minus, Runnable plus) {
        LinearLayout r = row(parent);
        button(r, "−", minus);
        button(r, "+", plus);
    }

    private RadioButton radio(String text) {
        RadioButton rb = new RadioButton(this);
        rb.setText(text);
        rb.setTextColor(TEXT);
        rb.setTextSize(13);
        rb.setId(View.generateViewId());
        return rb;
    }

    private void nudge(double deg) {
        model.nudge(deg);
        tableView.invalidate(); refreshControls();
    }
}
