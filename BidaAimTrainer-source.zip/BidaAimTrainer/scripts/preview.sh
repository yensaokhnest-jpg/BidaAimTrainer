#!/bin/sh
# Render ảnh PNG của giao diện (cùng DrawList mà Android vẽ) vào build/preview
cd "$(dirname "$0")/.." && ./scripts/build_engine.sh && java -Djava.awt.headless=true -cp build/jvm com.aimtrainer.tool.Preview build/preview
