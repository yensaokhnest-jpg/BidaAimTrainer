#!/bin/sh
# Builds the installable debug APK. Needs: JDK 17, Gradle 8.7+ (or Android Studio), Android SDK (ANDROID_HOME).
cd "$(dirname "$0")/.."
command -v gradle >/dev/null 2>&1 || { echo "Thiếu Gradle 8.7+ (hoặc mở thư mục này bằng Android Studio và bấm Build > Build APK)"; exit 1; }
if [ -z "$ANDROID_HOME" ] && [ ! -f local.properties ]; then
  echo "Thiếu Android SDK: đặt ANDROID_HOME hoặc tạo local.properties với dòng sdk.dir=/duong/dan/Android/Sdk"; exit 1
fi
gradle :engine:engineTests :app:assembleDebug || exit 1
mkdir -p dist && cp app/build/outputs/apk/debug/app-debug.apk dist/BidaAimTrainer-debug.apk && echo "APK: dist/BidaAimTrainer-debug.apk"
