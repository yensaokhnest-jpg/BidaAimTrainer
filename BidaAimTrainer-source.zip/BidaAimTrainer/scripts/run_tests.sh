#!/bin/sh
# Builds engine + trainer + tests on a plain JVM and runs ALL tests (no Android SDK needed).
cd "$(dirname "$0")/.." && ./scripts/build_engine.sh && java -Djava.awt.headless=true -cp build/jvm com.aimtrainer.test.TestRunner app/src/main/assets/billiards_config.properties
