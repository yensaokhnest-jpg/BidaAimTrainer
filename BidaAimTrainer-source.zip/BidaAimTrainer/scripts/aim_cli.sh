#!/bin/sh
# Công cụ dòng lệnh để kiểm tra engine (không cần Android). Ví dụ:
#   scripts/aim_cli.sh --line "cue 600 400" --line "ball 1 1800 800" --line "pocket 1 tr"
cd "$(dirname "$0")/.."
[ -d build/jvm/com ] || ./scripts/build_engine.sh || exit 1
exec java -cp build/jvm com.aimtrainer.tool.AimTool --config app/src/main/assets/billiards_config.properties "$@"
