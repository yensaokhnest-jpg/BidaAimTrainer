#!/bin/sh
# JVM-only build of engine + trainer + CLI tool + tests (no Android needed). Java 8 syntax.
cd "$(dirname "$0")/.."
rm -rf build/jvm && mkdir -p build/jvm
FILES=$(find engine/src -name '*.java')
if command -v javac >/dev/null 2>&1; then
  javac -source 8 -target 8 -Xlint:-options -encoding UTF-8 -d build/jvm $FILES
else
  java -m jdk.compiler/com.sun.tools.javac.Main -source 8 -target 8 -Xlint:-options -encoding UTF-8 -d build/jvm $FILES
fi
